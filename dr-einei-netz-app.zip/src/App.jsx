import { useState, useRef, useEffect, useCallback } from "react";

const QUESTIONS = [
  { id:'age', q:'מה גילך?', type:'select', opts:['מתחת ל-18','18–25','26–35','36–45','46–55','56+'] },
  { id:'prescription', q:'מה עוצמת המשקפיים/עדשות שלך?', type:'select', opts:['עד -3 (קל)','-3 עד -6 (בינוני)','-6 עד -10 (חזק)','מעל -10 (חמור)','ראייה קרובה (פלוס)','אסטיגמציה'] },
  { id:'stable', q:'כמה זמן המספר שלך לא השתנה?', type:'select', opts:['פחות משנה','שנה אחת','שנתיים ומעלה'] },
  { id:'cornea', q:'האם אובחנת עם קרטוקונוס?', type:'bool' },
  { id:'dry_eyes', q:'האם אתה סובל מעיניים יבשות?', type:'bool' },
  { id:'glaucoma', q:'האם אובחנת עם גלאוקומה?', type:'bool' },
  { id:'cataract', q:'האם יש לך קטרקט?', type:'bool' },
  { id:'diabetes', q:'האם אתה חולה סוכרת?', type:'bool' },
  { id:'autoimmune', q:'האם יש לך מחלה אוטואימונית?', type:'bool' },
  { id:'medications', q:'האם אתה נוטל תרופות המשפיעות על הראייה?', type:'bool' },
  { id:'pregnant', q:'האם את בהריון או מניקה?', type:'bool' },
  { id:'prev_surgery', q:'האם עברת ניתוח עיניים בעבר?', type:'bool' },
  { id:'family_history', q:'האם יש היסטוריה משפחתית של מחלות עיניים?', type:'bool' },
];

const FOLLOWUP_TIMELINE = [
  { id:'d1', label:'יום 1', days:1, icon:'🌅', desc:'בדיקה ראשונה אחרי ניתוח' },
  { id:'w1', label:'שבוע 1', days:7, icon:'📅', desc:'התאוששות ראשונית' },
  { id:'m1', label:'חודש 1', days:30, icon:'🗓️', desc:'יציבות ראשונית' },
  { id:'m3', label:'חודש 3', days:90, icon:'📊', desc:'הערכת תוצאה' },
  { id:'m6', label:'חודש 6', days:180, icon:'🔍', desc:'מעקב ביניים' },
  { id:'m12', label:'שנה 1', days:365, icon:'🏆', desc:'בדיקה שנתית' },
];

const SYMPTOM_QUESTIONS = [
  { id:'dryness', label:'יובש בעיניים', icon:'💧' },
  { id:'clarity', label:'בהירות ראייה', icon:'👁️' },
  { id:'pain', label:'כאב / אי נוחות', icon:'😣' },
  { id:'sensitivity', label:'רגישות לאור', icon:'🌟' },
  { id:'halos', label:'הילות סביב אורות', icon:'🌙' },
];

const SNELLEN_ROWS = [
  { size:80, acuity:'6/60', snellenNum:10, count:1, threshold:1 },
  { size:64, acuity:'6/36', snellenNum:16, count:1, threshold:1 },
  { size:50, acuity:'6/24', snellenNum:25, count:2, threshold:2 },
  { size:40, acuity:'6/18', snellenNum:33, count:3, threshold:2 },
  { size:31, acuity:'6/12', snellenNum:50, count:4, threshold:3 },
  { size:24, acuity:'6/9', snellenNum:66, count:4, threshold:3 },
  { size:19, acuity:'6/6', snellenNum:100, count:5, threshold:4 },
  { size:15, acuity:'6/5', snellenNum:120, count:5, threshold:4 },
];
const DIRS = ['up','down','left','right'];
const DIR_ARROWS = { up:'↑', down:'↓', left:'←', right:'→' };
const DIR_HEB = { up:'למעלה', down:'למטה', left:'שמאל', right:'ימין' };

const C = {
  bg:'#0a2d5e', surface:'#0d3570', card:'#112f63',
  cardBorder:'rgba(255,255,255,0.15)', primary:'#3b9eff',
  primaryLight:'rgba(59,158,255,0.15)', primaryGlow:'rgba(59,158,255,0.4)',
  cyan:'#38bdf8', cyanDim:'rgba(56,189,248,0.15)', cyanGlow:'rgba(56,189,248,0.35)',
  text:'#ffffff', muted:'rgba(255,255,255,0.45)', mutedLight:'rgba(255,255,255,0.7)',
  green:'#4ade80', yellow:'#fbbf24', red:'#f87171', white:'#ffffff',
  purple:'#a78bfa', border:'rgba(255,255,255,0.12)', shadow:'rgba(0,0,0,0.25)',
};

const GLOBAL_STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;600;700;800;900&display=swap');
  * { box-sizing:border-box; } body { margin:0; background:#fff; }
  @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
  @keyframes pulse-ring { 0%,100%{transform:scale(1);opacity:.3} 50%{transform:scale(1.05);opacity:.6} }
  @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
  @keyframes scan-line { 0%{top:20%;opacity:1} 80%{opacity:1} 100%{top:80%;opacity:0} }
  @keyframes ring-pulse { 0%,100%{opacity:.9} 50%{opacity:.5} }
  @keyframes blink-e { 0%,100%{opacity:1} 50%{opacity:0.3} }
  .fu0{animation:fadeUp .5s ease 0s both} .fu1{animation:fadeUp .5s ease .1s both}
  .fu2{animation:fadeUp .5s ease .2s both} .fu3{animation:fadeUp .5s ease .32s both}
  .fu4{animation:fadeUp .5s ease .44s both} .fu5{animation:fadeUp .5s ease .56s both}
  .hover-lift{transition:transform .15s ease,box-shadow .15s ease}
  .hover-lift:hover{transform:translateY(-2px);box-shadow:0 4px 16px rgba(30,111,186,.18)}
  .hover-slide{transition:all .14s ease}
  .hover-slide:hover{transform:translateX(-3px);border-color:rgba(255,255,255,.4)!important;background:rgba(255,255,255,.07)!important}
  .card-hover{transition:all .15s ease;cursor:pointer}
  .card-hover:hover{box-shadow:0 4px 20px rgba(30,111,186,.14);border-color:rgba(30,111,186,.35)!important}
  .bool-yes:hover{background:rgba(22,163,74,.1)!important;border-color:rgba(22,163,74,.6)!important;transform:scale(1.02)}
  .bool-no:hover{background:rgba(220,38,38,.08)!important;border-color:rgba(220,38,38,.5)!important;transform:scale(1.02)}
  .bool-yes,.bool-no{transition:all .14s ease}
  .dir-btn{transition:all .13s ease;cursor:pointer}
  .dir-btn:hover{transform:scale(1.07);background:rgba(30,111,186,.12)!important}
  .dir-btn:active{transform:scale(0.94)}
  input,textarea{outline:none}
  input:focus{border-color:rgba(59,158,255,.7)!important;box-shadow:0 0 0 3px rgba(59,158,255,.15)!important}
  ::-webkit-scrollbar{width:4px} ::-webkit-scrollbar-track{background:rgba(255,255,255,.05)} ::-webkit-scrollbar-thumb{background:rgba(255,255,255,.2);border-radius:2px}
  .tab-btn{transition:all .18s ease}
  .bottom-nav-btn{transition:all .15s ease;-webkit-tap-highlight-color:transparent}
  .bottom-nav-btn:active{transform:scale(0.92)}
`;

// ── Global home navigation ─────────────────────────────────────────────────────
let _goHome = null;
const setGoHome = (fn) => { _goHome = fn; };

const TopBar = ({ title, subtitle, onBack, hideHome=false }) => (
  <div dir="rtl" style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
    padding:'.75rem 1.1rem', borderBottom:'1px solid rgba(255,255,255,0.1)',
    background:'rgba(10,45,94,0.95)', backdropFilter:'blur(8px)',
    position:'sticky', top:0, zIndex:50, flexShrink:0 }}>
    {/* Right: back or placeholder */}
    <div style={{ width:80, display:'flex', justifyContent:'flex-end' }}>
      {onBack && (
        <button onClick={onBack} style={{ display:'flex', alignItems:'center', gap:'.3rem',
          background:'rgba(255,255,255,0.1)', border:'1px solid rgba(255,255,255,0.18)',
          borderRadius:'.65rem', padding:'.35rem .75rem', color:'rgba(255,255,255,.85)',
          cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.78rem', fontWeight:600 }}>
          → חזור
        </button>
      )}
    </div>
    {/* Center: title */}
    <div style={{ flex:1, textAlign:'center' }}>
      {title && <div style={{ color:'#fff', fontWeight:700, fontSize:'.9rem', lineHeight:1.2 }}>{title}</div>}
      {subtitle && <div style={{ color:'rgba(255,255,255,0.55)', fontSize:'.65rem', marginTop:'.1rem' }}>{subtitle}</div>}
    </div>
    {/* Left: home button */}
    <div style={{ width:80, display:'flex', justifyContent:'flex-start' }}>
      {!hideHome && (
        <button onClick={()=>_goHome&&_goHome()} style={{ display:'flex', alignItems:'center', gap:'.3rem',
          background:'rgba(59,158,255,0.2)', border:'1px solid rgba(59,158,255,0.4)',
          borderRadius:'.65rem', padding:'.35rem .75rem', color:C.cyan,
          cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.78rem', fontWeight:700 }}>
          🏠 ראשי
        </button>
      )}
    </div>
  </div>
);


const Shell = ({ children, center=false, fullBlack=false, noPad=false, title, subtitle, onBack, hideHome=false }) => (
  <div style={{ minHeight:'100vh', background:fullBlack?'#000':C.bg, fontFamily:"'Heebo',sans-serif",
  display:'flex', flexDirection:'column', alignItems:center?'center':undefined,
  justifyContent:center?'center':undefined, overflowX:'hidden',
  paddingBottom: noPad?0:72 }}>
  <style>{GLOBAL_STYLES}</style>
  {!fullBlack && !noPad && <TopBar title={title} subtitle={subtitle} onBack={onBack} hideHome={hideHome}/>}
  {children}
  </div>
);

let _postOpStore = {};
let _patientStore = {};
const loadPostOpData = () => ({ ..._postOpStore });
const savePostOpData = (d) => { _postOpStore = { ...d }; };
const loadPatient = () => ({ ..._patientStore });
const savePatientStore = (name, hmo) => { _patientStore = { name, hmo }; };

const HMO_LIST = [
  { id:'clalit', name:'כללית', logo:'🔵', color:'#2563eb' },
  { id:'maccabi', name:'מכבי', logo:'🟡', color:'#ca8a04' },
  { id:'meuhedet', name:'מאוחדת', logo:'🟢', color:'#16a34a' },
  { id:'leumit', name:'לאומית', logo:'🔴', color:'#dc2626' },
];

const PRICE_PACKAGES = [
  {
  id:'basic', name:'LASIK בסיסי', icon:'👁️',
  price:3800, pricePerEye:1900, duration:'20 דק׳',
  desc:'LASIK סטנדרטי עם לייזר Excimer',
  features:['בדיקות קדם ניתוח','הרדמה טפטפות','2 ביקורות מעקב'],
  hmoDiscount:{ clalit:15, maccabi:20, meuhedet:18, leumit:12 },
  },
  {
  id:'wavefront', name:'Wavefront מותאם', icon:'⭕', popular:true,
  price:5200, pricePerEye:2600, duration:'25 דק׳',
  desc:'LASIK מותאם אישית — Wavefront Guided',
  features:['מיפוי אבררציות אופטיות','דיוק גבוה יותר','3 ביקורות מעקב','אחריות שנה'],
  hmoDiscount:{ clalit:12, maccabi:18, meuhedet:15, leumit:10 },
  },
  {
  id:'smile', name:'SMILE לייזר', icon:'✨',
  price:6400, pricePerEye:3200, duration:'15 דק׳',
  desc:'ניתוח מינימלי פולשני — ללא פלאפ',
  features:['חתך מינימלי','פחות יובש לאחר','4 ביקורות מעקב','אחריות 2 שנים','מתאים לספורטאים'],
  hmoDiscount:{ clalit:10, maccabi:15, meuhedet:12, leumit:8 },
  },
];

const PAYMENT_OPTIONS = [
  { id:'full', label:'תשלום מלא', icon:'💳', desc:'חיסכון של 5%', badge:'חיסכון 5%', color:'#22c55e' },
  { id:'payments', label:'תשלומים ללא ריבית', icon:'📅', desc:'עד 24 תשלומים', badge:'ללא ריבית', color:'#06b6d4' },
  { id:'hmo', label:'השתתפות קופה', icon:'🏥', desc:'תיאום עם הקופה', badge:'הנחת קופה', color:'#818cf8' },
];

const CLINICS = [
  {
    id:'shaare_yerushalayim', name:'שערי העיר — ירושלים', city:'ירושלים', icon:'🕍',
    address:'יפו 224, ירושלים', rating:4.9, reviews:387,
    specialties:['LASIK','SMILE','PRK','Crosslinking'], waitDays:5,
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
    desc:'מרכז הלייזר המוביל של ירושלים. ציוד Zeiss VisuMax דור אחרון, צוות מומחים עם 15+ שנות ניסיון.',
  },
  {
    id:'azrieli_tlv', name:'עזריאלי — תל אביב', city:'תל אביב', icon:'🏙️',
    address:'דרך מנחם בגין 132, תל אביב', rating:4.8, reviews:521,
    specialties:['LASIK','SMILE','PRK','Wavefront'], waitDays:4,
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
    desc:'קליניקה פרמיום במגדלי עזריאלי. טכנולוגיה מתקדמת, עיצוב יוקרתי, חוויית מטופל ברמה עולמית.',
  },
  {
    id:'hutzot_hamifratz', name:'חוצות המפרץ — חיפה', city:'חיפה', icon:'⚓',
    address:'גרנד קניון, חיפה', rating:4.7, reviews:298,
    specialties:['LASIK','PRK','SMILE'], waitDays:6,
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
    desc:'מרכז הלייזר המוביל בצפון. נגיש, מקצועי, עם זמני המתנה קצרים וצוות חם ומסור.',
  },
  {
    id:'sheva_einayim', name:'שבע עיניים — באר שבע', city:'באר שבע', icon:'🌵',
    address:'קניון הנגב, באר שבע', rating:4.8, reviews:214,
    specialties:['LASIK','PRK','Crosslinking'], waitDays:3,
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
    desc:'מרכז הלייזר היחיד בדרום — מענה מלא לתושבי הנגב. זמני המתנה קצרים, שירות אישי ומסור.',
  },
];

const DOCTORS = [
  {
    id:'shaare_doc1', name:'ד"ר יונתן ברק', title:'מנהל רפואי — שערי העיר ירושלים',
    clinic:'shaare_yerushalayim', avatar:'👨‍⚕️', rating:4.9, surgeries:4600,
    experience:24, specialty:'LASIK, SMILE, קרניות',
    education:['MD — האוניברסיטה העברית הדסה','Fellowship — Moorfields Eye Hospital, London','פרופסור חבר — הדסה'],
    languages:['עברית','אנגלית','צרפתית'],
    bio:'מנהל רפואי ומנתח עיניים בכיר עם ניסיון של 24 שנה. מומחה ב-SMILE ו-LASIK Wavefront. פרסם מעל 50 מאמרים מדעיים ומרצה בינלאומי.',
    badges:['4600+ SURGERIES','PROFESSOR','SMILE EXPERT','INTERNATIONAL SPEAKER'],
    availableDays:['ראשון','שלישי','חמישי'],
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
  },
  {
    id:'shaare_doc2', name:'ד"ר אמיר שלום', title:'מנתח עיניים בכיר — שערי העיר',
    clinic:'shaare_yerushalayim', avatar:'👨‍⚕️', rating:4.8, surgeries:2900,
    experience:17, specialty:'SMILE, LASIK Wavefront, אסטיגמציה',
    education:['MD — אוניברסיטת בר אילן','Fellowship — כירורגיה רפרקטיבית, ניו יורק'],
    languages:['עברית','אנגלית','ערבית'],
    bio:'מומחה ב-SMILE ו-LASIK Wavefront. ידוע בגישתו הרגועה ובסבלנות עם מטופלים. ניסיון עשיר עם מספרים גבוהים ואסטיגמציה מורכבת.',
    badges:['SMILE EXPERT','HIGH MYOPIA','PATIENT CHOICE'],
    availableDays:['שני','רביעי','חמישי'],
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
  },
  {
    id:'shaare_doc3', name:'ד"ר תמר גולן', title:'רופאת עיניים — שערי העיר ירושלים',
    clinic:'shaare_yerushalayim', avatar:'👩‍⚕️', rating:4.8, surgeries:2100,
    experience:13, specialty:'PRK, LASIK, ניתוחי עדשות',
    education:['MD — הטכניון, חיפה','Residency — שיבא תל השומר'],
    languages:['עברית','אנגלית','רוסית'],
    bio:'מתמחה ב-PRK ומתאימה במיוחד למטופלים שאינם מועמדים ל-LASIK. ידועה בתשומת לב לפרטים ובדיוק גבוה. מומחית בטיפול בעיניים יבשות לפני ואחרי ניתוח.',
    badges:['PRK SPECIALIST','DRY EYE EXPERT','PRECISION'],
    availableDays:['ראשון','שלישי','שישי'],
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
  },
  {
    id:'azrieli_doc1', name:'ד"ר רוני אלון', title:'מנהל קליניקת עזריאלי תל אביב',
    clinic:'azrieli_tlv', avatar:'👨‍⚕️', rating:4.9, surgeries:5100,
    experience:23, specialty:'LASIK, SMILE, Phakic IOL',
    education:['MD — אוניברסיטת תל אביב','Fellowship — Bascom Palmer Eye Institute, Miami','פרופסור — סגל הרפואה, ת"א'],
    languages:['עברית','אנגלית','ספרדית'],
    bio:'מבכירי רופאי הלייזר בישראל עם 5,100 ניתוחים מוצלחים. מנהל קליניקת עזריאלי. מומחה בינלאומי ב-Phakic IOL למקרים שאינם מתאימים ללייזר. מדורג בעשירייה הראשונה בישראל.',
    badges:['5100+ SURGERIES','TOP 10 ISRAEL','PHAKIC IOL EXPERT','PROFESSOR'],
    availableDays:['ראשון','שני','שלישי','רביעי'],
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
  },
  {
    id:'azrieli_doc2', name:'ד"ר שירה כהן-לוי', title:'רופאה בכירה — עזריאלי תל אביב',
    clinic:'azrieli_tlv', avatar:'👩‍⚕️', rating:4.9, surgeries:2500,
    experience:14, specialty:'SMILE, LASIK Wavefront, Crosslinking',
    education:['MD — האוניברסיטה העברית','Fellowship — SMILE Surgery, Carl Zeiss Germany','PhD — ביולוגיה של הקרנית'],
    languages:['עברית','אנגלית','גרמנית'],
    bio:'מומחית ב-SMILE ו-Crosslinking. בעלת PhD בביולוגיה של הקרנית. אחת הרופאות הצעירות שקיבלו הסמכת SMILE מ-Carl Zeiss באירופה. תוצאות מעולות ועקביות.',
    badges:['SMILE CERTIFIED','CROSSLINKING EXPERT','PHD CORNEA'],
    availableDays:['שני','שלישי','חמישי'],
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
  },
  {
    id:'katz_haifa', name:'ד"ר אורית כץ', title:'מנהלת — חוצות המפרץ חיפה',
    clinic:'hutzot_hamifratz', avatar:'👩‍⚕️', rating:4.8, surgeries:3600,
    experience:20, specialty:'LASIK, SMILE, PRK',
    education:['MD — הטכניון, חיפה','Fellowship — Keck School of Medicine, LA'],
    languages:['עברית','אנגלית','רוסית'],
    bio:'מנהלת ומייסדת חוצות המפרץ. מובילת ניתוחי לייזר בצפון הארץ כבר 20 שנה. מוכרת בגישתה האמפטית ובתוצאות יציבות לטווח ארוך.',
    badges:['NORTH ISRAEL LEADER','20 YEARS EXPERIENCE','PATIENT FAVORITE'],
    availableDays:['ראשון','שני','רביעי','חמישי'],
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
  },
  {
    id:'mansour_haifa', name:"ד\"ר ג'ורג' מנסור", title:'רופא עיניים בכיר — חוצות המפרץ',
    clinic:'hutzot_hamifratz', avatar:'👨‍⚕️', rating:4.7, surgeries:2400,
    experience:16, specialty:'LASIK, Wavefront, אסטיגמציה',
    education:["MD — אוניברסיטת חיפה","Residency — רמב\"ם, חיפה"],
    languages:['עברית','ערבית','אנגלית'],
    bio:'מומחה לניתוחי לייזר עם ניסיון עשיר באסטיגמציה מורכבת. משרת מטופלים מכל רחבי הצפון והמרכז. ידוע בסבלנות ובהסבר מפורט לפני הניתוח.',
    badges:['ASTIGMATISM EXPERT','ARABIC SPEAKING','DETAILED CARE'],
    availableDays:['ראשון','שלישי','חמישי'],
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
  },
  {
    id:'ben_david_bs', name:'ד"ר נועה בן-דוד', title:'מנהלת — שבע עיניים באר שבע',
    clinic:'sheva_einayim', avatar:'👩‍⚕️', rating:4.9, surgeries:2800,
    experience:17, specialty:'LASIK, PRK, Crosslinking',
    education:["MD — אוניברסיטת בן גוריון בנגב","Fellowship — Wilmer Eye Institute, Johns Hopkins"],
    languages:['עברית','אנגלית'],
    bio:'מייסדת ומנהלת שבע עיניים. בוגרת Johns Hopkins — מביאה ידע ברמה עולמית לנגב. מחויבת לנגישות שירות רפואי ברמה הגבוהה ביותר לתושבי הדרום.',
    badges:['JOHNS HOPKINS FELLOW','NEGEV PIONEER','CROSSLINKING EXPERT'],
    availableDays:['ראשון','שני','רביעי'],
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
  },
  {
    id:'peretz_bs', name:'ד"ר אייל פרץ', title:'רופא עיניים בכיר — שבע עיניים',
    clinic:'sheva_einayim', avatar:'👨‍⚕️', rating:4.7, surgeries:1900,
    experience:12, specialty:'LASIK, PRK, יובש עיניים',
    education:["MD — אוניברסיטת בן גוריון","Residency — סורוקה, באר שבע"],
    languages:['עברית','אנגלית','אמהרית'],
    bio:'ילד הנגב — רופא עיניים מקומי שחזר לשרת את הקהילה שלו. מומחה בטיפול ביובש עיניים לפני ואחרי ניתוח. גישה אישית וחמה, נגיש תמיד לשאלות.',
    badges:['DRY EYE SPECIALIST','LOCAL HERO','PERSONAL CARE'],
    availableDays:['שני','שלישי','חמישי'],
    hmoAffiliation:['clalit','maccabi','meuhedet','leumit'],
  },
];

function ClinicScreen({ hmo, onNext, onBack }) {
  const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState('all');
  const hmoObj = HMO_LIST.find(h=>h.id===hmo);
  const cities = ['all','תל אביב','רמת גן','ירושלים','חיפה'];
  const filtered = CLINICS.filter(c => {
    if(filter!=='all' && c.city!==filter) return false;
    return true;
  });
  const isAffiliated = (c) => c.hmoAffiliation.includes('all') || (hmo && c.hmoAffiliation.includes(hmo));
  return (
    <Shell title="בחר מרפאה" subtitle="שלב 2 מתוך 5">
      <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem', paddingBottom:'2rem' }}>
        <div style={{ display:'flex', alignItems:'center', gap:'.75rem', marginBottom:'1rem' }}>
          <button onClick={onBack} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.85rem', padding:0 }}>← חזור</button>
          <div>
            <div style={{ color:C.cyan, fontSize:'.65rem', fontWeight:700, letterSpacing:'.2em' }}>שלב 2 מתוך 4</div>
            <div style={{ color:C.white, fontWeight:800, fontSize:'1rem' }}>🏥 בחר מרפאה</div>
          </div>
        </div>
        {hmoObj && (
          <div style={{ background:`${C.cyan}0a`, border:`1px solid ${C.cyan}22`, borderRadius:'.875rem', padding:'.6rem 1rem', marginBottom:'.875rem', display:'flex', alignItems:'center', gap:'.5rem' }}>
            <span>{hmoObj.logo}</span>
            <span style={{ color:C.mutedLight, fontSize:'.78rem' }}>מרפאות מסומנות ב-✓ מכבדות את {hmoObj.name}</span>
          </div>
        )}
        <div style={{ display:'flex', gap:'.4rem', overflowX:'auto', paddingBottom:'.5rem', marginBottom:'.875rem' }}>
          {cities.map(c=>(
            <button key={c} onClick={()=>setFilter(c)} style={{ flexShrink:0, padding:'.35rem .875rem', background:filter===c?C.cyan:`${C.cyan}10`, border:`1px solid ${filter===c?C.cyan:`${C.cyan}30`}`, borderRadius:'2rem', color:filter===c?C.bg:C.mutedLight, fontFamily:'Heebo,sans-serif', fontSize:'.75rem', fontWeight:filter===c?700:400, cursor:'pointer', transition:'all .12s' }}>
              {c==='all'?'הכל':c}
            </button>
          ))}
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:'.75rem', flex:1 }}>
          {filtered.map(clinic=>{
            const affiliated = isAffiliated(clinic);
            const isSel = selected===clinic.id;
            return (
              <div key={clinic.id} onClick={()=>setSelected(clinic.id)} style={{ background:isSel?'rgba(56,189,248,.15)':'rgba(255,255,255,.07)', border:`${isSel?2:1}px solid ${isSel?C.cyan:'rgba(255,255,255,.15)'}`, borderRadius:'1rem', padding:'1rem', cursor:'pointer', transition:'all .13s', boxShadow:isSel?`0 0 16px ${C.cyanGlow}`:'none' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:'.5rem' }}>
                  <div style={{ display:'flex', gap:'.75rem', alignItems:'center' }}>
                    <div style={{ width:42, height:42, borderRadius:'.75rem', background:`${C.cyan}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.3rem', border:`1px solid ${C.cyan}30`, flexShrink:0 }}>{clinic.icon}</div>
                    <div>
                      <div style={{ color:isSel?C.white:C.text, fontWeight:700, fontSize:'.95rem' }}>{clinic.name}</div>
                      <div style={{ color:C.muted, fontSize:'.72rem' }}>📍 {clinic.address}</div>
                    </div>
                  </div>
                  <div style={{ textAlign:'left', flexShrink:0 }}>
                    <div style={{ color:C.yellow, fontSize:'.78rem', fontWeight:700 }}>★ {clinic.rating}</div>
                    <div style={{ color:C.muted, fontSize:'.65rem' }}>{clinic.reviews} ביקורות</div>
                  </div>
                </div>
                <div style={{ color:C.mutedLight, fontSize:'.78rem', lineHeight:1.5, marginBottom:'.6rem' }}>{clinic.desc}</div>
                <div style={{ display:'flex', gap:'.4rem', flexWrap:'wrap', alignItems:'center' }}>
                  {clinic.specialties.map((s,i)=>(
                    <span key={i} style={{ padding:'.18rem .55rem', background:`${C.purple}12`, border:`1px solid ${C.purple}30`, borderRadius:'.4rem', color:C.purple, fontSize:'.68rem' }}>{s}</span>
                  ))}
                  <span style={{ marginRight:'auto', color:C.mutedLight, fontSize:'.7rem' }}>⏳ המתנה: {clinic.waitDays} ימים</span>
                  {affiliated && <span style={{ padding:'.18rem .55rem', background:`${C.green}15`, border:`1px solid ${C.green}35`, borderRadius:'.4rem', color:C.green, fontSize:'.68rem', fontWeight:700 }}>✓ {hmoObj?.name||'קופה'}</span>}
                </div>
              </div>
            );
          })}
        </div>
        <div style={{ paddingTop:'1.25rem' }}>
          <button className="hover-lift" disabled={!selected} onClick={()=>onNext(selected)} style={{ width:'100%', padding:'1rem', background:selected?C.cyan:'#131f2e', color:selected?C.bg:C.muted, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:selected?'pointer':'not-allowed', fontFamily:'Heebo,sans-serif', fontSize:'.95rem', transition:'all .2s', boxShadow:selected?`0 0 20px ${C.cyanGlow}`:'none' }}>
            המשך לבחירת רופא ←
          </button>
        </div>
      </div>
      <BottomNav onHome={()=>onBack&&onBack()} onChat={()=>{}} onPostOp={()=>{}} active={null}/>
    </Shell>
  );
}

function DoctorScreen({ clinicId, hmo, answers, onNext, onBack }) {
  const [tab, setTab] = useState('choose'); // choose | recommend | profile
  const [selected, setSelected] = useState(null);
  const [viewProfile, setViewProfile] = useState(null);
  const [aiRec, setAiRec] = useState(null);
  const [loadingRec, setLoadingRec] = useState(false);
  const clinic = CLINICS.find(c=>c.id===clinicId);
  const clinicDoctors = DOCTORS.filter(d=>d.clinic===clinicId);
  const allDoctors = clinicId ? clinicDoctors : DOCTORS;
  const hmoObj = HMO_LIST.find(h=>h.id===hmo);

  const getAiRecommendation = async () => {
    setLoadingRec(true); setTab('recommend');
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages",{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
        model:'claude-sonnet-4-20250514', max_tokens:500,
        system:'אתה יועץ רפואי ממליץ על רופאי עיניים. ענה בעברית, קצר וברור. החזר JSON בלבד: {"doctorId":"...","reason":"2 משפטים למה זה הרופא הכי מתאים","keyFactor":"הגורם המכריע"}',
        messages:[{role:'user',content:`עזור לבחור רופא עיניים לניתוח לייזר.\nשאלון: ${JSON.stringify(answers||{})}\nקופה: ${hmoObj?.name||'לא צוין'}\nמרפאה: ${clinic?.name||'כל המרפאות'}\nרופאים זמינים: ${JSON.stringify(allDoctors.map(d=>({id:d.id,name:d.name,specialty:d.specialty,experience:d.experience,surgeries:d.surgeries})))}`}]
      })});
      const data = await res.json();
      const txt = data.content?.find?.(b=>b.type==='text')?.text||'{}';
      const parsed = JSON.parse(txt.replace(/```json|```/g,'').trim());
      setAiRec(parsed);
      setSelected(parsed.doctorId);
    } catch(e) {
      setAiRec({ doctorId: allDoctors[0]?.id, reason:'ד"ר כהן הוא המנוסה ביותר עם 5,100 ניתוחים ומתאים לפרופיל שלך.', keyFactor:'ניסיון וזמינות' });
      setSelected(allDoctors[0]?.id);
    }
    setLoadingRec(false);
  };

  const ProfileCard = ({ doc }) => (
    <div style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1.1rem', padding:'1.25rem' }}>
      <div style={{ display:'flex', gap:'1rem', alignItems:'flex-start', marginBottom:'1rem' }}>
        <div style={{ width:64, height:64, borderRadius:'50%', background:`${C.purple}18`, border:`2px solid ${C.purple}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'2rem', flexShrink:0 }}>{doc.avatar}</div>
        <div style={{ flex:1 }}>
          <div style={{ color:C.white, fontWeight:800, fontSize:'1.05rem' }}>{doc.name}</div>
          <div style={{ color:C.cyan, fontSize:'.75rem', marginTop:'.1rem' }}>{doc.title}</div>
          <div style={{ display:'flex', alignItems:'center', gap:'.4rem', marginTop:'.3rem' }}>
            <span style={{ color:C.yellow, fontSize:'.78rem' }}>★ {doc.rating}</span>
            <span style={{ color:C.muted, fontSize:'.72rem' }}>·</span>
            <span style={{ color:C.mutedLight, fontSize:'.72rem' }}>{doc.surgeries.toLocaleString()} ניתוחים</span>
            <span style={{ color:C.muted, fontSize:'.72rem' }}>·</span>
            <span style={{ color:C.mutedLight, fontSize:'.72rem' }}>{doc.experience} שנות ניסיון</span>
          </div>
        </div>
      </div>
      <div style={{ display:'flex', gap:'.35rem', flexWrap:'wrap', marginBottom:'.875rem' }}>
        {doc.badges.map((b,i)=>(
          <span key={i} style={{ padding:'.2rem .6rem', background:`${C.cyan}12`, border:`1px solid ${C.cyan}30`, borderRadius:'.4rem', color:C.cyan, fontSize:'.65rem', fontWeight:700 }}>{b}</span>
        ))}
      </div>
      <p style={{ color:C.mutedLight, fontSize:'.82rem', lineHeight:1.6, margin:'0 0 .875rem' }}>{doc.bio}</p>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.5rem', marginBottom:'.875rem' }}>
        <div style={{ background:'rgba(255,255,255,.07)', borderRadius:'.6rem', padding:'.55rem .7rem' }}>
          <div style={{ color:C.muted, fontSize:'.65rem', marginBottom:'.2rem' }}>התמחות</div>
          <div style={{ color:C.text, fontSize:'.78rem', fontWeight:600 }}>{doc.specialty}</div>
        </div>
        <div style={{ background:'rgba(255,255,255,.07)', borderRadius:'.6rem', padding:'.55rem .7rem' }}>
          <div style={{ color:C.muted, fontSize:'.65rem', marginBottom:'.2rem' }}>שפות</div>
          <div style={{ color:C.text, fontSize:'.78rem', fontWeight:600 }}>{doc.languages.join(', ')}</div>
        </div>
      </div>
      <div style={{ background:`${C.purple}08`, border:`1px solid ${C.purple}22`, borderRadius:'.875rem', padding:'.75rem .875rem', marginBottom:'.875rem' }}>
        <div style={{ color:C.purple, fontSize:'.72rem', fontWeight:700, marginBottom:'.4rem' }}>🎓 השכלה והכשרה</div>
        {doc.education.map((e,i)=>(
          <div key={i} style={{ color:C.mutedLight, fontSize:'.78rem', marginBottom:'.2rem' }}>• {e}</div>
        ))}
      </div>
      <div>
        <div style={{ color:C.cyan, fontSize:'.72rem', fontWeight:700, marginBottom:'.4rem' }}>📅 ימי קבלה</div>
        <div style={{ display:'flex', gap:'.4rem', flexWrap:'wrap' }}>
          {doc.availableDays.map((d,i)=>(
            <span key={i} style={{ padding:'.2rem .6rem', background:`${C.green}12`, border:`1px solid ${C.green}30`, borderRadius:'.4rem', color:C.green, fontSize:'.72rem' }}>{d}</span>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <Shell title="בחר רופא" subtitle="שלב 3 מתוך 5">
      <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem', paddingBottom:'2rem' }}>
        <div style={{ display:'flex', alignItems:'center', gap:'.75rem', marginBottom:'1rem' }}>
          <button onClick={viewProfile?()=>setViewProfile(null):onBack} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.85rem', padding:0 }}>← {viewProfile?'חזור':'חזור'}</button>
          <div>
            <div style={{ color:C.purple, fontSize:'.65rem', fontWeight:700, letterSpacing:'.2em' }}>שלב 3 מתוך 4</div>
            <div style={{ color:C.white, fontWeight:800, fontSize:'1rem' }}>👨‍⚕️ {viewProfile?viewProfile.name:'בחר רופא'}</div>
          </div>
        </div>

        {clinic && !viewProfile && (
          <div style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', padding:'.65rem 1rem', marginBottom:'.875rem', display:'flex', gap:'.6rem', alignItems:'center' }}>
            <span style={{ fontSize:'1.1rem' }}>{clinic.icon}</span>
            <div style={{ flex:1 }}>
              <span style={{ color:C.text, fontWeight:600, fontSize:'.85rem' }}>{clinic.name}</span>
              <span style={{ color:C.muted, fontSize:'.72rem' }}> · {clinic.city}</span>
            </div>
            <button onClick={onBack} style={{ background:'none', border:'none', color:C.cyan, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.72rem', padding:0, textDecoration:'underline' }}>שנה</button>
          </div>
        )}

        {viewProfile ? (
          <>
            <ProfileCard doc={viewProfile}/>
            <div style={{ paddingTop:'1rem', display:'flex', gap:'.7rem' }}>
              <button className="hover-lift" onClick={()=>setViewProfile(null)} style={{ flex:1, padding:'.875rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', color:C.mutedLight, cursor:'pointer', fontFamily:'Heebo,sans-serif' }}>← חזור</button>
              <button className="hover-lift" onClick={()=>{ setSelected(viewProfile.id); setViewProfile(null); }} style={{ flex:2, padding:'.875rem', background:C.purple, color:C.white, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', boxShadow:`0 0 16px ${C.purple}44` }}>בחר רופא זה ←</button>
            </div>
          </>
        ) : (
          <>
            <div style={{ display:'flex', background:'rgba(255,255,255,0.09)', borderRadius:'.875rem', padding:'.25rem', border:`1px solid ${C.cardBorder}`, marginBottom:'.875rem' }}>
              {[{id:'choose',label:'🩺 בחר בעצמך'},{id:'recommend',label:'🤖 המלצת AI'}].map(t=>(
                <button key={t.id} onClick={()=>{ setTab(t.id); if(t.id==='recommend'&&!aiRec) getAiRecommendation(); }} style={{ flex:1, padding:'.6rem', background:tab===t.id?'rgba(255,255,255,.15)':'transparent', border:tab===t.id?'1px solid rgba(255,255,255,.2)':'1px solid transparent', borderRadius:'.65rem', color:tab===t.id?C.text:C.muted, fontFamily:'Heebo,sans-serif', fontWeight:tab===t.id?700:400, fontSize:'.82rem', cursor:'pointer', transition:'all .15s' }}>
                  {t.label}
                </button>
              ))}
            </div>

            {tab==='recommend' && (
              loadingRec ? (
                <div style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:'1rem', padding:'2rem' }}>
                  <div style={{ position:'relative', width:80, height:80 }}>
                    <div style={{ position:'absolute', inset:0, borderRadius:'50%', border:`3px solid ${C.purple}22` }}/>
                    <div style={{ position:'absolute', inset:0, borderRadius:'50%', border:'3px solid transparent', borderTopColor:C.purple, animation:'spin 1s linear infinite' }}/>
                    <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.5rem' }}>🤖</div>
                  </div>
                  <div style={{ color:C.purple, fontWeight:700 }}>מנתח פרופיל...</div>
                  <div style={{ color:C.muted, fontSize:'.82rem', textAlign:'center' }}>מתאים רופא לפי הבדיקות, הקופה והמרפאה</div>
                </div>
              ) : aiRec && (
                <div style={{ display:'flex', flexDirection:'column', gap:'.75rem' }}>
                  <div style={{ background:`${C.purple}0d`, border:`2px solid ${C.purple}44`, borderRadius:'1rem', padding:'1rem' }}>
                    <div style={{ color:C.purple, fontSize:'.72rem', fontWeight:700, marginBottom:'.5rem', letterSpacing:'.1em' }}>🤖 המלצת AI</div>
                    <div style={{ color:C.text, fontSize:'.88rem', lineHeight:1.55, marginBottom:'.5rem' }}>{aiRec.reason}</div>
                    <div style={{ display:'flex', alignItems:'center', gap:'.4rem' }}>
                      <span style={{ padding:'.2rem .65rem', background:`${C.green}15`, border:`1px solid ${C.green}35`, borderRadius:'.5rem', color:C.green, fontSize:'.7rem', fontWeight:700 }}>⚡ {aiRec.keyFactor}</span>
                    </div>
                  </div>
                  {DOCTORS.filter(d=>d.id===aiRec.doctorId).map(doc=>(
                    <div key={doc.id}>
                      <ProfileCard doc={doc}/>
                      <div style={{ paddingTop:'.875rem', display:'flex', gap:'.65rem' }}>
                        <button onClick={()=>setViewProfile(doc)} style={{ flex:1, padding:'.875rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', color:C.mutedLight, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.85rem' }}>רזומה מלא</button>
                        <button className="hover-lift" onClick={()=>onNext(doc.id)} style={{ flex:2, padding:'.875rem', background:C.purple, color:C.white, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', boxShadow:`0 0 16px ${C.purple}44` }}>בחר רופא זה ←</button>
                      </div>
                    </div>
                  ))}
                  <button onClick={()=>setTab('choose')} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.8rem', textDecoration:'underline', textAlign:'center', padding:'.5rem' }}>בחר רופא אחר בעצמי</button>
                </div>
              )
            )}

            {tab==='choose' && (
              <div style={{ display:'flex', flexDirection:'column', gap:'.7rem' }}>
                {allDoctors.map(doc=>{
                  const isSel = selected===doc.id;
                  const docClinic = CLINICS.find(c=>c.id===doc.clinic);
                  return (
                    <div key={doc.id} onClick={()=>setSelected(doc.id)} style={{ background:isSel?'rgba(167,139,250,.15)':'rgba(255,255,255,.07)', border:`${isSel?2:1}px solid ${isSel?C.purple:'rgba(255,255,255,.15)'}`, borderRadius:'1rem', padding:'1rem', cursor:'pointer', transition:'all .13s', boxShadow:isSel?`0 0 14px ${C.purple}33`:'none' }}>
                      <div style={{ display:'flex', gap:'.875rem', alignItems:'center' }}>
                        <div style={{ width:52, height:52, borderRadius:'50%', background:`${C.purple}18`, border:`2px solid ${isSel?C.purple:`${C.purple}33`}`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.5rem', flexShrink:0 }}>{doc.avatar}</div>
                        <div style={{ flex:1 }}>
                          <div style={{ color:isSel?C.white:C.text, fontWeight:700, fontSize:'.95rem' }}>{doc.name}</div>
                          <div style={{ color:C.cyan, fontSize:'.72rem' }}>{doc.specialty}</div>
                          <div style={{ display:'flex', gap:'.5rem', alignItems:'center', marginTop:'.2rem' }}>
                            <span style={{ color:C.yellow, fontSize:'.75rem' }}>★ {doc.rating}</span>
                            <span style={{ color:C.muted, fontSize:'.68rem' }}>·</span>
                            <span style={{ color:C.mutedLight, fontSize:'.72rem' }}>{doc.surgeries.toLocaleString()} ניתוחים</span>
                            {!clinicId && docClinic && <span style={{ color:C.muted, fontSize:'.68rem' }}>· {docClinic.name}</span>}
                          </div>
                        </div>
                        <button onClick={e=>{e.stopPropagation();setViewProfile(doc);}} style={{ padding:'.35rem .75rem', background:`${C.cyan}12`, border:`1px solid ${C.cyan}30`, borderRadius:'.5rem', color:C.cyan, fontSize:'.72rem', cursor:'pointer', fontFamily:'Heebo,sans-serif', flexShrink:0 }}>רזומה</button>
                      </div>
                      {isSel && (
                        <div style={{ marginTop:'.65rem', paddingTop:'.65rem', borderTop:`1px solid ${C.purple}22`, display:'flex', gap:'.4rem', flexWrap:'wrap' }}>
                          {doc.badges.slice(0,3).map((b,i)=>(
                            <span key={i} style={{ padding:'.18rem .55rem', background:`${C.purple}12`, border:`1px solid ${C.purple}30`, borderRadius:'.4rem', color:C.purple, fontSize:'.65rem', fontWeight:700 }}>{b}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {tab==='choose' && (
              <div style={{ paddingTop:'1.25rem' }}>
                <button className="hover-lift" disabled={!selected} onClick={()=>onNext(selected)} style={{ width:'100%', padding:'1rem', background:selected?C.purple:'#131f2e', color:selected?C.white:C.muted, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:selected?'pointer':'not-allowed', fontFamily:'Heebo,sans-serif', fontSize:'.95rem', transition:'all .2s', boxShadow:selected?`0 0 20px ${C.purple}44`:'none' }}>
                  המשך לשאלון ←
                </button>
                <button onClick={()=>onNext('any')} style={{ width:'100%', marginTop:'.65rem', padding:'.75rem', background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.8rem', textDecoration:'underline' }}>
                  אין העדפה — האפליקציה תמליץ
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </Shell>
  );
}

function HmoScreen({ name, onNext }) {
  const [selected, setSelected] = useState(null);
  return (
  <Shell center title="קופת חולים">
  <div dir="rtl" style={{ width:'100%', maxWidth:400, padding:'2rem' }}>
  <div className="fu0" style={{ textAlign:'center', marginBottom:'2rem' }}>
  <div style={{ fontSize:'3rem', marginBottom:'.75rem' }}>🏥</div>
  <h2 style={{ color:C.white, fontSize:'1.7rem', fontWeight:800, margin:0 }}>שלום, {name}!</h2>
  <p style={{ color:C.mutedLight, margin:'.5rem 0 0' }}>באיזו קופת חולים אתה חבר?</p>
  <p style={{ color:C.muted, fontSize:'.78rem', margin:'.3rem 0 0' }}>נשתמש בזה לחישוב ההנחה המתאימה לך</p>
  </div>
  <div className="fu1" style={{ display:'flex', flexDirection:'column', gap:'.75rem', marginBottom:'1.5rem' }}>
  {HMO_LIST.map(h=>(
  <div key={h.id} onClick={()=>setSelected(h.id)} style={{ display:'flex', alignItems:'center', gap:'1rem', padding:'1rem 1.25rem', background:selected===h.id?`rgba(6,182,212,0.12)`:C.card, border:`${selected===h.id?2:1}px solid ${selected===h.id?C.cyan:C.cardBorder}`, borderRadius:'1rem', cursor:'pointer', transition:'all .15s' }}>
  <div style={{ width:44, height:44, borderRadius:'.75rem', background:`${h.color}22`, border:`1.5px solid ${h.color}55`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.3rem' }}>{h.logo}</div>
  <div style={{ flex:1 }}>
  <div style={{ color:selected===h.id?C.white:C.text, fontWeight:700, fontSize:'1rem' }}>{h.name}</div>
  <div style={{ color:C.muted, fontSize:'.75rem' }}>
  {selected===h.id ? `✓ נבחר — הנחה עד ${Math.max(...PRICE_PACKAGES.map(p=>p.hmoDiscount[h.id]))}%` : `הנחה עד ${Math.max(...PRICE_PACKAGES.map(p=>p.hmoDiscount[h.id]))}% על ניתוח לייזר`}
  </div>
  </div>
  {selected===h.id && <div style={{ width:20, height:20, borderRadius:'50%', background:C.cyan, display:'flex', alignItems:'center', justifyContent:'center', color:C.bg, fontSize:'.75rem', fontWeight:900 }}>✓</div>}
  </div>
  ))}
  </div>
  <div className="fu2" style={{ display:'flex', flexDirection:'column', gap:'.65rem' }}>
  <button className="hover-lift" disabled={!selected} onClick={()=>onNext(selected)} style={{ width:'100%', padding:'1rem', background:selected?C.cyan:'#131f2e', color:selected?C.bg:C.muted, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:selected?'pointer':'not-allowed', fontFamily:'Heebo,sans-serif', fontSize:'1rem', transition:'all .2s', boxShadow:selected?`0 0 20px ${C.cyanGlow}`:'none' }}>
  המשך לשאלון ←
  </button>
  <button onClick={()=>onNext('none')} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.82rem', textDecoration:'underline' }}>
  אינני חבר בקופת חולים / דלג
  </button>
  </div>
  </div>
  </Shell>
  );
}

function SurgerySchedulerScreen({ patientName, pkg, finalPrice, hmoObj, onBack, onConfirmed }) {
  const today = new Date();
  const [viewMonth, setViewMonth] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [confirmed, setConfirmed] = useState(false);
  const [saving, setSaving] = useState(false);
  const TIME_SLOTS = ['08:00','10:00','12:00','14:00','16:00'];
  const daysInMonth = (y, m) => new Date(y, m+1, 0).getDate();
  const firstDayOfMonth = (y, m) => { const d = new Date(y, m, 1).getDay(); return d===0?6:d-1; };
  const isAvailable = (d) => {
  const day = d.getDay();
  const isPast = d < new Date(today.getFullYear(), today.getMonth(), today.getDate());
  return !isPast && day!==5 && day!==6;
  };
  const yr = viewMonth.getFullYear(), mo = viewMonth.getMonth();
  const totalDays = daysInMonth(yr, mo), startPad = firstDayOfMonth(yr, mo);
  const days = [];
  for(let i=0;i<startPad;i++) days.push(null);
  for(let d=1;d<=totalDays;d++) days.push(new Date(yr, mo, d));
  const HEB_MONTHS = ['ינואר','פברואר','מרץ','אפריל','מאי','יוני','יולי','אוגוסט','ספטמבר','אוקטובר','נובמבר','דצמבר'];
  const HEB_DAYS_SHORT = ['ב׳','ג׳','ד׳','ה׳','ו׳','ש׳','א׳'];
  const buildICS = () => {
    const [h,m] = selectedTime.split(':').map(Number);
    const start = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate(), h, m);
    const end = new Date(start.getTime() + 90*60*1000);
    const fmt = d => d.toISOString().replace(/[-:]/g,'').split('.')[0]+'Z';
    const hmoLine = hmoObj ? ('\nקופה: ' + hmoObj.name) : '';
    const desc = 'מטופל: ' + patientName + '\nחבילה: ' + (pkg && pkg.name||'') + '\nמחיר: ₪' + String(finalPrice||'') + hmoLine + '\nמשך: 90 דקות';
    const lines = [
      'BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//OptiScan//IL','BEGIN:VEVENT',
      'DTSTART:'+fmt(start),'DTEND:'+fmt(end),
      'SUMMARY:ניתוח לייזר — '+(pkg && pkg.name||'LASIK'),
      'DESCRIPTION:'+desc,'LOCATION:'+(clinicInfo?.name||'קליניקת OptiScan'),
      'STATUS:CONFIRMED','BEGIN:VALARM','TRIGGER:-PT1H','ACTION:DISPLAY',
      'DESCRIPTION:תזכורת ניתוח לייזר','END:VALARM','END:VEVENT','END:VCALENDAR'
    ];
    return lines.join('\r\n');
  }
  const handleConfirm = () => {
  setSaving(true);
  const blob = new Blob([buildICS()], {type:'text/calendar;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='surgery.ics'; a.click();
  URL.revokeObjectURL(url);
  setTimeout(()=>{ setSaving(false); setConfirmed(true); onConfirmed&&onConfirmed(selectedDate,selectedTime); }, 800);
  };
  const formatDate = d => d?.toLocaleDateString('he-IL',{weekday:'long',day:'numeric',month:'long'});
  if(confirmed) return (
  <Shell center title="תיאום ניתוח">
  <div dir="rtl" style={{ textAlign:'center', padding:'2rem', maxWidth:340 }}>
  <div style={{ fontSize:'4rem', marginBottom:'1rem', animation:'float 3s ease-in-out infinite' }}>✅</div>
  <h2 style={{ color:C.green, fontSize:'1.6rem', fontWeight:900, margin:'0 0 .75rem' }}>הניתוח נקבע!</h2>
  <div style={{ background:'rgba(255,255,255,0.09)', border:`2px solid ${C.green}44`, borderRadius:'1.1rem', padding:'1.25rem', marginBottom:'1.5rem' }}>
  <div style={{ color:C.text, fontWeight:700, fontSize:'1.05rem', marginBottom:'.4rem' }}>{formatDate(selectedDate)}</div>
  <div style={{ color:C.cyan, fontSize:'1.1rem', fontWeight:800 }}>⏰ {selectedTime}</div>
  <div style={{ color:C.muted, fontSize:'.8rem', marginTop:'.4rem' }}>משך: ~90 דקות · קליניקת OptiScan</div>
  </div>
  <div style={{ background:'rgba(34,197,94,.07)', border:'1px solid rgba(34,197,94,.25)', borderRadius:'.875rem', padding:'.875rem', marginBottom:'1.5rem', color:C.mutedLight, fontSize:'.82rem', lineHeight:1.6 }}>
  📅 קובץ יומן הורד למכשירך<br/>פתח אותו להוספה ל-Apple / Google Calendar
  </div>
  <button className="hover-lift" onClick={onBack} style={{ width:'100%', padding:'1rem', background:C.cyan, color:C.bg, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif' }}>חזור לתפריט ראשי</button>
  </div>
  </Shell>
  );
  return (
  <Shell>
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem', paddingBottom:'2rem' }}>
  <div style={{ display:'flex', alignItems:'center', gap:'.75rem', marginBottom:'1.25rem' }}>
  <button onClick={onBack} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.85rem', padding:0 }}>← חזור</button>
  <div><div style={{ color:C.green, fontSize:'.65rem', fontWeight:700, letterSpacing:'.2em' }}>תיאום ניתוח</div><div style={{ color:C.white, fontWeight:800 }}>📅 בחר תאריך ושעה</div></div>
  </div>
  <div style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'.875rem 1rem', marginBottom:'1rem', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
  <div><div style={{ color:C.text, fontWeight:700 }}>{pkg?.icon} {pkg?.name}</div><div style={{ color:C.muted, fontSize:'.73rem' }}>{pkg?.duration} · קליניקת OptiScan</div></div>
  <div style={{ color:C.cyan, fontWeight:800, fontSize:'1.1rem' }}>₪{finalPrice?.toLocaleString()}</div>
  </div>
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'.75rem' }}>
  <button onClick={()=>setViewMonth(new Date(yr,mo-1,1))} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontSize:'1.3rem', padding:'.2rem .5rem' }}>‹</button>
  <div style={{ color:C.white, fontWeight:700 }}>{HEB_MONTHS[mo]} {yr}</div>
  <button onClick={()=>setViewMonth(new Date(yr,mo+1,1))} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontSize:'1.3rem', padding:'.2rem .5rem' }}>›</button>
  </div>
  <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:'.2rem', marginBottom:'.35rem' }}>
  {HEB_DAYS_SHORT.map((d,i)=><div key={i} style={{ textAlign:'center', color:i>=5?'rgba(239,68,68,.4)':C.muted, fontSize:'.68rem', fontWeight:600, padding:'.25rem 0' }}>{d}</div>)}
  </div>
  <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:'.25rem', marginBottom:'1rem' }}>
  {days.map((d,i)=>{
  if(!d) return <div key={`p${i}`}/>;
  const avail=isAvailable(d), isSel=selectedDate&&d.toDateString()===selectedDate.toDateString(), isToday=d.toDateString()===today.toDateString(), isWeekend=d.getDay()===5||d.getDay()===6;
  return <div key={i} onClick={()=>avail&&(setSelectedDate(d),setSelectedTime(null))} style={{ aspectRatio:'1', display:'flex', alignItems:'center', justifyContent:'center', borderRadius:'.6rem', background:isSel?C.cyan:isToday?`${C.cyan}18`:'transparent', border:isSel?`2px solid ${C.cyan}`:isToday?`1px solid ${C.cyan}44`:avail?`1px solid ${C.cardBorder}`:'none', color:isSel?C.bg:!avail||isWeekend?'rgba(255,255,255,.18)':C.text, fontSize:'.85rem', fontWeight:isSel||isToday?700:400, cursor:avail?'pointer':'default', transition:'all .12s', boxShadow:isSel?`0 0 12px ${C.cyanGlow}`:'none' }}>{d.getDate()}</div>;
  })}
  </div>
  {selectedDate && (
  <div style={{ marginBottom:'1rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.6rem', letterSpacing:'.1em' }}>⏰ שעות זמינות — {formatDate(selectedDate)}</div>
  <div style={{ display:'flex', gap:'.6rem', flexWrap:'wrap' }}>
  {TIME_SLOTS.map(t=>{
  const isSel=selectedTime===t;
  return <button key={t} onClick={()=>setSelectedTime(t)} style={{ padding:'.55rem 1rem', background:isSel?C.green:`${C.green}12`, border:`${isSel?2:1}px solid ${isSel?C.green:`${C.green}44`}`, borderRadius:'.75rem', color:isSel?C.bg:C.green, fontFamily:'Heebo,sans-serif', fontWeight:isSel?800:500, fontSize:'.9rem', cursor:'pointer', transition:'all .12s', boxShadow:isSel?`0 0 12px ${C.green}44`:'none' }}>{t}</button>;
  })}
  </div>
  </div>
  )}
  <div style={{ display:'flex', gap:'1rem', marginBottom:'1rem', fontSize:'.72rem', color:C.muted }}>
  <div style={{ display:'flex', alignItems:'center', gap:'.3rem' }}><div style={{ width:12,height:12,borderRadius:'.2rem',background:C.cyan }}/> נבחר</div>
  <div style={{ display:'flex', alignItems:'center', gap:'.3rem' }}><div style={{ width:12,height:12,borderRadius:'.2rem',border:`1px solid ${C.cyan}44` }}/> היום</div>
  <div style={{ display:'flex', alignItems:'center', gap:'.3rem' }}><div style={{ width:12,height:12,borderRadius:'.2rem',background:'rgba(255,255,255,.08)' }}/> לא זמין</div>
  </div>
  <div style={{ marginTop:'auto' }}>
  <button className="hover-lift" disabled={!selectedDate||!selectedTime||saving} onClick={handleConfirm} style={{ width:'100%', padding:'1rem', background:selectedDate&&selectedTime?`linear-gradient(135deg,${C.green},#16a34a)`:'#131f2e', color:selectedDate&&selectedTime?C.white:C.muted, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:selectedDate&&selectedTime?'pointer':'not-allowed', fontFamily:'Heebo,sans-serif', fontSize:'.95rem', transition:'all .2s', boxShadow:selectedDate&&selectedTime?`0 0 20px ${C.green}44`:'none' }}>
  {saving?'⏳ שומר...' : selectedDate&&selectedTime?`📅 אשר ואצור אירוע ביומן — ${selectedDate.getDate()}/${selectedDate.getMonth()+1} ב-${selectedTime}`:'בחר תאריך ושעה'}
  </button>
  <div style={{ textAlign:'center', marginTop:'.75rem', color:C.muted, fontSize:'.73rem', lineHeight:1.5 }}>יורד קובץ .ics — פתח אותו להוספה לApple / Google Calendar</div>
  </div>
  </div>
  </Shell>
  );
}
function PaymentTab({ pkg, finalPrice, hmoObj, discount, selectedPayment, setSelectedPayment, onSchedule, onChat, patientName }) {
  const [payMethod, setPayMethod] = useState('credit'); // credit | bit | transfer | payments | hmo
  const [installments, setInstallments] = useState(12);
  const [paid, setPaid] = useState(false);
  const [processing, setProcessing] = useState(false);

  const METHODS = [
    { id:'credit',    icon:'💳', label:'כרטיס אשראי',   color:C.primary,  detail:'ויזה / מאסטרקארד / אמקס' },
    { id:'bit',       icon:'🟠', label:'Bit',             color:'#ff6b00',  detail:'תשלום מהיר דרך Bit' },
    { id:'paybox',    icon:'🔵', label:'PayBox',          color:'#0066cc',  detail:'תשלום דרך PayBox' },
    { id:'transfer',  icon:'🏦', label:'העברה בנקאית',   color:C.cyan,     detail:'בנק לאומי · 10-900000-11' },
    { id:'payments',  icon:'📅', label:'תשלומים ללא ריבית', color:C.green, detail:'עד 24 תשלומים' },
    { id:'hmo',       icon:'🏥', label:'השתתפות קופה',   color:C.purple,   detail:hmoObj?`עד 30% דרך ${hmoObj.name}`:'בחר קופה בשלב הרישום' },
  ];

  const selectedMethod = METHODS.find(m=>m.id===payMethod);
  const effectivePrice = payMethod==='credit' && installments===1 ? Math.round(finalPrice*0.95) : finalPrice;
  const monthlyAmount = payMethod==='payments' ? Math.round(finalPrice/installments) : null;

  const handlePay = () => {
    setProcessing(true);
    setTimeout(()=>{ setProcessing(false); setPaid(true); }, 2000);
  };

  if (paid) return (
    <div style={{ display:'flex', flexDirection:'column', gap:'.875rem' }}>
      <div style={{ textAlign:'center', padding:'2rem 1rem' }}>
        <div style={{ fontSize:'3.5rem', marginBottom:'1rem', animation:'float 2s ease-in-out infinite' }}>✅</div>
        <div style={{ color:C.green, fontWeight:900, fontSize:'1.3rem', marginBottom:'.5rem' }}>התשלום הושלם!</div>
        <div style={{ color:C.mutedLight, fontSize:'.85rem', lineHeight:1.6, marginBottom:'1.25rem' }}>
          קיבלנו את תשלומך עבור<br/>
          <strong style={{ color:C.white }}>{pkg?.name}</strong> — ₪{effectivePrice.toLocaleString()}<br/>
          אישור נשלח למייל ול-SMS
        </div>
        <button className="hover-lift" onClick={()=>onSchedule&&onSchedule(pkg,finalPrice,hmoObj)} style={{ width:'100%', padding:'1rem', background:'linear-gradient(135deg,#1a5fa8,#0891b2)', color:'#fff', border:'none', borderRadius:'1rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.95rem', boxShadow:'0 4px 18px rgba(26,95,168,0.5)' }}>
          📅 קבע תור לניתוח ←
        </button>
      </div>
    </div>
  );

  return (
    <div dir="rtl" style={{ display:'flex', flexDirection:'column', gap:'.75rem' }}>
      {/* Price summary */}
      <div style={{ background:`${C.cyan}12`, border:`1px solid ${C.cyan}30`, borderRadius:'1rem', padding:'.875rem 1rem', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <div style={{ color:C.cyan, fontSize:'.7rem', fontWeight:700 }}>סה"כ לתשלום</div>
          <div style={{ color:C.white, fontWeight:800, fontSize:'1rem' }}>{pkg?.icon} {pkg?.name}</div>
          {hmoObj && <div style={{ color:C.green, fontSize:'.72rem' }}>הנחת {hmoObj.name} {discount}% — כבר מחושבת</div>}
        </div>
        <div style={{ textAlign:'left' }}>
          {payMethod==='credit' && installments===1 && <div style={{ color:C.muted, fontSize:'.7rem', textDecoration:'line-through' }}>₪{finalPrice.toLocaleString()}</div>}
          <div style={{ color:C.cyan, fontWeight:900, fontSize:'1.5rem' }}>
            {monthlyAmount ? `₪${monthlyAmount.toLocaleString()}` : `₪${effectivePrice.toLocaleString()}`}
          </div>
          {monthlyAmount && <div style={{ color:C.mutedLight, fontSize:'.7rem' }}>× {installments} תשלומים</div>}
          {payMethod==='credit' && installments===1 && <div style={{ color:C.green, fontSize:'.7rem', fontWeight:700 }}>חיסכון ₪{(finalPrice-effectivePrice).toLocaleString()}</div>}
        </div>
      </div>

      {/* Payment methods */}
      <div style={{ color:C.mutedLight, fontSize:'.75rem', fontWeight:700, letterSpacing:'.05em' }}>בחר אמצעי תשלום</div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.5rem' }}>
        {METHODS.map(m=>{
          const isSel = payMethod===m.id;
          return (
            <div key={m.id} onClick={()=>setPayMethod(m.id)} style={{ padding:'.75rem .875rem', background:isSel?`${m.color}18`:'rgba(255,255,255,.07)', border:`${isSel?2:1}px solid ${isSel?m.color:'rgba(255,255,255,.12)'}`, borderRadius:'.875rem', cursor:'pointer', transition:'all .13s', boxShadow:isSel?`0 0 12px ${m.color}33`:'none' }}>
              <div style={{ display:'flex', alignItems:'center', gap:'.5rem', marginBottom:'.25rem' }}>
                <span style={{ fontSize:'1.15rem' }}>{m.icon}</span>
                <span style={{ color:isSel?m.color:C.text, fontWeight:isSel?800:600, fontSize:'.85rem' }}>{m.label}</span>
              </div>
              <div style={{ color:C.muted, fontSize:'.68rem' }}>{m.detail}</div>
              {isSel && <div style={{ width:18, height:18, borderRadius:'50%', background:m.color, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:'.6rem', fontWeight:900, marginTop:'.4rem' }}>✓</div>}
            </div>
          );
        })}
      </div>

      {/* Installments selector */}
      {(payMethod==='credit'||payMethod==='payments') && (
        <div style={{ background:'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.13)', borderRadius:'1rem', padding:'.875rem 1rem' }}>
          <div style={{ color:C.cyan, fontSize:'.72rem', fontWeight:700, marginBottom:'.6rem' }}>מספר תשלומים</div>
          <div style={{ display:'flex', gap:'.5rem' }}>
            {[1,6,12,18,24].map(n=>(
              <button key={n} onClick={()=>setInstallments(n)} style={{ flex:1, padding:'.5rem 0', background:installments===n?C.cyan:'rgba(255,255,255,.08)', border:`1px solid ${installments===n?C.cyan:'rgba(255,255,255,.15)'}`, borderRadius:'.6rem', color:installments===n?C.bg:C.text, fontFamily:'Heebo,sans-serif', fontWeight:installments===n?800:500, fontSize:'.8rem', cursor:'pointer', transition:'all .12s' }}>
                {n===1?'מזומן':n}
              </button>
            ))}
          </div>
          {installments > 1 && (
            <div style={{ marginTop:'.6rem', color:C.mutedLight, fontSize:'.75rem', textAlign:'center' }}>
              ₪{Math.round(finalPrice/installments).toLocaleString()} × {installments} = ₪{finalPrice.toLocaleString()} ללא ריבית
            </div>
          )}
        </div>
      )}

      {/* Transfer details */}
      {payMethod==='transfer' && (
        <div style={{ background:'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.13)', borderRadius:'1rem', padding:'.875rem 1rem' }}>
          <div style={{ color:C.cyan, fontSize:'.72rem', fontWeight:700, marginBottom:'.6rem' }}>🏦 פרטי חשבון בנק</div>
          {[['בנק','לאומי (10)'],['סניף','900'],['חשבון','10-900000-11'],['לפקודת','ד"ר עיני נץ — ניתוחי עיניים'],['סכום',`₪${finalPrice.toLocaleString()}`]].map(([k,v],i)=>(
            <div key={i} style={{ display:'flex', justifyContent:'space-between', padding:'.3rem 0', borderBottom:i<4?'1px solid rgba(255,255,255,.07)':'none' }}>
              <span style={{ color:C.muted, fontSize:'.8rem' }}>{k}</span>
              <span style={{ color:C.text, fontSize:'.8rem', fontWeight:700 }}>{v}</span>
            </div>
          ))}
          <div style={{ marginTop:'.6rem', background:'rgba(251,191,36,.12)', border:'1px solid rgba(251,191,36,.3)', borderRadius:'.5rem', padding:'.5rem .75rem', color:C.yellow, fontSize:'.73rem' }}>
            ⚠️ לאחר ההעברה שלח אישור ל-WhatsApp לאישור התור
          </div>
        </div>
      )}

      {/* Bit / PayBox */}
      {(payMethod==='bit'||payMethod==='paybox') && (
        <div style={{ background:'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.13)', borderRadius:'1rem', padding:'1rem', textAlign:'center' }}>
          <div style={{ fontSize:'2rem', marginBottom:'.5rem' }}>{payMethod==='bit'?'🟠':'🔵'}</div>
          <div style={{ color:C.text, fontWeight:700, marginBottom:'.3rem' }}>{payMethod==='bit'?'תשלום דרך Bit':'תשלום דרך PayBox'}</div>
          <div style={{ color:C.mutedLight, fontSize:'.78rem', marginBottom:'.75rem' }}>מספר טלפון: <strong style={{ color:C.white }}>050-1234567</strong></div>
          <div style={{ color:C.muted, fontSize:'.72rem' }}>לאחר התשלום שלח צילום מסך לאישור</div>
        </div>
      )}

      {/* HMO */}
      {payMethod==='hmo' && (
        <div style={{ background:'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.13)', borderRadius:'1rem', padding:'.875rem 1rem' }}>
          <div style={{ color:C.purple, fontSize:'.72rem', fontWeight:700, marginBottom:'.5rem' }}>🏥 תהליך השתתפות קופה</div>
          <div style={{ display:'flex', flexDirection:'column', gap:'.5rem' }}>
            {['צור קשר עם קופת החולים שלך','בקש טופס השתתפות עצמית לניתוח עיניים','קבל אישור מקדים מהקופה','שלח לנו את האישור ונתאם תור'].map((s,i)=>(
              <div key={i} style={{ display:'flex', gap:'.6rem', alignItems:'center' }}>
                <div style={{ width:20, height:20, borderRadius:'50%', background:`${C.purple}25`, border:`1px solid ${C.purple}45`, display:'flex', alignItems:'center', justifyContent:'center', color:C.purple, fontSize:'.65rem', fontWeight:800, flexShrink:0 }}>{i+1}</div>
                <span style={{ color:C.mutedLight, fontSize:'.78rem' }}>{s}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Pay button */}
      {payMethod !== 'hmo' && (
        <button className="hover-lift" onClick={handlePay} disabled={processing}
          style={{ width:'100%', padding:'1.1rem', background:processing?'rgba(255,255,255,.15)':'linear-gradient(135deg,#16a34a,#15803d)', color:'#fff', border:'none', borderRadius:'1rem', fontWeight:800, cursor:processing?'not-allowed':'pointer', fontFamily:'Heebo,sans-serif', fontSize:'1rem', boxShadow:processing?'none':'0 4px 18px rgba(22,163,74,0.45)', transition:'all .2s', letterSpacing:'.01em' }}>
          {processing ? '⏳ מעבד תשלום...' : `✅ בצע תשלום — ₪${effectivePrice.toLocaleString()}`}
        </button>
      )}
      {payMethod === 'hmo' && (
        <button className="hover-lift" onClick={()=>onChat&&onChat()}
          style={{ width:'100%', padding:'1rem', background:'linear-gradient(135deg,#7c3aed,#6d28d9)', color:'#fff', border:'none', borderRadius:'1rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.95rem', boxShadow:'0 4px 16px rgba(124,58,237,0.4)' }}>
          💬 צור קשר לתיאום השתתפות קופה
        </button>
      )}

      <button className="hover-lift" onClick={()=>onSchedule&&onSchedule(pkg,finalPrice,hmoObj)} style={{ width:'100%', padding:'.85rem', background:'rgba(255,255,255,.08)', border:'1px solid rgba(255,255,255,.15)', color:C.mutedLight, borderRadius:'1rem', cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.88rem' }}>
        📅 תאם ניתוח ביומן קודם (ללא תשלום עכשיו)
      </button>
    </div>
  );
}


function ApprovalScreen({ patientName, hmo, onBack, onChat, onSchedule }) {
  const [tab, setTab] = useState('status'); // status | pricing | payment
  const [selectedPkg, setSelectedPkg] = useState('wavefront');
  const [selectedPayment, setSelectedPayment] = useState('payments');
  const hmoObj = HMO_LIST.find(h=>h.id===hmo) || null;

  // Simulate approval status — in prod this would come from backend
  const [approvalStatus] = useState('approved'); // 'pending' | 'approved' | 'rejected'

  const pkg = PRICE_PACKAGES.find(p=>p.id===selectedPkg);
  const discount = hmoObj ? pkg.hmoDiscount[hmoObj.id] : 0;
  const finalPrice = Math.round(pkg.price * (1 - discount/100));
  const saving = pkg.price - finalPrice;

  const statusConfig = {
  pending: { icon:'⏳', color:C.yellow, label:'ממתין לאישור רופא', sub:'הדוח שלך נשלח לרופא המומחה ויבדק תוך 48 שעות' },
  approved: { icon:'✅', color:C.green, label:'מאושר לניתוח!', sub:'הרופא בדק את תוצאותיך ואישר שאתה מתאים לניתוח לייזר' },
  rejected: { icon:'❌', color:C.red, label:'לא מתאים בשלב זה', sub:'הרופא המליץ על בדיקות נוספות. פנה לייעוץ אישי' },
  };
  const st = statusConfig[approvalStatus];

  return (
  <Shell title="אישור ותמחור">
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem', paddingBottom:'2rem' }}>

  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'1.25rem' }}>
  <button onClick={onBack} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.85rem', padding:0 }}>← ראשי</button>
  <div style={{ textAlign:'center' }}>
  <div style={{ color:C.green, fontSize:'.65rem', fontWeight:700, letterSpacing:'.2em' }}>אישור ותמחור</div>
  <div style={{ color:C.white, fontWeight:800, fontSize:'.95rem' }}>{patientName}</div>
  </div>
  {hmoObj ? <div style={{ textAlign:'left', color:C.muted, fontSize:'.78rem' }}>{hmoObj.logo} {hmoObj.name}</div> : <div/>}
  </div>

  <div style={{ display:'flex', background:'rgba(255,255,255,0.09)', borderRadius:'.875rem', padding:'.3rem', marginBottom:'1.25rem', border:`1px solid ${C.cardBorder}` }}>
  {[{id:'status',label:'סטטוס'},{id:'pricing',label:'תמחור'},{id:'payment',label:'תשלום'}].map(t=>(
  <button key={t.id} className="tab-btn" onClick={()=>setTab(t.id)} style={{ flex:1, padding:'.65rem', background:tab===t.id?'rgba(255,255,255,.15)':'transparent', border:tab===t.id?'1px solid rgba(255,255,255,.2)':'1px solid transparent', borderRadius:'.65rem', color:tab===t.id?C.text:C.muted, fontFamily:'Heebo,sans-serif', fontWeight:tab===t.id?700:400, fontSize:'.85rem', cursor:'pointer' }}>
  {t.label}
  </button>
  ))}
  </div>

  {}
  {tab==='status' && (
  <div style={{ display:'flex', flexDirection:'column', gap:'.875rem' }}>

  <div className="fu0" style={{ background:'rgba(255,255,255,0.09)', border:`2px solid ${st.color}44`, borderRadius:'1.25rem', padding:'1.5rem', textAlign:'center', position:'relative', overflow:'hidden' }}>
  <div style={{ position:'absolute', inset:0, background:`radial-gradient(circle at 50% 0%, ${st.color}0e, transparent 70%)` }}/>
  <div style={{ fontSize:'3.5rem', marginBottom:'.75rem', animation: approvalStatus==='approved'?'float 3s ease-in-out infinite':undefined }}>{st.icon}</div>
  <h2 style={{ color:st.color, fontSize:'1.5rem', fontWeight:900, margin:'0 0 .5rem' }}>{st.label}</h2>
  <p style={{ color:C.mutedLight, margin:0, fontSize:'.88rem', lineHeight:1.55 }}>{st.sub}</p>
  {approvalStatus==='approved' && (
  <div style={{ marginTop:'1rem', padding:'.6rem 1.25rem', background:`${C.green}18`, border:`1px solid ${C.green}44`, borderRadius:'2rem', display:'inline-block', color:C.green, fontSize:'.82rem', fontWeight:700 }}>
  🎉 אתה מתאים לניתוח לייזר!
  </div>
  )}
  </div>

  {approvalStatus==='approved' && (
  <>
  <div className="fu1" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1rem' }}>
  <div style={{ color:C.cyan, fontSize:'.72rem', fontWeight:700, marginBottom:'.75rem', letterSpacing:'.1em' }}>📋 פרטי אישור</div>
  {[
  {l:'רופא מאשר', v:'ד"ר אייל שפירא — רופא עיניים מומחה'},
  {l:'תאריך אישור', v:new Date().toLocaleDateString('he-IL',{day:'numeric',month:'long',year:'numeric'})},
  {l:'תוקף אישור', v:'90 יום מתאריך הבדיקה'},
  {l:'סוג ניתוח מומלץ', v:'LASIK Wavefront Guided'},
  ].map((r,i)=>(
  <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', padding:'.45rem 0', borderBottom:i<3?`1px solid ${C.cardBorder}`:'none' }}>
  <span style={{ color:C.muted, fontSize:'.78rem' }}>{r.l}</span>
  <span style={{ color:C.text, fontSize:'.78rem', fontWeight:600, textAlign:'left', maxWidth:'55%' }}>{r.v}</span>
  </div>
  ))}
  </div>
  <button className="hover-lift" onClick={()=>setTab('pricing')} style={{ width:'100%', padding:'1rem', background:C.green, color:C.bg, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.95rem', boxShadow:`0 0 20px ${C.green}44` }}>
  💰 צפה בהצעת המחיר שלך ←
  </button>
  <button className="hover-lift" onClick={onChat} style={{ width:'100%', padding:'.875rem', background:`${C.purple}18`, border:`1px solid ${C.purple}44`, borderRadius:'.875rem', color:C.purple, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.9rem', fontWeight:700 }}>
  💬 שאל שאלות לפני ההחלטה
  </button>
  </>
  )}
  </div>
  )}

  {}
  {tab==='pricing' && (
  <div style={{ display:'flex', flexDirection:'column', gap:'.75rem' }}>
  <div className="fu0" style={{ color:C.mutedLight, fontSize:'.82rem', textAlign:'center', marginBottom:'.25rem' }}>
  {hmoObj ? `הנחת ${hmoObj.name} מחושבת אוטומטית` : 'בחר חבילה לפרטי המחיר'}
  </div>
  {PRICE_PACKAGES.map(p=>{
  const disc = hmoObj?p.hmoDiscount[hmoObj.id]:0;
  const final = Math.round(p.price*(1-disc/100));
  const isSelected = selectedPkg===p.id;
  return (
  <div key={p.id} onClick={()=>setSelectedPkg(p.id)} style={{ background:isSelected?'rgba(56,189,248,.15)':'rgba(255,255,255,.07)', border:`${isSelected?2:1}px solid ${isSelected?C.cyan:'rgba(255,255,255,.14)'}`, borderRadius:'1.1rem', padding:'1.1rem', cursor:'pointer', transition:'all .15s', position:'relative' }}>
  {p.popular && <div style={{ position:'absolute', top:-10, right:16, background:C.cyan, color:C.bg, fontSize:'.65rem', fontWeight:800, padding:'.2rem .75rem', borderRadius:'1rem', boxShadow:`0 0 12px ${C.cyanGlow}` }}>⭐ פופולרי</div>}
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:'.65rem' }}>
  <div>
  <div style={{ fontSize:'1.1rem', marginBottom:'.2rem' }}>{p.icon} <span style={{ color:isSelected?C.white:C.text, fontWeight:800, fontSize:'1rem' }}>{p.name}</span></div>
  <div style={{ color:C.muted, fontSize:'.75rem' }}>{p.desc}</div>
  </div>
  <div style={{ textAlign:'left', flexShrink:0, marginRight:'auto', marginLeft:'1rem' }}>
  {disc>0 && <div style={{ color:C.muted, fontSize:'.75rem', textDecoration:'line-through' }}>₪{p.price.toLocaleString()}</div>}
  <div style={{ color:isSelected?C.cyan:C.text, fontWeight:900, fontSize:'1.2rem' }}>₪{final.toLocaleString()}</div>
  {disc>0 && <div style={{ color:C.green, fontSize:'.7rem', fontWeight:700 }}>חיסכון ₪{(p.price-final).toLocaleString()}</div>}
  </div>
  </div>
  <div style={{ display:'flex', flexWrap:'wrap', gap:'.35rem' }}>
  {p.features.map((f,i)=><span key={i} style={{ padding:'.2rem .6rem', background:`${C.cyan}10`, border:`1px solid ${C.cyan}22`, borderRadius:'.5rem', color:C.mutedLight, fontSize:'.7rem' }}>✓ {f}</span>)}
  </div>
  {disc>0 && hmoObj && (
  <div style={{ marginTop:'.65rem', padding:'.4rem .75rem', background:`${hmoObj.color}18`, border:`1px solid ${hmoObj.color}44`, borderRadius:'.6rem', display:'inline-flex', alignItems:'center', gap:'.4rem' }}>
  <span style={{ fontSize:'.85rem' }}>{hmoObj.logo}</span>
  <span style={{ color:C.text, fontSize:'.72rem' }}>הנחת {hmoObj.name}: <strong style={{ color:C.green }}>{disc}%</strong></span>
  </div>
  )}
  </div>
  );
  })}
  <button className="hover-lift" onClick={()=>setTab('payment')} style={{ width:'100%', padding:'1rem', background:C.cyan, color:C.bg, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.95rem', boxShadow:`0 0 20px ${C.cyanGlow}` }}>
  בחר אפשרות תשלום ←
  </button>
  </div>
  )}

  {tab==='payment' && (
  <PaymentTab pkg={pkg} finalPrice={finalPrice} hmoObj={hmoObj} discount={discount} selectedPayment={selectedPayment} setSelectedPayment={setSelectedPayment} onSchedule={onSchedule} onChat={onChat} patientName={patientName}/>
  )}
  </div>
  </Shell>
  );
}

const STAFF = [
  { id:'nurse', name:'רחל כהן', role:'אחות ראשית', avatar:'👩‍⚕️', online:true, responseTime:'בד"כ תוך דקות' },
  { id:'doctor', name:'ד"ר אייל שפירא', role:'רופא עיניים מומחה', avatar:'👨‍⚕️', online:false, responseTime:'בד"כ תוך שעות' },
  { id:'coordinator', name:'מיכל לוי', role:'רכזת מטופלים', avatar:'👩‍💼', online:true, responseTime:'זמין עכשיו' },
];

const QUICK_QUESTIONS = [
  'כמה זמן אסור לנהוג לאחר הניתוח?',
  'האם הניתוח כואב?',
  'כמה ימי מחלה אני צריך?',
  'מה ההבדל בין LASIK ל-SMILE?',
  'האם הניתוח מתאים לאנשים עם עיניים יבשות?',
  'כמה זמן עד שהראייה מתייצבת?',
];

function ChatCenterScreen({ patientName, hmo, onBack }) {
  const [tab, setTab] = useState('bot'); // bot | staff
  const [selectedStaff, setSelectedStaff] = useState(null);
  // AI Bot state
  const [botMessages, setBotMessages] = useState([
  { role:'assistant', content:`שלום ${patientName}! 👋 אני האסיסטנט הרפואי של OptiScan. אשמח לענות על כל שאלה לגבי ניתוח לייזר לעיניים, אפשרויות הטיפול, המחיר, ההכנה לניתוח, ההתאוששות וכל דבר אחר שמעניין אותך. במה אוכל לעזור?` }
  ]);
  const [botInput, setBotInput] = useState('');
  const [botLoading, setBotLoading] = useState(false);
  const botEndRef = useRef(null);
  // Staff chat state
  const [staffChats, setStaffChats] = useState({
  nurse: [{ from:'staff', text:'שלום! כאן רחל. אשמח לעזור בכל שאלה לגבי הניתוח ותקופת ההחלמה 😊', time:'עכשיו' }],
  doctor: [{ from:'staff', text:'שלום, כאן ד"ר שפירא. ניתן לשלוח שאלות רפואיות ואחזור אליך בהקדם.', time:'לפני שעה' }],
  coordinator: [{ from:'staff', text:'היי! אני מיכל. אשמח לעזור עם תיאום הניתוח, מחיר, ביטוח ותאריכים 📅', time:'עכשיו' }],
  });
  const [staffInput, setStaffInput] = useState('');
  const staffEndRef = useRef(null);

  useEffect(()=>{ botEndRef.current?.scrollIntoView({behavior:'smooth'}); },[botMessages]);
  useEffect(()=>{ staffEndRef.current?.scrollIntoView({behavior:'smooth'}); },[staffChats, selectedStaff]);

  const hmoObj = HMO_LIST.find(h=>h.id===hmo)||null;

  const sendBotMessage = async () => {
  if(!botInput.trim()||botLoading) return;
  const userMsg = { role:'user', content:botInput.trim() };
  const newMsgs = [...botMessages, userMsg];
  setBotMessages(newMsgs); setBotInput(''); setBotLoading(true);
  try {
  const res = await fetch("https://api.anthropic.com/v1/messages",{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
  model:'claude-sonnet-4-20250514', max_tokens:600,
  system:`אתה אסיסטנט רפואי מומחה של קליניקת עיניים לייזר בישראל. עונה בעברית, קצר וידידותי (עד 120 מילים). מומחה ב: ניתוחי LASIK/PRK/SMILE, ויזוס, טופוגרפיה, התאוששות, כאב, עיניים יבשות, תמחור (3800-6400 ש"ח לשתי עיניים), אפשרויות תשלום (עד 24 תשלומים ללא ריבית), הנחות קופות חולים (כללית 15%, מכבי 20%, מאוחדת 18%, לאומית 12%). מטופל: ${patientName}${hmoObj?`, קופה: ${hmoObj.name}`:''}.`,
  messages: newMsgs.map(m=>({role:m.role,content:m.content}))
  })});
  const data=await res.json();
  const reply=data.content?.find?.(b=>b.type==='text')?.text||'מצטער, נסה שוב.';
  setBotMessages(prev=>[...prev,{role:'assistant',content:reply}]);
  } catch {
  setBotMessages(prev=>[...prev,{role:'assistant',content:'מצטער, הייתה שגיאה. נסה שוב בעוד רגע.'}]);
  }
  setBotLoading(false);
  };

  const sendStaffMessage = () => {
  if(!staffInput.trim()||!selectedStaff) return;
  const now = new Date().toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'});
  setStaffChats(prev=>({...prev,[selectedStaff]:[...prev[selectedStaff],{from:'patient',text:staffInput.trim(),time:now}]}));
  setStaffInput('');
  // Simulate reply after delay
  const staff = STAFF.find(s=>s.id===selectedStaff);
  if(staff?.online) {
  setTimeout(()=>{
  const replies = {
  nurse:['אבדוק ואחזור אליך תוך דקות 😊','בהחלט! אני ממליצה...','שאלה מצוינת! לאחר הניתוח...'],
  coordinator:['כמובן! נוכל לתאם...','אבדוק זמינות ואחזור אליך','בשמחה, אשלח לך פרטים'],
  doctor:['בהחלט. מנקודת מבט רפואית...','שאלה חשובה. אענה בהרחבה...'],
  };
  const rArr = replies[selectedStaff]||['קיבלתי. אחזור אליך בהקדם.'];
  const rText = rArr[Math.floor(Math.random()*rArr.length)];
  const t = new Date().toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'});
  setStaffChats(prev=>({...prev,[selectedStaff]:[...prev[selectedStaff],{from:'staff',text:rText,time:t}]}));
  }, 1800 + Math.random()*1200);
  }
  };

  const staff = STAFF.find(s=>s.id===selectedStaff);

  return (
  <Shell title="מרכז שיחה">
  <div dir="rtl" style={{ height:'100vh', display:'flex', flexDirection:'column' }}>

  <div style={{ padding:'1rem 1.25rem .75rem', borderBottom:`1px solid ${C.cardBorder}`, flexShrink:0 }}>
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'.75rem' }}>
  <button onClick={selectedStaff?()=>setSelectedStaff(null):onBack} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.85rem', padding:0 }}>← {selectedStaff?'חזור לצ׳אט':'ראשי'}</button>
  <div style={{ textAlign:'center' }}>
  {selectedStaff ? (
  <>
  <div style={{ color:C.white, fontWeight:800 }}>{staff?.avatar} {staff?.name}</div>
  <div style={{ display:'flex', alignItems:'center', gap:'.3rem', justifyContent:'center' }}>
  <div style={{ width:6, height:6, borderRadius:'50%', background:staff?.online?C.green:C.muted }}/>
  <div style={{ color:staff?.online?C.green:C.muted, fontSize:'.7rem' }}>{staff?.online?'מחובר':'לא מחובר'}</div>
  </div>
  </>
  ) : (
  <>
  <div style={{ color:C.purple, fontSize:'.65rem', fontWeight:700, letterSpacing:'.2em' }}>מרכז שיחה</div>
  <div style={{ color:C.white, fontWeight:800 }}>💬 צ׳אט ותמיכה</div>
  </>
  )}
  </div>
  <div style={{ width:60 }}/>
  </div>

  {!selectedStaff && (
  <div style={{ display:'flex', background:'rgba(255,255,255,0.09)', borderRadius:'.75rem', padding:'.25rem', border:`1px solid ${C.cardBorder}` }}>
  {[{id:'bot',label:'🤖 AI Bot'},{id:'staff',label:'👥 צוות רפואי'}].map(t=>(
  <button key={t.id} className="tab-btn" onClick={()=>setTab(t.id)} style={{ flex:1, padding:'.55rem', background:tab===t.id?'rgba(255,255,255,.15)':'transparent', border:tab===t.id?'1px solid rgba(255,255,255,.2)':'1px solid transparent', borderRadius:'.55rem', color:tab===t.id?C.text:C.muted, fontFamily:'Heebo,sans-serif', fontWeight:tab===t.id?700:400, fontSize:'.82rem', cursor:'pointer' }}>
  {t.label}
  </button>
  ))}
  </div>
  )}
  </div>

  {}
  {tab==='bot' && !selectedStaff && (
  <>
  <div style={{ flex:1, overflowY:'auto', padding:'1rem 1.25rem', display:'flex', flexDirection:'column', gap:'.75rem' }}>
  {botMessages.map((m,i)=>(
  <div key={i} style={{ display:'flex', justifyContent:m.role==='user'?'flex-start':'flex-end', gap:'.5rem', alignItems:'flex-end' }}>
  {m.role==='assistant' && <div style={{ width:30, height:30, borderRadius:'50%', background:`${C.purple}22`, border:`1px solid ${C.purple}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'.85rem', flexShrink:0 }}>🤖</div>}
  <div style={{ maxWidth:'80%', padding:'.75rem 1rem', background:m.role==='user'?`${C.cyan}18`:C.card, border:`1px solid ${m.role==='user'?`${C.cyan}44`:C.cardBorder}`, borderRadius:m.role==='user'?'1rem 1rem 0 1rem':'1rem 1rem 1rem 0', color:C.text, fontSize:'.88rem', lineHeight:1.55 }}>
  {m.content}
  </div>
  </div>
  ))}
  {botLoading && (
  <div style={{ display:'flex', justifyContent:'flex-end', gap:'.5rem', alignItems:'flex-end' }}>
  <div style={{ width:30, height:30, borderRadius:'50%', background:`${C.purple}22`, border:`1px solid ${C.purple}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'.85rem' }}>🤖</div>
  <div style={{ padding:'.75rem 1rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem 1rem 1rem 0' }}>
  <div style={{ display:'flex', gap:'.3rem', alignItems:'center' }}>
  {[0,1,2].map(i=><div key={i} style={{ width:6, height:6, borderRadius:'50%', background:C.purple, animation:`blink-e 1.2s ease ${i*0.2}s infinite` }}/>)}
  </div>
  </div>
  </div>
  )}
  <div ref={botEndRef}/>
  </div>

  <div style={{ padding:'.75rem 1.25rem 0', borderTop:`1px solid ${C.cardBorder}40`, flexShrink:0 }}>
  <div style={{ overflowX:'auto', display:'flex', gap:'.5rem', paddingBottom:'.5rem' }}>
  {QUICK_QUESTIONS.map((q,i)=>(
  <button key={i} onClick={()=>{ setBotInput(q); }} style={{ flexShrink:0, padding:'.4rem .875rem', background:`${C.purple}12`, border:`1px solid ${C.purple}33`, borderRadius:'2rem', color:C.purple, fontSize:'.73rem', cursor:'pointer', fontFamily:'Heebo,sans-serif', whiteSpace:'nowrap', transition:'all .15s' }}>
  {q}
  </button>
  ))}
  </div>
  </div>

  <div style={{ padding:'.75rem 1.25rem 1rem', flexShrink:0 }}>
  <div style={{ display:'flex', gap:'.6rem', alignItems:'center' }}>
  <input value={botInput} onChange={e=>setBotInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendBotMessage()} placeholder="שאל שאלה על הניתוח..." style={{ flex:1, padding:'.875rem 1.1rem', background:'rgba(255,255,255,.1)', border:'1px solid rgba(255,255,255,.15)', borderRadius:'.875rem', color:C.text, fontSize:'.9rem', fontFamily:'Heebo,sans-serif' }}/>
  <button onClick={sendBotMessage} disabled={!botInput.trim()||botLoading} style={{ width:46, height:46, borderRadius:'.875rem', background:botInput.trim()?C.purple:'#131f2e', border:'none', cursor:botInput.trim()?'pointer':'not-allowed', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.1rem', flexShrink:0, transition:'all .15s', boxShadow:botInput.trim()?`0 0 12px ${C.purple}44`:'none' }}>→</button>
  </div>
  </div>
  </>
  )}

  {}
  {tab==='staff' && !selectedStaff && (
  <div style={{ flex:1, overflowY:'auto', padding:'1rem 1.25rem', display:'flex', flexDirection:'column', gap:'.75rem' }}>
  <div style={{ color:C.mutedLight, fontSize:'.82rem', textAlign:'center', marginBottom:'.25rem' }}>בחר איש צוות לשיחה</div>
  {STAFF.map(s=>{
  const lastMsg = staffChats[s.id]?.slice(-1)[0];
  const unread = staffChats[s.id]?.filter(m=>m.from==='staff').length || 0;
  return (
  <div key={s.id} className="hover-slide" onClick={()=>setSelectedStaff(s.id)} style={{ display:'flex', gap:'1rem', alignItems:'center', padding:'1rem 1.1rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', cursor:'pointer' }}>
  <div style={{ position:'relative' }}>
  <div style={{ width:52, height:52, borderRadius:'50%', background:`${C.purple}18`, border:`2px solid ${s.online?C.green:C.muted}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.5rem' }}>{s.avatar}</div>
  <div style={{ position:'absolute', bottom:2, right:2, width:10, height:10, borderRadius:'50%', background:s.online?C.green:C.muted, border:`2px solid ${C.bg}` }}/>
  </div>
  <div style={{ flex:1 }}>
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
  <div style={{ color:C.white, fontWeight:700 }}>{s.name}</div>
  <div style={{ color:C.muted, fontSize:'.68rem' }}>{lastMsg?.time||''}</div>
  </div>
  <div style={{ color:C.cyan, fontSize:'.72rem', marginBottom:'.2rem' }}>{s.role}</div>
  <div style={{ color:C.muted, fontSize:'.75rem', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', maxWidth:200 }}>{lastMsg?.text?.substring(0,50)||''}...</div>
  </div>
  <div style={{ color:s.online?C.green:C.muted, fontSize:'.68rem', textAlign:'center', flexShrink:0 }}>
  <div style={{ width:8, height:8, borderRadius:'50%', background:s.online?C.green:C.muted, margin:'0 auto .2rem' }}/>
  {s.online?'מחובר':'לא מחובר'}
  </div>
  </div>
  );
  })}
  <div style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', padding:'.875rem 1rem', marginTop:'.25rem' }}>
  <div style={{ color:C.yellow, fontSize:'.72rem', fontWeight:700, marginBottom:'.3rem' }}>⏰ שעות פעילות</div>
  <div style={{ color:C.mutedLight, fontSize:'.75rem', lineHeight:1.6 }}>ימים א׳–ה׳: 8:00–20:00<br/>יום ו׳: 8:00–13:00<br/>שישי-שבת: AI Bot זמין 24/7</div>
  </div>
  </div>
  )}

  {}
  {selectedStaff && (
  <>
  <div style={{ flex:1, overflowY:'auto', padding:'1rem 1.25rem', display:'flex', flexDirection:'column', gap:'.65rem' }}>
  {staffChats[selectedStaff]?.map((m,i)=>(
  <div key={i} style={{ display:'flex', justifyContent:m.from==='patient'?'flex-start':'flex-end', gap:'.5rem', alignItems:'flex-end' }}>
  {m.from==='staff' && <div style={{ width:30, height:30, borderRadius:'50%', background:`${C.purple}22`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'.85rem', flexShrink:0 }}>{staff?.avatar}</div>}
  <div>
  <div style={{ maxWidth:'78%', padding:'.7rem .95rem', background:m.from==='patient'?`${C.cyan}18`:C.card, border:`1px solid ${m.from==='patient'?`${C.cyan}44`:C.cardBorder}`, borderRadius:m.from==='patient'?'1rem 1rem 0 1rem':'1rem 1rem 1rem 0', color:C.text, fontSize:'.88rem', lineHeight:1.5 }}>
  {m.text}
  </div>
  <div style={{ color:C.muted, fontSize:'.65rem', marginTop:'.2rem', textAlign:m.from==='patient'?'right':'left' }}>{m.time}</div>
  </div>
  </div>
  ))}
  <div ref={staffEndRef}/>
  </div>
  {!staff?.online && (
  <div style={{ padding:'.5rem 1.25rem', background:'rgba(234,179,8,.06)', borderTop:'1px solid rgba(234,179,8,.15)', flexShrink:0 }}>
  <div style={{ color:C.yellow, fontSize:'.75rem', textAlign:'center' }}>⏰ {staff?.name} לא מחובר כרגע — {staff?.responseTime}</div>
  </div>
  )}
  <div style={{ padding:'.75rem 1.25rem 1rem', borderTop:`1px solid ${C.cardBorder}40`, flexShrink:0 }}>
  <div style={{ display:'flex', gap:'.6rem', alignItems:'center' }}>
  <input value={staffInput} onChange={e=>setStaffInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendStaffMessage()} placeholder={`שלח הודעה ל${staff?.name}...`} style={{ flex:1, padding:'.875rem 1.1rem', background:'rgba(255,255,255,.1)', border:'1px solid rgba(255,255,255,.15)', borderRadius:'.875rem', color:C.text, fontSize:'.9rem', fontFamily:'Heebo,sans-serif' }}/>
  <button onClick={sendStaffMessage} disabled={!staffInput.trim()} style={{ width:46, height:46, borderRadius:'.875rem', background:staffInput.trim()?C.purple:'#131f2e', border:'none', cursor:staffInput.trim()?'pointer':'not-allowed', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.1rem', flexShrink:0, transition:'all .15s', boxShadow:staffInput.trim()?`0 0 12px ${C.purple}44`:'none' }}>→</button>
  </div>
  </div>
  </>
  )}
  </div>
  </Shell>
  );
}

// ─── LOGO COMPONENT ────────────────────────────────────────────────────────────
// Faithful recreation of the Dr. Levinger logo banner
const DrLevingerLogo = ({ size=48, full=false }) => {
  if (full) return (
    <div dir="rtl" style={{ display:'inline-flex', alignItems:'center', background:'#1a5fa8', borderRadius:10, overflow:'hidden', boxShadow:'0 3px 14px rgba(0,0,0,0.35)', gap:0 }}>
      {/* Blue text block */}
      <div style={{ padding:'10px 14px 10px 10px', display:'flex', flexDirection:'column', justifyContent:'center' }}>
        <div style={{ color:'#fff', fontFamily:'Heebo,sans-serif', fontWeight:900, fontSize:20, lineHeight:1.15, letterSpacing:'-.01em' }}>ד"ר עיני נץ</div>
        <div style={{ color:'rgba(255,255,255,0.82)', fontFamily:'Heebo,sans-serif', fontWeight:400, fontSize:10, lineHeight:1.3, marginTop:2 }}>ניתוחי עיניים בקבוצת דנאל</div>
      </div>
      {/* Icon block */}
      <div style={{ background:'rgba(255,255,255,0.15)', padding:'8px 12px', display:'flex', alignItems:'center', justifyContent:'center', borderRight:'1px solid rgba(255,255,255,0.2)', height:'100%' }}>
        <svg width={38} height={38} viewBox="0 0 60 60" fill="none">
          {/* Outer ring */}
          <circle cx="30" cy="30" r="27" stroke="white" strokeWidth="2" fill="none"/>
          {/* Diagonal orbit-line */}
          <ellipse cx="30" cy="30" rx="27" ry="27" stroke="rgba(255,255,255,0.4)" strokeWidth="1.2" fill="none" transform="rotate(-35 30 30)" strokeDasharray="6 3"/>
          {/* Eye shape */}
          <path d="M8 30 Q19 15 30 30 Q41 45 52 30 Q41 15 30 30 Q19 45 8 30Z" fill="none" stroke="white" strokeWidth="2.2"/>
          {/* Pupil */}
          <circle cx="30" cy="30" r="7" fill="white"/>
          <circle cx="30" cy="30" r="4" fill="#1a5fa8"/>
          <circle cx="32" cy="28" r="1.5" fill="rgba(255,255,255,0.7)"/>
        </svg>
      </div>
    </div>
  );
  // Small icon-only version
  return (
    <div style={{ width:size, height:size, borderRadius:'50%', background:'#1a5fa8', display:'flex', alignItems:'center', justifyContent:'center', boxShadow:'0 2px 10px rgba(26,95,168,0.5)', flexShrink:0 }}>
      <svg width={size*0.7} height={size*0.7} viewBox="0 0 60 60" fill="none">
        <circle cx="30" cy="30" r="27" stroke="white" strokeWidth="2.2" fill="none"/>
        <ellipse cx="30" cy="30" rx="27" ry="27" stroke="rgba(255,255,255,0.35)" strokeWidth="1" fill="none" transform="rotate(-35 30 30)" strokeDasharray="5 3"/>
        <path d="M8 30 Q19 15 30 30 Q41 45 52 30 Q41 15 30 30 Q19 45 8 30Z" fill="none" stroke="white" strokeWidth="2.2"/>
        <circle cx="30" cy="30" r="7" fill="white"/>
        <circle cx="30" cy="30" r="4" fill="#1a5fa8"/>
        <circle cx="32" cy="28" r="1.5" fill="rgba(255,255,255,0.65)"/>
      </svg>
    </div>
  );
};

// ─── BOTTOM NAV ────────────────────────────────────────────────────────────────
const BottomNav = ({ onHome, onChat, onPostOp, active }) => (
  <div style={{ position:'fixed', bottom:0, left:0, right:0, zIndex:100,
    background:'#0a2d5e', borderTop:'1.5px solid rgba(255,255,255,.12)',
    display:'flex', alignItems:'stretch', height:64,
    boxShadow:'0 -2px 12px rgba(0,0,0,0.07)' }}>
    {[
      { id:'home',   icon:'🏠', label:'ראשי',      action: onHome },
      { id:'chat',   icon:'💬', label:'שאל שאלה',  action: onChat },
      { id:'postop', icon:'📈', label:'מעקב ניתוח', action: onPostOp },
    ].map(btn => (
      <button key={btn.id} className="bottom-nav-btn" onClick={btn.action}
        style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
          gap:2, background:'none', border:'none', cursor:'pointer', fontFamily:'Heebo,sans-serif',
          borderTop: active===btn.id ? '2.5px solid #1e6fba' : '2.5px solid transparent',
          paddingTop: active===btn.id ? 0 : 2 }}>
        <span style={{ fontSize:'1.25rem', lineHeight:1 }}>{btn.icon}</span>
        <span style={{ fontSize:'.62rem', fontWeight: active===btn.id?700:400,
          color: active===btn.id?C.cyan:'rgba(255,255,255,.4)' }}>{btn.label}</span>
      </button>
    ))}
  </div>
);

// ─── SPLASH SCREEN ─────────────────────────────────────────────────────────────
function SplashScreen({ onStart }) {
  return (
    <Shell center noPad hideHome={true}>
      <div dir="rtl" style={{ width:'100%', maxWidth:400, padding:'2.5rem 2rem', display:'flex', flexDirection:'column', alignItems:'center', minHeight:'100vh', justifyContent:'center' }}>
        <div style={{ position:'absolute', top:0, left:0, right:0, height:260,
          background:'linear-gradient(160deg, rgba(255,255,255,0.07) 0%, rgba(56,189,248,0.05) 100%)',
          borderRadius:'0 0 60% 60%', pointerEvents:'none' }}/>
        <div className="fu0" style={{ marginBottom:'1.5rem', animation:'float 4s ease-in-out infinite' }}>
          <DrLevingerLogo full={true}/>
        </div>
        <div className="fu1" style={{ textAlign:'center', marginBottom:'1rem' }}>
          <div style={{ fontSize:'.65rem', letterSpacing:'.3em', color:C.cyan, fontWeight:700, marginBottom:'.5rem' }}>ניתוחי עיניים בקבוצת דנאל</div>
          <h1 style={{ fontSize:'2rem', fontWeight:900, color:C.cyan, margin:0, letterSpacing:'-.01em', lineHeight:1.15 }}>ד"ר עיני נץ</h1>
          <div style={{ fontSize:'1rem', color:C.mutedLight, fontWeight:500, marginTop:'.3rem' }}>ניתוחי עיניים</div>
        </div>
        <div className="fu2" style={{ background:'rgba(56,189,248,.12)', border:'1.5px solid rgba(30,111,186,0.2)', borderRadius:'1.25rem', padding:'1.25rem 1.5rem', marginBottom:'2rem', textAlign:'center', maxWidth:340 }}>
          <p style={{ color:C.text, fontSize:'.92rem', lineHeight:1.7, margin:0, fontWeight:400 }}>
            ברוכים הבאים לאפליקציה של <strong style={{ color:'#1e6fba' }}>ד"ר עיני נץ — ניתוחי עיניים</strong><br/>
            <span style={{ color:C.mutedLight, fontSize:'.85rem' }}>אפליקציה נסיונית לניהול תהליך הסרת משקפיים בלייזר</span>
          </p>
        </div>
        <div className="fu3" style={{ width:'100%', maxWidth:340, display:'flex', flexDirection:'column', gap:'.75rem' }}>
          <button className="hover-lift" onClick={onStart} style={{ width:'100%', padding:'1.1rem', background:'#1e6fba', color:'#fff', border:'none', borderRadius:'1rem', fontSize:'1.05rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', boxShadow:'0 4px 20px rgba(30,111,186,0.35)', letterSpacing:'.01em' }}>
            👁️ התחל בדיקת התאמה
          </button>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.6rem' }}>
            <button style={{ padding:'.75rem', background:'rgba(56,189,248,.12)', border:'1px solid rgba(30,111,186,.25)', borderRadius:'.875rem', color:'#1e6fba', fontSize:'.82rem', fontWeight:600, cursor:'pointer', fontFamily:'Heebo,sans-serif' }}>📈 מעקב ניתוח</button>
            <button style={{ padding:'.75rem', background:'rgba(56,189,248,.12)', border:'1px solid rgba(30,111,186,.25)', borderRadius:'.875rem', color:'#1e6fba', fontSize:'.82rem', fontWeight:600, cursor:'pointer', fontFamily:'Heebo,sans-serif' }}>💬 שאל שאלה</button>
          </div>
        </div>
        <div className="fu4" style={{ marginTop:'1.75rem', textAlign:'center', color:C.muted, fontSize:'.7rem', lineHeight:1.6 }}>
          ⚠️ אפליקציה נסיונית — אינה מחליפה אבחנה רפואית מוסמכת
        </div>
      </div>
    </Shell>
  );
}

// ─── REGISTER SCREEN (name + ID + HMO) ────────────────────────────────────────
function RegisterScreen({ onNext, onBack }) {
  const [name, setName] = useState('');
  const [idNum, setIdNum] = useState('');
  const [hmo, setHmo] = useState(null);
  const valid = name.trim().length >= 2 && idNum.trim().length >= 5 && hmo;
  return (
    <Shell title="פרטים אישיים" subtitle="שלב 1 מתוך 5">
      <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem 1.25rem 0' }}>
        <div style={{ display:'flex', alignItems:'center', gap:'.75rem', marginBottom:'1.5rem', paddingTop:'.5rem' }}>
          <button onClick={onBack} style={{ width:36, height:36, borderRadius:'50%', background:'rgba(255,255,255,0.1)', border:'1px solid rgba(255,255,255,0.15)', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', fontSize:'.9rem' }}>←</button>
          <div>
            <div style={{ color:C.cyan, fontSize:'.62rem', fontWeight:700, letterSpacing:'.2em' }}>שלב 1 מתוך 5</div>
            <div style={{ color:C.text, fontWeight:800, fontSize:'1.05rem' }}>פרטים אישיים</div>
          </div>
          <DrLevingerLogo size={32}/>
        </div>
        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:'1rem', maxWidth:400, margin:'0 auto', width:'100%' }}>
          <div className="fu0">
            <label style={{ color:C.mutedLight, fontSize:'.78rem', fontWeight:600, display:'block', marginBottom:'.4rem' }}>שם מלא</label>
            <input value={name} onChange={e=>setName(e.target.value)} placeholder="ישראל ישראלי" style={{ width:'100%', padding:'.875rem 1rem', background:'rgba(255,255,255,0.1)', border:`1.5px solid ${name.trim().length>=2?C.cyan:'rgba(255,255,255,.2)'}`, borderRadius:'.875rem', color:C.text, fontSize:'1rem', fontFamily:'Heebo,sans-serif', transition:'border .15s' }}/>
          </div>
          <div className="fu1">
            <label style={{ color:C.mutedLight, fontSize:'.78rem', fontWeight:600, display:'block', marginBottom:'.4rem' }}>מספר תעודת זהות</label>
            <input value={idNum} onChange={e=>setIdNum(e.target.value.replace(/\D/g,''))} placeholder="000000000" maxLength={9} inputMode="numeric" style={{ width:'100%', padding:'.875rem 1rem', background:'rgba(255,255,255,0.1)', border:`1.5px solid ${idNum.trim().length>=5?C.cyan:'rgba(255,255,255,.2)'}`, borderRadius:'.875rem', color:C.text, fontSize:'1rem', fontFamily:'Heebo,sans-serif', letterSpacing:'.1em', transition:'border .15s' }}/>
            <div style={{ color:C.muted, fontSize:'.7rem', marginTop:'.3rem' }}>* ניתן להזין מספר פיקטיבי בשלב זה</div>
          </div>
          <div className="fu2">
            <label style={{ color:C.mutedLight, fontSize:'.78rem', fontWeight:600, display:'block', marginBottom:'.6rem' }}>קופת חולים</label>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.5rem' }}>
              {HMO_LIST.map(h=>(
                <div key={h.id} onClick={()=>setHmo(h.id)} style={{ display:'flex', alignItems:'center', gap:'.65rem', padding:'.75rem 1rem', background:hmo===h.id?'rgba(59,158,255,.2)':'rgba(255,255,255,.08)', border:`${hmo===h.id?2:1.5}px solid ${hmo===h.id?C.cyan:'rgba(255,255,255,.15)'}`, borderRadius:'.875rem', cursor:'pointer', transition:'all .13s' }}>
                  <span style={{ fontSize:'1.1rem' }}>{h.logo}</span>
                  <span style={{ color:hmo===h.id?'#1e6fba':C.text, fontWeight:hmo===h.id?700:500, fontSize:'.88rem' }}>{h.name}</span>
                  {hmo===h.id && <div style={{ marginRight:'auto', width:18, height:18, borderRadius:'50%', background:'#1e6fba', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:'.65rem', fontWeight:900 }}>✓</div>}
                </div>
              ))}
            </div>
          </div>
          <div className="fu3" style={{ marginTop:'.5rem' }}>
            <button className="hover-lift" disabled={!valid} onClick={()=>onNext({name:name.trim(),idNum,hmo})} style={{ width:'100%', padding:'1rem', background:valid?'#1e6fba':'#f1f5f9', color:valid?'#fff':'#94a3b8', border:'none', borderRadius:'1rem', fontSize:'1rem', fontWeight:800, cursor:valid?'pointer':'not-allowed', fontFamily:'Heebo,sans-serif', transition:'all .2s', boxShadow:valid?'0 4px 16px rgba(30,111,186,.3)':'none' }}>
              המשך ←
            </button>
          </div>
        </div>
      </div>
      <BottomNav onHome={onBack} onChat={()=>{}} onPostOp={()=>{}} active="home"/>
    </Shell>
  );
}

// ─── ONBOARDING SCREEN ─────────────────────────────────────────────────────────
function OnboardingScreen({ patientName, onNext, onBack }) {
  const steps = [
    { n:'1', icon:'📋', title:'שאלון רפואי', desc:'13 שאלות קצרות על מצב בריאותך ורקע עיניים', color:'#1e6fba' },
    { n:'2', icon:'🏥', title:'בחירת מרפאה ורופא', desc:'בחר מרפאה קרובה אליך ורופא מועדף — או קבל המלצת AI', color:'#0891b2' },
    { n:'3', icon:'📸', title:'צילום עין (אופציונלי)', desc:'ניתן לדלג בשלב זה ולבצע בקליניקה', color:'#7c3aed' },
    { n:'4', icon:'⭕', title:'בדיקת Placido (אופציונלי)', desc:'ניתוח טופוגרפיית קרנית דרך המסך — ניתן לדלג', color:'#0891b2' },
    { n:'5', icon:'🤖', title:'ניתוח AI ותוצאות', desc:'המערכת תנתח את הנתונים ותיצור איתך קשר תוך 24 שעות', color:'#16a34a' },
  ];
  return (
    <Shell title="שלבי הבדיקה" subtitle="מה עומד לקרות">
      <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem 1.25rem 0' }}>
        <div style={{ display:'flex', alignItems:'center', gap:'.75rem', marginBottom:'1.25rem', paddingTop:'.5rem' }}>
          <button onClick={onBack} style={{ width:36, height:36, borderRadius:'50%', background:'rgba(255,255,255,0.1)', border:'1px solid rgba(255,255,255,0.15)', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', fontSize:'.9rem' }}>←</button>
          <div>
            <div style={{ color:C.cyan, fontSize:'.62rem', fontWeight:700, letterSpacing:'.2em' }}>מה עומד לקרות</div>
            <div style={{ color:C.text, fontWeight:800, fontSize:'1.05rem' }}>שלבי הבדיקה</div>
          </div>
          <DrLevingerLogo size={32}/>
        </div>
        <div className="fu0" style={{ background:'rgba(255,255,255,0.09)', border:'1.5px solid rgba(255,255,255,.15)', borderRadius:'1.1rem', padding:'1rem 1.25rem', marginBottom:'1.25rem' }}>
          <p style={{ color:C.text, margin:0, fontSize:'.9rem', lineHeight:1.6 }}>
            שלום <strong style={{ color:'#1e6fba' }}>{patientName}</strong> 👋<br/>
            <span style={{ color:C.mutedLight, fontSize:'.83rem' }}>הבדיקה לוקחת כ-5 דקות. התוצאות יישלחו לצוות הרפואי ונחזור אליך תוך <strong>24 שעות</strong>.</span>
          </p>
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:'.65rem', flex:1, maxWidth:420, margin:'0 auto', width:'100%' }}>
          {steps.map((s,i)=>(
            <div key={i} className="fu1" style={{ display:'flex', gap:'1rem', alignItems:'flex-start', padding:'.875rem 1rem', background:'rgba(255,255,255,0.1)', border:'1.5px solid rgba(255,255,255,0.15)', borderRadius:'1rem', boxShadow:'0 1px 4px rgba(0,0,0,0.04)' }}>
              <div style={{ width:40, height:40, borderRadius:'50%', background:`${s.color}12`, border:`2px solid ${s.color}30`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.15rem', flexShrink:0 }}>{s.icon}</div>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', alignItems:'center', gap:'.5rem', marginBottom:'.2rem' }}>
                  <span style={{ width:18, height:18, borderRadius:'50%', background:s.color, color:'#fff', fontSize:'.62rem', fontWeight:800, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>{s.n}</span>
                  <span style={{ color:C.text, fontWeight:700, fontSize:'.9rem' }}>{s.title}</span>
                  {(i===2||i===3) && <span style={{ padding:'.12rem .5rem', background:'rgba(251,191,36,.18)', border:'1px solid rgba(251,191,36,.4)', borderRadius:'.4rem', color:'#fbbf24', fontSize:'.62rem', fontWeight:700 }}>ניתן לדלג</span>}
                </div>
                <div style={{ color:C.mutedLight, fontSize:'.78rem', lineHeight:1.45 }}>{s.desc}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ padding:'1.25rem 0 0', maxWidth:420, margin:'0 auto', width:'100%' }}>
          <button className="hover-lift" onClick={onNext} style={{ width:'100%', padding:'1rem', background:'#1e6fba', color:'#fff', border:'none', borderRadius:'1rem', fontSize:'1rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', boxShadow:'0 4px 16px rgba(30,111,186,.3)' }}>
            מתחילים! ←
          </button>
        </div>
      </div>
      <BottomNav onHome={onBack} onChat={()=>{}} onPostOp={()=>{}} active="home"/>
    </Shell>
  );
}

function HomeScreen({ onPreOp, onPostOp, onApproval, onChat, patientName, hmo }) {
  const data = loadPostOpData();
  const hasSurgery = !!data.surgeryDate;
  const hmoObj = HMO_LIST.find(h=>h.id===hmo);
  return (
    <Shell>
      <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem 1.25rem 0' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'1.25rem', paddingTop:'.5rem' }}>
          <div>
            <div style={{ color:C.cyan, fontSize:'.6rem', fontWeight:700, letterSpacing:'.25em' }}>ד"ר עיני נץ — ניתוחי עיניים</div>
            <div style={{ color:C.text, fontWeight:900, fontSize:'1.3rem', letterSpacing:'-.01em' }}>שלום{patientName?', '+patientName:''} 👋</div>
          </div>
          <DrLevingerLogo size={44}/>
        </div>
        {hmoObj && (
          <div style={{ background:'rgba(255,255,255,0.1)', border:'1px solid rgba(255,255,255,.15)', borderRadius:'.875rem', padding:'.5rem .875rem', marginBottom:'1rem', display:'flex', gap:'.5rem', alignItems:'center' }}>
            <span>{hmoObj.logo}</span><span style={{ color:C.mutedLight, fontSize:'.75rem' }}>{hmoObj.name}</span>
          </div>
        )}
        <div style={{ background:'linear-gradient(135deg,#1e6fba,#0891b2)', borderRadius:'1.25rem', padding:'1.1rem 1.25rem', marginBottom:'1.1rem', cursor:'pointer', boxShadow:'0 4px 20px rgba(30,111,186,.35)' }} onClick={onApproval}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <div><div style={{ color:'rgba(255,255,255,.8)', fontSize:'.7rem', fontWeight:700, marginBottom:'.25rem' }}>✅ אושרת לניתוח לייזר!</div>
            <div style={{ color:'#fff', fontWeight:800, fontSize:'1rem' }}>צפה בהצעת המחיר שלך</div>
            <div style={{ color:'rgba(255,255,255,.7)', fontSize:'.75rem' }}>ד"ר שפירא אישר את תוצאותיך</div></div>
            <div style={{ fontSize:'1.8rem' }}>←</div>
          </div>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.7rem' }}>
          {[
            { icon:'🔍', label:'בדיקת התאמה', sub:'שאלון · Placido · AI', action:onPreOp, color:'#1e6fba' },
            { icon:'💬', label:'שאל שאלה', sub:'AI Bot · רופא · אחות', action:onChat, color:'#0891b2' },
            { icon:'💰', label:'אישור ומחיר', sub:'סטטוס · הצעה · תשלום', action:onApproval, color:'#16a34a' },
            { icon:'📈', label:'מעקב ניתוח', sub:hasSurgery?'● פעיל':'ויזוס · תסמינים', action:onPostOp, color:'#7c3aed' },
          ].map((t,i)=>(
            <div key={i} className="card-hover" onClick={t.action} style={{ padding:'1rem', background:'rgba(255,255,255,0.1)', border:'1.5px solid rgba(255,255,255,0.15)', borderRadius:'1rem', display:'flex', flexDirection:'column', gap:'.5rem', boxShadow:'0 1px 4px rgba(0,0,0,0.05)' }}>
              <div style={{ width:42, height:42, borderRadius:'.75rem', background:`${t.color}10`, border:`1.5px solid ${t.color}25`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.2rem' }}>{t.icon}</div>
              <div><div style={{ color:t.color, fontWeight:700, fontSize:'.9rem' }}>{t.label}</div><div style={{ color:C.muted, fontSize:'.7rem', marginTop:'.1rem' }}>{t.sub}</div></div>
            </div>
          ))}
        </div>
        <div style={{ textAlign:'center', paddingTop:'1.5rem', color:C.muted, fontSize:'.68rem' }}>
          ⚠️ אפליקציה נסיונית — אינה מחליפה אבחנה רפואית
        </div>
      </div>
      <BottomNav onHome={()=>{}} onChat={onChat} onPostOp={onPostOp} active="home"/>
    </Shell>
  );
}

function WelcomeScreen({ onStart, onBack }) {
  return (
  <Shell center>
  <div dir="rtl" style={{ width:'100%', maxWidth:400, padding:'2rem', display:'flex', flexDirection:'column', alignItems:'center' }}>
  <div style={{ position:'fixed', top:'25%', left:'50%', transform:'translate(-50%,-50%)', width:480, height:480, background:'radial-gradient(circle,rgba(6,182,212,.07) 0%,transparent 70%)', pointerEvents:'none' }}/>
  <div className="fu0" style={{ marginBottom:'2rem', animation:'float 5s ease-in-out infinite', position:'relative' }}>
  <div style={{ width:96, height:96, borderRadius:'50%', border:`1.5px solid ${C.cyan}`, display:'flex', alignItems:'center', justifyContent:'center', boxShadow:`0 0 40px ${C.cyanDim},inset 0 0 20px ${C.cyanDim}` }}>
  <div style={{ position:'absolute', inset:-10, borderRadius:'50%', border:'1px solid rgba(6,182,212,.25)', animation:'pulse-ring 2.5s ease-in-out infinite' }}/>
  <div style={{ position:'absolute', inset:-22, borderRadius:'50%', border:'1px solid rgba(6,182,212,.1)', animation:'pulse-ring 2.5s ease-in-out .5s infinite' }}/>
  <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke={C.cyan} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
  </svg>
  </div>
  </div>
  <div className="fu1" style={{ textAlign:'center', marginBottom:'2.5rem' }}>
  <div style={{ fontSize:'.65rem', letterSpacing:'.35em', color:C.cyan, marginBottom:'.6rem', fontWeight:600 }}>LASER EYE SCREENING</div>
  <h1 style={{ fontSize:'2.8rem', fontWeight:900, color:C.white, margin:0, letterSpacing:'-.02em', lineHeight:1 }}>OptiScan</h1>
  <p style={{ color:C.mutedLight, margin:'.75rem 0 0', fontSize:'1rem', fontWeight:300 }}>בדיקת התאמה לייזר מהבית</p>
  </div>
  <div className="fu2" style={{ width:'100%', display:'flex', flexDirection:'column', gap:'.6rem', marginBottom:'2rem' }}>
  {[
  {icon:'📋',label:'שאלון רפואי מקצועי',sub:'13 שאלות מותאמות אישית'},
  {icon:'👁️',label:'צילום עין',sub:'תיעוד ויזואלי למסמך'},
  {icon:'⭕',label:'טופוגרפיה — Placido',sub:'ניתוח עקמומיות קרנית',hi:true},
  {icon:'🤖',label:'ניתוח AI עם Vision',sub:'הערכה מיידית ומפורטת'},
  {icon:'👨‍⚕️',label:'שיתוף עם רופא',sub:'דוח מלא ב-WhatsApp / אימייל'},
  ].map((f,i)=>(
  <div key={i} style={{ display:'flex', alignItems:'center', gap:'1rem', padding:'.85rem 1rem', background:f.hi?`${C.cyan}08`:C.card, border:`1px solid ${f.hi?`${C.cyan}40`:C.cardBorder}`, borderRadius:'.75rem' }}>
  <span style={{ fontSize:'1.2rem', width:32, textAlign:'center' }}>{f.icon}</span>
  <div><div style={{ color:f.hi?C.cyan:C.text, fontSize:'.9rem', fontWeight:600 }}>{f.label}</div><div style={{ color:C.muted, fontSize:'.75rem' }}>{f.sub}</div></div>
  </div>
  ))}
  </div>
  <div className="fu3" style={{ width:'100%', display:'flex', flexDirection:'column', gap:'.65rem' }}>
  <button className="hover-lift" onClick={onStart} style={{ width:'100%', padding:'1rem', background:C.cyan, color:C.bg, border:'none', borderRadius:'.875rem', fontSize:'1rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', boxShadow:`0 0 24px ${C.cyanGlow}` }}>התחל בדיקה ←</button>
  <button onClick={onBack} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.82rem', textDecoration:'underline', padding:'.4rem' }}>← חזור לתפריט ראשי</button>
  </div>
  </div>
  </Shell>
  );
}

function NameScreen({ onNext }) {
  const [name, setName] = useState('');
  return (
  <Shell center>
  <div dir="rtl" style={{ width:'100%', maxWidth:380, padding:'2rem' }}>
  <div className="fu0" style={{ textAlign:'center', marginBottom:'2.5rem' }}>
  <div style={{ fontSize:'3.5rem', marginBottom:'1rem' }}>👋</div>
  <h2 style={{ color:C.white, fontSize:'2rem', fontWeight:800, margin:0 }}>ברוך הבא!</h2>
  <p style={{ color:C.mutedLight, margin:'.5rem 0 0' }}>נתחיל בבדיקה — מה שמך?</p>
  </div>
  <div className="fu1">
  <input value={name} onChange={e=>setName(e.target.value)} onKeyDown={e=>e.key==='Enter'&&name.trim()&&onNext(name.trim())} placeholder="שם מלא..." style={{ width:'100%', padding:'1rem 1.25rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', color:C.text, fontSize:'1rem', fontFamily:'Heebo,sans-serif', marginBottom:'1rem', transition:'all .2s ease' }}/>
  <button className="hover-lift" disabled={!name.trim()} onClick={()=>onNext(name.trim())} style={{ width:'100%', padding:'1rem', background:name.trim()?C.cyan:'#131f2e', color:name.trim()?C.bg:C.muted, border:'none', borderRadius:'.875rem', fontSize:'1rem', fontWeight:800, cursor:name.trim()?'pointer':'not-allowed', fontFamily:'Heebo,sans-serif', transition:'all .2s ease', boxShadow:name.trim()?`0 0 20px ${C.cyanGlow}`:'none' }}>
  המשך לשאלון ←
  </button>
  </div>
  </div>
  </Shell>
  );
}

function QuestionnaireScreen({ qIndex, answers, onAnswer, onBack }) {
  const q = QUESTIONS[qIndex];
  const progress = (qIndex/QUESTIONS.length)*100;
  const [animKey, setAnimKey] = useState(0);
  useEffect(()=>{setAnimKey(k=>k+1);},[qIndex]);
  return (
  <Shell title="שאלון רפואי" subtitle="שלב 4 מתוך 5">
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem' }}>
  <div style={{ marginBottom:'1.5rem' }}>
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'.6rem' }}>
  <button onClick={onBack} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontSize:'.85rem', fontFamily:'Heebo,sans-serif', padding:0 }}>← חזור</button>
  <div style={{ display:'flex', alignItems:'center', gap:'.75rem' }}>
  <span style={{ color:C.muted, fontSize:'.82rem' }}>{qIndex+1} / {QUESTIONS.length}</span>
  <div style={{ width:36, height:36, position:'relative' }}>
  <svg width="36" height="36" viewBox="0 0 36 36">
  <circle cx="18" cy="18" r="15" fill="none" stroke="#1a2d3d" strokeWidth="3"/>
  <circle cx="18" cy="18" r="15" fill="none" stroke={C.cyan} strokeWidth="3" strokeDasharray={`${progress*.942} 94.2`} strokeDashoffset="23.55" strokeLinecap="round" style={{transition:'stroke-dasharray .4s ease'}}/>
  </svg>
  <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'.65rem', color:C.cyan, fontWeight:700 }}>{Math.round(progress)}%</div>
  </div>
  </div>
  </div>
  <div style={{ height:3, background:'rgba(255,255,255,.12)', borderRadius:2, overflow:'hidden' }}>
  <div style={{ height:'100%', background:`linear-gradient(90deg,${C.cyan},#818cf8)`, borderRadius:2, width:`${progress}%`, transition:'width .4s ease' }}/>
  </div>
  </div>
  <div key={animKey} style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'center', maxWidth:420, margin:'0 auto', width:'100%', animation:'fadeUp .35s ease' }}>
  <div style={{ marginBottom:'.4rem' }}><span style={{ fontSize:'.65rem', letterSpacing:'.25em', color:C.cyan, fontWeight:700 }}>שאלה {qIndex+1}</span></div>
  <h2 style={{ color:C.white, fontSize:'1.45rem', fontWeight:700, margin:'0 0 2rem', lineHeight:1.45 }}>{q.q}</h2>
  {q.type==='bool' ? (
  <div style={{ display:'flex', gap:'1rem' }}>
  <button className="bool-yes" onClick={()=>onAnswer('כן')} style={{ flex:1, padding:'1.25rem', background:'rgba(74,222,128,.1)', border:'2px solid rgba(34,197,94,.35)', borderRadius:'1rem', color:C.green, fontSize:'1.1rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif' }}>✓ כן</button>
  <button className="bool-no" onClick={()=>onAnswer('לא')} style={{ flex:1, padding:'1.25rem', background:'rgba(248,113,113,.1)', border:'2px solid rgba(239,68,68,.35)', borderRadius:'1rem', color:C.red, fontSize:'1.1rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif' }}>✗ לא</button>
  </div>
  ) : (
  <div style={{ display:'flex', flexDirection:'column', gap:'.7rem' }}>
  {q.opts.map((opt,i)=>(
  <div key={i} className="hover-slide" onClick={()=>onAnswer(opt)} style={{ padding:'1rem 1.25rem', background:'rgba(255,255,255,0.1)', border:'1px solid rgba(255,255,255,0.15)', borderRadius:'.875rem', color:C.text, fontSize:'.95rem', cursor:'pointer', fontWeight:500 }}>{opt}</div>
  ))}
  </div>
  )}
  </div>
  </div>
  </Shell>
  );
}

function CaptureScreen({ onContinue, stepLabel='שלב 2 מתוך 4' }) {
  const [captured, setCaptured] = useState(null);
  const [mode, setMode] = useState('choose');
  const [error, setError] = useState('');
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const fileInputRef = useRef(null);
  const streamRef = useRef(null);

  const startCamera = async () => {
  setError('');
  try {
  const stream = await navigator.mediaDevices.getUserMedia({ video:{facingMode:'environment',width:{ideal:1280}} });
  streamRef.current=stream; setMode('live');
  setTimeout(()=>{ if(videoRef.current){ videoRef.current.srcObject=stream; videoRef.current.play(); } },80);
  } catch(e) {
  setError(e.name==='NotAllowedError'?'הרשאת מצלמה נדחתה. השתמש בהעלאה מהגלריה.':'המצלמה אינה זמינה כאן. השתמש בהעלאה.');
  }
  };
  const stopCamera = ()=>{streamRef.current?.getTracks().forEach(t=>t.stop()); streamRef.current=null;};
  const captureFromVideo = ()=>{
  const v=videoRef.current,c=canvasRef.current; if(!v||!c) return;
  c.width=v.videoWidth||640; c.height=v.videoHeight||480;
  c.getContext('2d').drawImage(v,0,0);
  setCaptured(c.toDataURL('image/jpeg',.88)); stopCamera();
  };
  const handleFile = e=>{
  const file=e.target.files?.[0]; if(!file) return;
  const reader=new FileReader();
  reader.onload=ev=>setCaptured(ev.target.result);
  reader.readAsDataURL(file);
  };
  const reset=()=>{setCaptured(null); stopCamera(); setMode('choose'); setError('');};
  useEffect(()=>()=>stopCamera(),[]);

  if (captured) return (
  <Shell title="צילום עין">
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem' }}>
  <div className="fu0" style={{ textAlign:'center', marginBottom:'1.25rem' }}>
  <div style={{ fontSize:'.65rem', letterSpacing:'.25em', color:C.cyan, fontWeight:700, marginBottom:'.4rem' }}>{stepLabel}</div>
  <h2 style={{ color:C.white, margin:0, fontSize:'1.4rem', fontWeight:800 }}>📸 תמונת עין</h2>
  </div>
  <div className="fu1" style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:'1.25rem', maxWidth:420, margin:'0 auto', width:'100%' }}>
  <div style={{ position:'relative', width:'100%' }}>
  <img src={captured} alt="eye" style={{ width:'100%', borderRadius:'1rem', border:`2px solid ${C.cyan}`, display:'block', maxHeight:320, objectFit:'cover' }}/>
  <div style={{ position:'absolute', top:12, right:12, padding:'.3rem .75rem', background:'rgba(34,197,94,.9)', borderRadius:'1rem', color:'#fff', fontSize:'.78rem', fontWeight:700 }}>✓ תמונה נטענה</div>
  </div>
  <div style={{ display:'flex', gap:'.75rem', width:'100%' }}>
  <button className="hover-lift" onClick={reset} style={{ flex:1, padding:'.875rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', color:C.text, cursor:'pointer', fontFamily:'Heebo,sans-serif' }}>↺ החלף</button>
  <button className="hover-lift" onClick={()=>onContinue(captured)} style={{ flex:2, padding:'.875rem', background:C.cyan, color:C.bg, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', boxShadow:`0 0 16px ${C.cyanGlow}` }}>המשך ←</button>
  </div>
  </div>
  <canvas ref={canvasRef} style={{ display:'none' }}/>
  </div>
  </Shell>
  );

  if (mode==='live') return (
  <Shell>
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem' }}>
  <div className="fu0" style={{ textAlign:'center', marginBottom:'1rem' }}>
  <h2 style={{ color:C.white, margin:0, fontSize:'1.3rem', fontWeight:800 }}>📸 צלם עין</h2>
  <p style={{ color:C.mutedLight, margin:'.3rem 0 0', fontSize:'.82rem' }}>מרכז האישון בעיגול ← לחץ צלם</p>
  </div>
  <div style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:'1rem' }}>
  <div style={{ position:'relative', width:'100%', maxWidth:480 }}>
  <video ref={videoRef} autoPlay playsInline muted style={{ width:'100%', borderRadius:'1rem', display:'block', background:'#000', minHeight:280 }}/>
  <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', pointerEvents:'none' }}>
  <div style={{ position:'relative', width:160, height:160 }}>
  <div style={{ width:'100%', height:'100%', borderRadius:'50%', border:`2px solid ${C.cyan}`, boxShadow:'0 0 0 1600px rgba(2,12,27,.6)' }}/>
  <div style={{ position:'absolute', left:0, right:0, height:2, background:`linear-gradient(90deg,transparent 10%,${C.cyan} 50%,transparent 90%)`, animation:'scan-line 1.8s ease-in-out infinite', top:'20%' }}/>
  </div>
  </div>
  <button onClick={captureFromVideo} style={{ position:'absolute', bottom:16, left:'50%', transform:'translateX(-50%)', width:66, height:66, borderRadius:'50%', background:C.white, border:`4px solid ${C.cyan}`, cursor:'pointer', boxShadow:`0 0 24px ${C.cyanGlow}`, fontSize:'1.5rem' }}>📸</button>
  </div>
  <canvas ref={canvasRef} style={{ display:'none' }}/>
  <button onClick={()=>{stopCamera();setMode('choose');}} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontSize:'.82rem', fontFamily:'Heebo,sans-serif', textDecoration:'underline' }}>← חזור לאפשרויות</button>
  </div>
  </div>
  </Shell>
  );

  return (
  <Shell>
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem' }}>
  <div className="fu0" style={{ textAlign:'center', marginBottom:'1.5rem' }}>
  <div style={{ fontSize:'.65rem', letterSpacing:'.25em', color:C.cyan, fontWeight:700, marginBottom:'.4rem' }}>{stepLabel}</div>
  <h2 style={{ color:C.white, margin:0, fontSize:'1.4rem', fontWeight:800 }}>📸 צילום עין</h2>
  <p style={{ color:C.mutedLight, margin:'.4rem 0 0', fontSize:'.85rem' }}>בחר שיטת צילום</p>
  </div>
  {error && (
  <div className="fu1" style={{ background:'rgba(239,68,68,.07)', border:'1px solid rgba(239,68,68,.28)', borderRadius:'.875rem', padding:'.875rem 1rem', marginBottom:'1rem', display:'flex', gap:'.75rem' }}>
  <span>⚠️</span>
  <div style={{ color:'#fca5a5', fontSize:'.82rem' }}>{error}</div>
  </div>
  )}
  <div className="fu2" style={{ display:'flex', flexDirection:'column', gap:'.75rem', flex:1, justifyContent:'center', maxWidth:400, margin:'0 auto', width:'100%' }}>
  <div className="hover-slide" onClick={startCamera} style={{ padding:'1.1rem 1.25rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', cursor:'pointer', display:'flex', gap:'1rem', alignItems:'center' }}>
  <div style={{ width:48, height:48, borderRadius:'.75rem', background:`${C.cyan}18`, border:`1px solid ${C.cyan}33`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.4rem', flexShrink:0 }}>📷</div>
  <div style={{ flex:1 }}><div style={{ color:C.text, fontWeight:700 }}>צלם עכשיו</div><div style={{ color:C.muted, fontSize:'.76rem' }}>פתח מצלמה ישירות</div></div>
  <span style={{ color:C.cyan }}>←</span>
  </div>
  <div className="hover-slide" onClick={()=>fileInputRef.current?.click()} style={{ padding:'1.1rem 1.25rem', background:`${C.cyan}0a`, border:`2px solid ${C.cyan}55`, borderRadius:'1rem', cursor:'pointer', display:'flex', gap:'1rem', alignItems:'center' }}>
  <div style={{ width:48, height:48, borderRadius:'.75rem', background:`${C.cyan}22`, border:`1px solid ${C.cyan}55`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.4rem', flexShrink:0 }}>🖼️</div>
  <div style={{ flex:1 }}>
  <div style={{ display:'flex', alignItems:'center', gap:'.4rem' }}>
  <div style={{ color:C.cyan, fontWeight:700 }}>העלה מהגלריה</div>
  <span style={{ background:`${C.cyan}22`, borderRadius:'.4rem', padding:'.1rem .4rem', color:C.cyan, fontSize:'.6rem', fontWeight:700, border:`1px solid ${C.cyan}44` }}>מומלץ iOS</span>
  </div>
  <div style={{ color:C.mutedLight, fontSize:'.76rem' }}>צלם או בחר מהגלריה</div>
  </div>
  <span style={{ color:C.cyan }}>←</span>
  </div>
  <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFile} style={{ display:'none' }}/>
  <div style={{ background:'rgba(234,179,8,.05)', border:'1px solid rgba(234,179,8,.18)', borderRadius:'.875rem', padding:'.9rem 1rem' }}>
  <div style={{ color:C.yellow, fontSize:'.75rem', fontWeight:700, marginBottom:'.4rem' }}>💡 טיפ</div>
  <div style={{ color:C.mutedLight, fontSize:'.76rem', lineHeight:1.6 }}>• חדר מואר · ~10 ס"מ מהעין<br/>• וודא שהאישון ולבן העין נראים</div>
  </div>
  </div>
  <div className="fu3" style={{ textAlign:'center', paddingTop:'1rem' }}>
  <button onClick={()=>onContinue(null)} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontSize:'.82rem', fontFamily:'Heebo,sans-serif', textDecoration:'underline' }}>דלג על צילום</button>
  </div>
  </div>
  </Shell>
  );
}

function PlacidoScreen({ onComplete }) {
  const [phase, setPhase] = useState('intro');
  const [countdown, setCountdown] = useState(5);
  const [cameraError, setCameraError] = useState('');
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const projCanvasRef = useRef(null);
  const placidoFileRef = useRef(null);
  const streamRef = useRef(null);
  const timerRef = useRef(null);

  const handlePlacidoFile = e => {
  const file=e.target.files?.[0]; if(!file) return;
  const reader=new FileReader();
  reader.onload=ev=>{ setPhase('processing'); setTimeout(()=>onComplete(ev.target.result),1200); };
  reader.readAsDataURL(file);
  };

  const drawPlacidoRings = useCallback(()=>{
  const canvas=projCanvasRef.current; if(!canvas) return;
  const ctx=canvas.getContext('2d');
  const W=canvas.width, H=canvas.height, cx=W/2, cy=H/2;
  ctx.fillStyle='#000'; ctx.fillRect(0,0,W,H);
  const maxR=Math.min(W,H)*.46, ringCount=20;
  for(let i=ringCount;i>=1;i--){
  const r=(i/ringCount)*maxR, thickness=(maxR/ringCount)*.42;
  ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2);
  ctx.strokeStyle=i%2===0?'#fff':'#777'; ctx.lineWidth=thickness; ctx.stroke();
  }
  ctx.beginPath(); ctx.arc(cx,cy,5,0,Math.PI*2); ctx.fillStyle='#fff'; ctx.fill();
  ctx.strokeStyle='rgba(255,255,255,.2)'; ctx.lineWidth=1; ctx.setLineDash([4,4]);
  ctx.beginPath(); ctx.moveTo(cx-40,cy); ctx.lineTo(cx+40,cy); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(cx,cy-40); ctx.lineTo(cx,cy+40); ctx.stroke();
  ctx.setLineDash([]);
  },[]);

  const startCapture = useCallback(async()=>{
  setPhase('capture');
  try {
  const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:1280}}});
  streamRef.current=stream;
  setTimeout(()=>{ if(videoRef.current){ videoRef.current.srcObject=stream; videoRef.current.play(); } },100);
  } catch(e){ setCameraError('לא ניתן לגשת למצלמה הקדמית.'); }
  },[]);

  useEffect(()=>{
  if(phase!=='project') return;
  const t=setTimeout(()=>drawPlacidoRings(),80);
  let c=5; setCountdown(c);
  timerRef.current=setInterval(()=>{ c-=1; setCountdown(c); if(c<=0){ clearInterval(timerRef.current); startCapture(); } },1000);
  return()=>{ clearTimeout(t); clearInterval(timerRef.current); };
  },[phase,drawPlacidoRings,startCapture]);

  const captureReflection=()=>{
  const v=videoRef.current,c=canvasRef.current; if(!v||!c) return;
  c.width=v.videoWidth||640; c.height=v.videoHeight||480;
  const ctx=c.getContext('2d'); ctx.save(); ctx.scale(-1,1); ctx.drawImage(v,-c.width,0); ctx.restore();
  const img=c.toDataURL('image/jpeg',.9);
  streamRef.current?.getTracks().forEach(t=>t.stop());
  setPhase('processing'); setTimeout(()=>onComplete(img),1600);
  };

  useEffect(()=>()=>{ streamRef.current?.getTracks().forEach(t=>t.stop()); clearInterval(timerRef.current); },[]);

  if(phase==='intro') return (
  <Shell title="בדיקת Placido">
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem', paddingBottom:'2rem' }}>
  <div className="fu0" style={{ textAlign:'center', marginBottom:'1.5rem' }}>
  <div style={{ fontSize:'.65rem', letterSpacing:'.25em', color:C.cyan, fontWeight:700, marginBottom:'.4rem' }}>שלב 3 מתוך 4</div>
  <h2 style={{ color:C.white, margin:0, fontSize:'1.4rem', fontWeight:800 }}>⭕ טופוגרפיית Placido</h2>
  </div>
  <div className="fu1" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1.1rem', marginBottom:'1rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.75rem', letterSpacing:'.1em' }}>⚙️ איך זה עובד?</div>
  <div style={{ display:'flex', flexDirection:'column', gap:'.65rem' }}>
  {['המסך יציג טבעות אור קונצנטריות (Placido Disk)','קרב עינך למסך — ~5 ס"מ','המצלמה הקדמית תצלם את ההשתקפות בקרנית','AI מנתח עיוותים לזיהוי קרטוקונוס'].map((t,i)=>(
  <div key={i} style={{ display:'flex', gap:'.75rem', alignItems:'flex-start' }}>
  <div style={{ width:22, height:22, borderRadius:'50%', background:`${C.cyan}22`, border:`1px solid ${C.cyan}44`, display:'flex', alignItems:'center', justifyContent:'center', color:C.cyan, fontSize:'.7rem', fontWeight:700, flexShrink:0 }}>{i+1}</div>
  <p style={{ color:C.mutedLight, margin:0, fontSize:'.85rem', lineHeight:1.5 }}>{t}</p>
  </div>
  ))}
  </div>
  </div>
  <div className="fu2" style={{ display:'flex', gap:'1rem', marginBottom:'1rem', justifyContent:'center' }}>
  <div style={{ textAlign:'center' }}>
  <svg width="110" height="110" viewBox="0 0 110 110"><rect width="110" height="110" fill="#000" rx="10"/>{[50,42,34,26,19,13,8,4].map((r,i)=><circle key={i} cx="55" cy="55" r={r} fill="none" stroke={i%2===0?'#fff':'#888'} strokeWidth={i%2===0?2.5:2}/>)}<circle cx="55" cy="55" r="2" fill="#fff"/></svg>
  <div style={{ color:C.green, fontSize:'.68rem', marginTop:'.3rem', fontWeight:600 }}>✓ תקין</div>
  </div>
  <div style={{ textAlign:'center' }}>
  <svg width="110" height="110" viewBox="0 0 110 110"><rect width="110" height="110" fill="#000" rx="10"/>{[50,42,34,26,19,13,8,4].map((r,i)=>{ const d=[0,3,5,7,8,6,4,2][i]; return <ellipse key={i} cx={55+d} cy={55-d*.6} rx={r*1.15} ry={r*.88} fill="none" stroke={i%2===0?'#fff':'#888'} strokeWidth={i%2===0?2.5:2}/>; })}<circle cx="58" cy="52" r="2" fill="#fff"/></svg>
  <div style={{ color:C.red, fontSize:'.68rem', marginTop:'.3rem', fontWeight:600 }}>⚠ קרטוקונוס</div>
  </div>
  </div>
  <div className="fu3" style={{ background:'rgba(234,179,8,.05)', border:'1px solid rgba(234,179,8,.2)', borderRadius:'1rem', padding:'1rem', marginBottom:'1.5rem' }}>
  <div style={{ color:C.yellow, fontSize:'.78rem', fontWeight:700, marginBottom:'.4rem' }}>💡 לתוצאות מיטביות</div>
  <div style={{ color:C.mutedLight, fontSize:'.78rem', lineHeight:1.65 }}>• חדר חשוך · הסר עדשות מגע<br/>• ~5 ס"מ מהמסך · הביט למרכז</div>
  </div>
  <div className="fu4" style={{ display:'flex', flexDirection:'column', gap:'.65rem' }}>
  <button className="hover-lift" onClick={()=>setPhase('project')} style={{ width:'100%', padding:'1rem', background:C.cyan, color:C.bg, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', boxShadow:`0 0 20px ${C.cyanGlow}` }}>⭕ הצג Placido ←</button>
  <button onClick={()=>onComplete(null)} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', textDecoration:'underline', padding:'.5rem', fontSize:'.82rem' }}>דלג על טופוגרפיה</button>
  </div>
  </div>
  </Shell>
  );

  if(phase==='project'){
  const size=Math.min(typeof window!=='undefined'?window.innerWidth:400, typeof window!=='undefined'?window.innerHeight:800);
  return (
  <div style={{ position:'fixed', inset:0, background:'#000', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', zIndex:9999 }}>
  <canvas ref={projCanvasRef} width={size} height={size} style={{ display:'block', maxWidth:'100vmin', maxHeight:'100vmin' }}/>
  <div style={{ position:'absolute', bottom:36, left:0, right:0, display:'flex', flexDirection:'column', alignItems:'center', gap:10 }}>
  <div style={{ position:'relative', width:60, height:60 }}>
  <svg width="60" height="60" viewBox="0 0 60 60"><circle cx="30" cy="30" r="26" fill="none" stroke="rgba(255,255,255,.12)" strokeWidth="3.5"/><circle cx="30" cy="30" r="26" fill="none" stroke={C.cyan} strokeWidth="3.5" strokeDasharray="163.4" strokeLinecap="round" strokeDashoffset={(1-countdown/5)*163.4} transform="rotate(-90 30 30)" style={{transition:'stroke-dashoffset .9s linear'}}/></svg>
  <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:'1.4rem', fontWeight:900, fontFamily:'Heebo,sans-serif' }}>{countdown}</div>
  </div>
  <p style={{ color:'rgba(255,255,255,.65)', fontSize:'.8rem', fontFamily:'Heebo,sans-serif', margin:0, textAlign:'center', direction:'rtl' }}>קרב עין למסך · מצלמה בעוד {countdown} שניות</p>
  </div>
  </div>
  );
  }

  if(phase==='capture') return (
  <div style={{ position:'fixed', inset:0, background:'#000', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', zIndex:9999, fontFamily:'Heebo,sans-serif' }}>
  {cameraError ? (
  <div dir="rtl" style={{ width:'100%', maxWidth:380, padding:'1.5rem', display:'flex', flexDirection:'column', gap:'1rem' }}>
  <div style={{ background:'rgba(239,68,68,.1)', border:'1px solid rgba(239,68,68,.3)', borderRadius:'.875rem', padding:'.875rem 1rem', display:'flex', gap:'.75rem' }}><span>⚠️</span><div style={{ color:'#fca5a5', fontSize:'.82rem' }}>{cameraError}</div></div>
  <div style={{ background:'rgba(6,182,212,.07)', border:`1px solid ${C.cyan}33`, borderRadius:'1rem', padding:'1rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.6rem' }}>📋 צילום ידני:</div>
  {['פתח מצלמת iPhone','עבור לקדמי (selfie)','קרב עין למסך — ~5 ס"מ','צלם כשרואה טבעות בעין','חזור ולחץ ״העלה תמונה״'].map((s,i)=>(
  <div key={i} style={{ display:'flex', gap:'.6rem', alignItems:'flex-start', marginBottom:'.4rem' }}>
  <div style={{ width:18, height:18, borderRadius:'50%', background:`${C.cyan}22`, display:'flex', alignItems:'center', justifyContent:'center', color:C.cyan, fontSize:'.6rem', fontWeight:700, flexShrink:0 }}>{i+1}</div>
  <p style={{ color:C.mutedLight, margin:0, fontSize:'.78rem' }}>{s}</p>
  </div>
  ))}
  </div>
  <button onClick={()=>{setCameraError('');setPhase('project');}} style={{ width:'100%', padding:'.875rem', background:`${C.cyan}18`, border:`1px solid ${C.cyan}44`, borderRadius:'.875rem', color:C.cyan, fontWeight:700, cursor:'pointer', fontFamily:'Heebo,sans-serif' }}>⭕ הצג שוב Placido</button>
  <button onClick={()=>placidoFileRef.current?.click()} style={{ width:'100%', padding:'1rem', background:C.cyan, color:C.bg, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', boxShadow:`0 0 20px ${C.cyanGlow}` }}>🖼️ העלה תמונת השתקפות</button>
  <input ref={placidoFileRef} type="file" accept="image/*" onChange={handlePlacidoFile} style={{ display:'none' }}/>
  <button onClick={()=>onComplete(null)} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.8rem', textDecoration:'underline', textAlign:'center' }}>דלג על טופוגרפיה</button>
  </div>
  ) : (
  <>
  <video ref={videoRef} autoPlay playsInline muted style={{ width:'100%', maxWidth:520, display:'block', transform:'scaleX(-1)' }}/>
  <div style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', pointerEvents:'none' }}>
  <svg width="200" height="200" viewBox="0 0 200 200"><circle cx="100" cy="100" r="94" fill="none" stroke="rgba(6,182,212,.5)" strokeWidth="1.5" strokeDasharray="5,5"/><circle cx="100" cy="100" r="66" fill="none" stroke="rgba(6,182,212,.35)" strokeWidth="1"/><circle cx="100" cy="100" r="38" fill="none" stroke="rgba(6,182,212,.25)" strokeWidth="1"/><line x1="75" y1="100" x2="125" y2="100" stroke="rgba(6,182,212,.6)" strokeWidth=".8"/><line x1="100" y1="75" x2="100" y2="125" stroke="rgba(6,182,212,.6)" strokeWidth=".8"/></svg>
  </div>
  <div dir="rtl" style={{ position:'absolute', top:20, left:0, right:0, textAlign:'center' }}>
  <div style={{ display:'inline-block', padding:'.4rem 1rem', background:'rgba(0,0,0,.75)', borderRadius:'1rem', color:C.cyan, fontSize:'.8rem', border:`1px solid ${C.cardBorder}` }}>מרכז עינך וצלם</div>
  </div>
  <button onClick={captureReflection} style={{ position:'absolute', bottom:32, left:'50%', transform:'translateX(-50%)', width:72, height:72, borderRadius:'50%', background:'rgba(255,255,255,.95)', border:`4px solid ${C.cyan}`, cursor:'pointer', boxShadow:`0 0 28px ${C.cyanGlow}`, fontSize:'1.5rem' }}>📸</button>
  </>
  )}
  <canvas ref={canvasRef} style={{ display:'none' }}/>
  </div>
  );

  return (
  <Shell center>
  <div dir="rtl" style={{ textAlign:'center', padding:'2rem' }}>
  <div style={{ position:'relative', width:100, height:100, margin:'0 auto 1.5rem' }}>
  <div style={{ position:'absolute', inset:0, borderRadius:'50%', border:'3px solid rgba(6,182,212,.15)' }}/>
  <div style={{ position:'absolute', inset:0, borderRadius:'50%', border:'3px solid transparent', borderTopColor:C.cyan, animation:'spin 1s linear infinite' }}/>
  <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'2rem' }}>⭕</div>
  </div>
  <p style={{ color:C.cyan, fontWeight:700, margin:'0 0 .4rem', fontFamily:'Heebo,sans-serif' }}>מעבד Placido...</p>
  </div>
  </Shell>
  );
}

function AnalysisScreen() {
  const steps=['סורק היסטוריה רפואית...','מנתח תמונת עין...','מפענח טבעות Placido...','בודק עקמומיות קרנית...','מחשב ציון התאמה...','מכין המלצות...'];
  const [active,setActive]=useState(0);
  useEffect(()=>{const iv=setInterval(()=>setActive(s=>(s+1)%steps.length),900);return()=>clearInterval(iv);},[]);
  return (
  <Shell center title="ניתוח AI">
  <div dir="rtl" style={{ textAlign:'center', padding:'2rem', maxWidth:340 }}>
  <div style={{ position:'relative', width:120, height:120, margin:'0 auto 2rem' }}>
  <div style={{ position:'absolute', inset:0, borderRadius:'50%', border:'3px solid rgba(6,182,212,.15)' }}/>
  <div style={{ position:'absolute', inset:0, borderRadius:'50%', border:'3px solid transparent', borderTopColor:C.cyan, animation:'spin 1.1s linear infinite' }}/>
  <div style={{ position:'absolute', inset:8, borderRadius:'50%', border:'2px solid rgba(6,182,212,.08)', borderTopColor:'rgba(6,182,212,.4)', animation:'spin 1.8s linear reverse infinite' }}/>
  <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center' }}>
  <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke={C.cyan} strokeWidth="1.4" strokeLinecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
  </div>
  </div>
  <h2 style={{ color:C.white, fontSize:'1.5rem', fontWeight:800, margin:'0 0 .75rem' }}>מנתח נתונים...</h2>
  <p style={{ color:C.mutedLight, margin:'0 0 2rem', fontSize:'.9rem' }}>AI בוחן שאלון + צילום + ניתוח Placido</p>
  <div style={{ display:'flex', flexDirection:'column', gap:'.5rem' }}>
  {steps.map((s,i)=>(
  <div key={i} style={{ display:'flex', alignItems:'center', gap:'.75rem', justifyContent:'center', opacity:i===active?1:0.3, transition:'opacity .3s' }}>
  <div style={{ width:6, height:6, borderRadius:'50%', background:i===active?C.cyan:C.muted, boxShadow:i===active?`0 0 8px ${C.cyan}`:'none', transition:'all .3s' }}/>
  <span style={{ color:i===active?C.cyan:C.muted, fontSize:'.82rem' }}>{s}</span>
  </div>
  ))}
  </div>
  </div>
  </Shell>
  );
}

function ResultsScreen({ result, patientName, capturedEye, placidoImage, onShare, onRestart, onToPricing }) {
  const sc=result?.color==='green'?C.green:result?.color==='yellow'?C.yellow:C.red;
  const circ=2*Math.PI*52;
  const offset=circ-((result?.score||0)/100)*circ;
  const pc=result?.placido?.risk==='low'?C.green:result?.placido?.risk==='medium'?C.yellow:C.red;
  return (
  <Shell title="תוצאות הבדיקה">
  <div dir="rtl" style={{ padding:'1.25rem', maxWidth:440, margin:'0 auto', width:'100%', paddingBottom:'2rem' }}>
  <div className="fu0" style={{ textAlign:'center', marginBottom:'1.5rem' }}>
  <div style={{ fontSize:'.65rem', letterSpacing:'.25em', color:C.cyan, fontWeight:700, marginBottom:'.4rem' }}>תוצאות הבדיקה</div>
  <h2 style={{ color:C.white, margin:0, fontSize:'1.4rem', fontWeight:800 }}>{patientName}</h2>
  <p style={{ color:C.muted, margin:'.2rem 0 0', fontSize:'.8rem' }}>{new Date().toLocaleDateString('he-IL',{day:'numeric',month:'long',year:'numeric'})}</p>
  </div>
  <div className="fu1" style={{ textAlign:'center', marginBottom:'1.5rem' }}>
  <div style={{ position:'relative', display:'inline-block' }}>
  <svg width="140" height="140" viewBox="0 0 140 140"><circle cx="70" cy="70" r="52" fill="none" stroke="#0f2030" strokeWidth="10"/><circle cx="70" cy="70" r="52" fill="none" stroke={sc} strokeWidth="10" strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round" transform="rotate(-90 70 70)" style={{transition:'stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)'}}/></svg>
  <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center' }}>
  <div style={{ fontSize:'2.4rem', fontWeight:900, color:sc, lineHeight:1 }}>{result?.score}</div>
  <div style={{ fontSize:'.7rem', color:C.muted }}>/ 100</div>
  </div>
  </div>
  <div style={{ marginTop:'.75rem' }}>
  <span style={{ display:'inline-block', padding:'.4rem 1.5rem', background:`${sc}18`, border:`1.5px solid ${sc}`, borderRadius:'2rem', color:sc, fontWeight:800, fontSize:'1.05rem', boxShadow:`0 0 16px ${sc}30` }}>{result?.verdict}</span>
  </div>
  </div>
  {result?.placido && (
  <div className="fu2" style={{ background:'rgba(255,255,255,0.09)', border:`2px solid ${pc}44`, borderRadius:'1rem', padding:'1.1rem', marginBottom:'.75rem', position:'relative', overflow:'hidden' }}>
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'.9rem' }}>
  <div style={{ color:C.cyan, fontSize:'.72rem', fontWeight:700, letterSpacing:'.12em' }}>⭕ PLACIDO</div>
  <span style={{ padding:'.25rem .8rem', background:`${pc}18`, border:`1px solid ${pc}55`, borderRadius:'1rem', color:pc, fontSize:'.72rem', fontWeight:700 }}>{result.placido.risk==='low'?'✓ תקין':result.placido.risk==='medium'?'⚠ חשד':'✗ ממצא'}</span>
  </div>
  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.45rem', marginBottom:'.8rem' }}>
  {[{l:'סימטרייה',v:result.placido.symmetry},{l:'עקמומיות',v:result.placido.centralCurvature},{l:'חריגות',v:result.placido.peripheralVariation},{l:'KC מדד',v:result.placido.kcIndex}].map((m,i)=>(
  <div key={i} style={{ background:'rgba(255,255,255,.07)', borderRadius:'.6rem', padding:'.55rem .7rem' }}>
  <div style={{ color:C.muted, fontSize:'.65rem', marginBottom:'.2rem' }}>{m.l}</div>
  <div style={{ color:C.text, fontSize:'.8rem', fontWeight:600 }}>{m.v}</div>
  </div>
  ))}
  </div>
  <p style={{ color:C.mutedLight, margin:0, fontSize:'.82rem', lineHeight:1.55 }}>{result.placido.summary}</p>
  {placidoImage && (
  <div style={{ display:'flex', gap:'.7rem', alignItems:'center', paddingTop:'.75rem', borderTop:'1px solid rgba(6,182,212,.1)', marginTop:'.75rem' }}>
  <img src={placidoImage} alt="placido" style={{ width:54, height:54, borderRadius:'.6rem', objectFit:'cover', border:`1px solid ${C.cyan}44` }}/>
  <div style={{ color:C.muted, fontSize:'.72rem' }}>תמונת Placido · נכללת בדוח</div>
  </div>
  )}
  </div>
  )}
  {capturedEye && (
  <div className="fu2" style={{ marginBottom:'.75rem', display:'flex', gap:'.75rem', alignItems:'center', padding:'.75rem 1rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem' }}>
  <img src={capturedEye} alt="eye" style={{ width:48, height:48, borderRadius:'50%', objectFit:'cover', border:`1px solid ${C.cyan}` }}/>
  <div style={{ color:C.text, fontSize:'.82rem', fontWeight:600 }}>צילום עין · נכלל בדוח</div>
  </div>
  )}
  <div className="fu3" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1.1rem', marginBottom:'.75rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.5rem' }}>📊 סיכום</div>
  <p style={{ color:C.text, margin:0, lineHeight:1.65, fontSize:'.88rem' }}>{result?.summary}</p>
  </div>
  {result?.risks?.length>0 && (
  <div className="fu3" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1.1rem', marginBottom:'.75rem' }}>
  <div style={{ color:C.red, fontSize:'.75rem', fontWeight:700, marginBottom:'.6rem' }}>⚠️ גורמי סיכון</div>
  <div style={{ display:'flex', flexWrap:'wrap', gap:'.4rem' }}>{result.risks.map((r,i)=><span key={i} style={{ padding:'.25rem .7rem', background:'rgba(239,68,68,.1)', border:'1px solid rgba(239,68,68,.28)', borderRadius:'1rem', color:'#fca5a5', fontSize:'.78rem' }}>{r}</span>)}</div>
  </div>
  )}
  {result?.pros?.length>0 && (
  <div className="fu4" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1.1rem', marginBottom:'.75rem' }}>
  <div style={{ color:C.green, fontSize:'.75rem', fontWeight:700, marginBottom:'.6rem' }}>✅ גורמים חיוביים</div>
  <div style={{ display:'flex', flexWrap:'wrap', gap:'.4rem' }}>{result.pros.map((p,i)=><span key={i} style={{ padding:'.25rem .7rem', background:'rgba(34,197,94,.1)', border:'1px solid rgba(34,197,94,.28)', borderRadius:'1rem', color:'#86efac', fontSize:'.78rem' }}>{p}</span>)}</div>
  </div>
  )}
  <div className="fu4" style={{ background:`${C.cyan}0d`, border:'1px solid rgba(6,182,212,.3)', borderRadius:'1rem', padding:'1.1rem', marginBottom:'1.25rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.5rem' }}>🎯 צעד הבא</div>
  <p style={{ color:C.text, margin:0, fontSize:'.88rem', lineHeight:1.55 }}>{result?.nextStep}</p>
  </div>
  <div className="fu5" style={{ display:'flex', flexDirection:'column', gap:'.875rem' }}>
    {/* 24h confirmation */}
    <div style={{ background:'rgba(74,222,128,0.12)', border:'1.5px solid rgba(74,222,128,0.35)', borderRadius:'1.1rem', padding:'1.1rem 1.25rem', display:'flex', gap:'.875rem', alignItems:'flex-start' }}>
      <div style={{ fontSize:'1.75rem', flexShrink:0, lineHeight:1 }}>📬</div>
      <div>
        <div style={{ color:C.green, fontWeight:800, fontSize:'.95rem', marginBottom:'.3rem' }}>התוצאות נקלטו בהצלחה!</div>
        <div style={{ color:C.mutedLight, fontSize:'.82rem', lineHeight:1.6 }}>
          הצוות הרפואי של <strong style={{ color:'#fff' }}>ד"ר עיני נץ</strong> קיבל את הנתונים שלך.<br/>
          <strong style={{ color:C.green }}>נחזור אליך תוך 24 שעות</strong> עם תשובה מלאה.
        </div>
      </div>
    </div>
    {/* Continue CTA */}
    <button className="hover-lift" onClick={onToPricing} style={{ width:'100%', padding:'1.05rem', background:'linear-gradient(135deg,#1a5fa8,#0891b2)', color:'#fff', border:'none', borderRadius:'1rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.97rem', boxShadow:'0 4px 18px rgba(26,95,168,0.45)', letterSpacing:'.01em' }}>
      💰 המשך תהליך — לשלב הצעת המחיר ←
    </button>
    <button className="hover-lift" onClick={onRestart} style={{ width:'100%', padding:'.85rem', background:'rgba(255,255,255,0.09)', border:'1px solid rgba(255,255,255,.18)', color:C.mutedLight, borderRadius:'1rem', cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.88rem' }}>↺ בדיקה חדשה</button>
  </div>
  </div>
  </Shell>
  );
}

function ShareScreen({ result, patientName, capturedEye, placidoImage, onBack }) {
  const [copied,setCopied]=useState(false);
  const date=new Date().toLocaleDateString('he-IL',{day:'numeric',month:'long',year:'numeric'});
  const pc=result?.placido;
  const report=`דוח בדיקת התאמה לניתוח לייזר — OptiScan\n==========================================\nמטופל: ${patientName} | תאריך: ${date}\nציון: ${result?.score}/100 | סטטוס: ${result?.verdict}\nPlacido: ${placidoImage?'בוצע':'לא בוצע'}${pc?`\n${pc.summary}`:''}\n\nסיכום: ${result?.summary}\nסיכונים: ${result?.risks?.join(' | ')}\nחיובי: ${result?.pros?.join(' | ')}\nהמלצה: ${result?.nextStep}\n==========================================\n⚠️ סינון ראשוני בלבד.`;
  const share=m=>{
  if(m==='email') window.open(`mailto:?subject=דוח בדיקת לייזר - ${patientName}&body=${encodeURIComponent(report)}`);
  if(m==='whatsapp') window.open(`https://wa.me/?text=${encodeURIComponent(report)}`);
  if(m==='copy'){navigator.clipboard.writeText(report).then(()=>{setCopied(true);setTimeout(()=>setCopied(false),2000);});}
  };
  const sc=result?.color==='green'?C.green:result?.color==='yellow'?C.yellow:C.red;
  return (
  <Shell title="שתף תוצאות">
  <div dir="rtl" style={{ padding:'1.25rem', maxWidth:440, margin:'0 auto', width:'100%' }}>
  <button onClick={onBack} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', padding:0, marginBottom:'1.5rem' }}>← חזור לתוצאות</button>
  <div className="fu0" style={{ marginBottom:'1.5rem' }}>
  <h2 style={{ color:C.white, fontSize:'1.5rem', fontWeight:800, margin:'0 0 .3rem' }}>שתף תוצאות</h2>
  <p style={{ color:C.mutedLight, margin:0, fontSize:'.85rem' }}>שלח לרופא העיניים</p>
  </div>
  <div className="fu1" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1.25rem', marginBottom:'1.25rem' }}>
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'.875rem', paddingBottom:'.875rem', borderBottom:'1px solid rgba(6,182,212,.12)' }}>
  <div><div style={{ color:C.white, fontWeight:700 }}>דוח בדיקת התאמה</div><div style={{ color:C.muted, fontSize:'.75rem' }}>{patientName} · {date}</div></div>
  <span style={{ padding:'.3rem .875rem', background:`${sc}18`, border:`1px solid ${sc}`, borderRadius:'1rem', color:sc, fontSize:'.78rem', fontWeight:700 }}>{result?.score}/100</span>
  </div>
  <div style={{ color:C.mutedLight, fontSize:'.78rem', lineHeight:1.6 }}>{result?.summary?.substring(0,140)}...</div>
  </div>
  <div className="fu2" style={{ display:'flex', flexDirection:'column', gap:'.65rem', marginBottom:'1.5rem' }}>
  {[{icon:'📧',label:'שלח באימייל',sub:'פתח אפליקציית מייל',m:'email'},{icon:'💬',label:'שתף ב-WhatsApp',sub:'שלח ישירות לרופא',m:'whatsapp'},{icon:copied?'✅':'📋',label:copied?'הועתק!':'העתק טקסט',sub:'הדבק ידנית',m:'copy'}].map((opt,i)=>(
  <div key={i} className="hover-slide" onClick={()=>share(opt.m)} style={{ display:'flex', alignItems:'center', gap:'1rem', padding:'.9rem 1.1rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', cursor:'pointer' }}>
  <span style={{ fontSize:'1.3rem', width:32, textAlign:'center' }}>{opt.icon}</span>
  <div><div style={{ color:C.text, fontWeight:600 }}>{opt.label}</div><div style={{ color:C.muted, fontSize:'.72rem' }}>{opt.sub}</div></div>
  </div>
  ))}
  </div>
  <div className="fu3" style={{ padding:'1rem', background:'rgba(239,68,68,.05)', border:'1px solid rgba(239,68,68,.18)', borderRadius:'.875rem', color:C.muted, fontSize:'.75rem', lineHeight:1.55 }}>
  <strong style={{ color:'#fca5a5' }}>⚠️</strong> דוח זה הוא סינון ראשוני בלבד — אינו תחליף לאבחנה רפואית.
  </div>
  </div>
  </Shell>
  );
}

// POST-OP MODULE

function SurgerySetupScreen({ onSave, onBack }) {
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [surgeryType, setSurgeryType] = useState('LASIK');
  return (
  <Shell title="הגדרת מעקב">
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem' }}>
  <button onClick={onBack} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.85rem', padding:0, marginBottom:'1.5rem' }}>← חזור</button>
  <div className="fu0" style={{ textAlign:'center', marginBottom:'2rem' }}>
  <div style={{ fontSize:'3rem', marginBottom:'.75rem' }}>🏥</div>
  <h2 style={{ color:C.white, fontSize:'1.5rem', fontWeight:800, margin:0 }}>הגדרת מעקב אחרי ניתוח</h2>
  <p style={{ color:C.mutedLight, margin:'.5rem 0 0', fontSize:'.85rem' }}>הגדר פעם אחת — ועקוב לאורך שנה</p>
  </div>
  <div className="fu1" style={{ display:'flex', flexDirection:'column', gap:'1rem', maxWidth:380, margin:'0 auto', width:'100%' }}>
  <div>
  <label style={{ color:C.mutedLight, fontSize:'.78rem', fontWeight:600, display:'block', marginBottom:'.4rem' }}>שם מלא</label>
  <input value={name} onChange={e=>setName(e.target.value)} placeholder="שמך..." style={{ width:'100%', padding:'.9rem 1.1rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', color:C.text, fontSize:'1rem', fontFamily:'Heebo,sans-serif' }}/>
  </div>
  <div>
  <label style={{ color:C.mutedLight, fontSize:'.78rem', fontWeight:600, display:'block', marginBottom:'.4rem' }}>תאריך הניתוח</label>
  <input type="date" value={date} onChange={e=>setDate(e.target.value)} style={{ width:'100%', padding:'.9rem 1.1rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', color:C.text, fontSize:'1rem', fontFamily:'Heebo,sans-serif', colorScheme:'dark' }}/>
  </div>
  <div>
  <label style={{ color:C.mutedLight, fontSize:'.78rem', fontWeight:600, display:'block', marginBottom:'.4rem' }}>סוג הניתוח</label>
  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:'.5rem' }}>
  {['LASIK','PRK','SMILE'].map(t=>(
  <div key={t} onClick={()=>setSurgeryType(t)} style={{ padding:'.7rem', background:surgeryType===t?'rgba(167,139,250,.2)':'rgba(255,255,255,.07)', border:`${surgeryType===t?2:1}px solid ${surgeryType===t?C.purple:'rgba(255,255,255,.15)'}`, borderRadius:'.75rem', color:surgeryType===t?C.purple:C.mutedLight, textAlign:'center', cursor:'pointer', fontWeight:surgeryType===t?700:400, transition:'all .15s', fontSize:'.9rem' }}>{t}</div>
  ))}
  </div>
  </div>
  <button className="hover-lift" disabled={!name.trim()||!date} onClick={()=>onSave({name:name.trim(),surgeryDate:date,surgeryType,checkups:[]})} style={{ width:'100%', padding:'1rem', background:name.trim()&&date?C.purple:'#131f2e', color:name.trim()&&date?C.white:C.muted, border:'none', borderRadius:'.875rem', fontSize:'1rem', fontWeight:800, cursor:name.trim()&&date?'pointer':'not-allowed', fontFamily:'Heebo,sans-serif', marginTop:'.5rem', boxShadow:name.trim()&&date?`0 0 20px ${C.purple}44`:'none', transition:'all .2s' }}>
  התחל מעקב ←
  </button>
  </div>
  </div>
  </Shell>
  );
}

function FollowUpDashboard({ data, onStartCheckup, onBack }) {
  const surgeryDate = new Date(data.surgeryDate);
  const today = new Date();
  const daysSince = Math.floor((today - surgeryDate) / (1000*60*60*24));
  const checkups = data.checkups || [];

  // Find next due checkup
  const nextCheckup = FOLLOWUP_TIMELINE.find(t => {
  const done = checkups.find(c=>c.timelineId===t.id);
  return !done && daysSince >= t.days - 1;
  });

  // Progress chart data — visus over time
  const visusData = checkups.filter(c=>c.visus).map(c=>({ label:c.timelineLabel, val:c.visus.snellenNum, date:c.date }));

  return (
  <Shell title="לוח מעקב">
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem', paddingBottom:'2rem' }}>

  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'1.25rem' }}>
  <button onClick={onBack} style={{ background:'none', border:'none', color:C.muted, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.85rem', padding:0 }}>← ראשי</button>
  <div style={{ textAlign:'center' }}>
  <div style={{ color:C.purple, fontSize:'.65rem', fontWeight:700, letterSpacing:'.2em' }}>מעקב אחרי ניתוח</div>
  <div style={{ color:C.white, fontWeight:800, fontSize:'.95rem' }}>{data.name}</div>
  </div>
  <div style={{ textAlign:'left' }}>
  <div style={{ color:C.muted, fontSize:'.68rem' }}>יום {daysSince}</div>
  <div style={{ color:C.mutedLight, fontSize:'.72rem' }}>{data.surgeryType}</div>
  </div>
  </div>

  {nextCheckup && (
  <div className="fu0" style={{ background:`${C.purple}12`, border:`2px solid ${C.purple}44`, borderRadius:'1.1rem', padding:'1.1rem', marginBottom:'1rem' }}>
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'.6rem' }}>
  <div>
  <div style={{ color:C.purple, fontSize:'.72rem', fontWeight:700, letterSpacing:'.1em' }}>⏰ בדיקה נדרשת</div>
  <div style={{ color:C.white, fontSize:'1.1rem', fontWeight:800, marginTop:'.2rem' }}>{nextCheckup.icon} {nextCheckup.label}</div>
  <div style={{ color:C.mutedLight, fontSize:'.78rem' }}>{nextCheckup.desc}</div>
  </div>
  <button className="hover-lift" onClick={()=>onStartCheckup(nextCheckup)} style={{ padding:'.7rem 1.2rem', background:C.purple, color:C.white, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.85rem', boxShadow:`0 0 16px ${C.purple}44`, whiteSpace:'nowrap' }}>
  התחל ←
  </button>
  </div>
  </div>
  )}

  {visusData.length > 0 && (
  <div className="fu1" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1rem', marginBottom:'1rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.75rem', letterSpacing:'.1em' }}>📈 גרף ויזוס לאורך זמן</div>
  <div style={{ position:'relative', height:100 }}>
  <svg width="100%" height="100" viewBox={`0 0 ${Math.max(visusData.length*70,280)} 100`} preserveAspectRatio="none">

  {[0,25,50,75,100].map(y=>(
  <line key={y} x1="0" y1={100-y} x2="100%" y2={100-y} stroke="rgba(255,255,255,.05)" strokeWidth="1"/>
  ))}

  {visusData.length>1 && (
  <polyline points={visusData.map((d,i)=>`${i*70+20},${100-d.val}`).join(' ')} fill="none" stroke={C.purple} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
  )}

  {visusData.map((d,i)=>(
  <g key={i}>
  <circle cx={i*70+20} cy={100-d.val} r="5" fill={C.purple} stroke={C.bg} strokeWidth="2"/>
  <text x={i*70+20} y="115" textAnchor="middle" fill={C.muted} fontSize="10" fontFamily="Heebo,sans-serif">{d.label}</text>
  <text x={i*70+20} y={100-d.val-10} textAnchor="middle" fill={C.text} fontSize="9" fontFamily="Heebo,sans-serif">{SNELLEN_ROWS.find(r=>r.snellenNum===d.val)?.acuity||''}</text>
  </g>
  ))}
  </svg>
  </div>

  <div style={{ display:'flex', alignItems:'center', gap:'.4rem', marginTop:'.5rem' }}>
  <div style={{ width:16, height:2, background:C.green, borderRadius:1 }}/>
  <div style={{ color:C.muted, fontSize:'.68rem' }}>יעד: 6/6 (ראייה מושלמת)</div>
  </div>
  </div>
  )}

  <div className="fu2" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1rem', marginBottom:'1rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.875rem', letterSpacing:'.1em' }}>📅 לוח מעקב</div>
  <div style={{ display:'flex', flexDirection:'column', gap:'.6rem' }}>
  {FOLLOWUP_TIMELINE.map((t,i)=>{
  const done = checkups.find(c=>c.timelineId===t.id);
  const due = !done && daysSince >= t.days - 1;
  const future = !done && daysSince < t.days - 1;
  const color = done?C.green:due?C.yellow:C.muted;
  const dueDate = new Date(surgeryDate); dueDate.setDate(dueDate.getDate()+t.days);
  return (
  <div key={i} style={{ display:'flex', alignItems:'center', gap:'.875rem' }}>
  <div style={{ width:28, height:28, borderRadius:'50%', background:`${color}18`, border:`1.5px solid ${color}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'.85rem', flexShrink:0 }}>{done?'✓':t.icon}</div>
  <div style={{ flex:1 }}>
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
  <div style={{ color:done?C.text:due?C.yellow:C.muted, fontWeight:done||due?600:400, fontSize:'.88rem' }}>{t.label}</div>
  <div style={{ color:C.muted, fontSize:'.68rem' }}>{dueDate.toLocaleDateString('he-IL',{day:'numeric',month:'short'})}</div>
  </div>
  {done && done.visus && (
  <div style={{ color:C.green, fontSize:'.72rem', marginTop:'.1rem' }}>
  ויזוס: {done.visus.acuity} · {done.visus.score}% נכון
  </div>
  )}
  {due && <div style={{ color:C.yellow, fontSize:'.72rem', marginTop:'.1rem' }}>נדרשת עכשיו</div>}
  {future && <div style={{ color:C.muted, fontSize:'.72rem', marginTop:'.1rem' }}>בעוד {t.days-daysSince} ימים</div>}
  </div>
  </div>
  );
  })}
  </div>
  </div>

  {checkups.length>0 && checkups[checkups.length-1].symptoms && (
  <div className="fu3" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1rem', marginBottom:'1rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.75rem', letterSpacing:'.1em' }}>😊 תסמינים אחרונים — {checkups[checkups.length-1].timelineLabel}</div>
  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.5rem' }}>
  {SYMPTOM_QUESTIONS.map((q,i)=>{
  const val = checkups[checkups.length-1].symptoms[q.id]||0;
  const isGood = q.id==='clarity' ? val>=7 : val<=3;
  const barColor = isGood?C.green:val>6?C.red:C.yellow;
  return (
  <div key={i} style={{ background:'rgba(255,255,255,.07)', borderRadius:'.6rem', padding:'.55rem .7rem' }}>
  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:'.3rem' }}>
  <div style={{ color:C.muted, fontSize:'.68rem' }}>{q.icon} {q.label}</div>
  <div style={{ color:barColor, fontSize:'.72rem', fontWeight:700 }}>{val}/10</div>
  </div>
  <div style={{ height:4, background:'rgba(255,255,255,.07)', borderRadius:2 }}>
  <div style={{ height:'100%', width:`${val*10}%`, background:barColor, borderRadius:2, transition:'width .4s' }}/>
  </div>
  </div>
  );
  })}
  </div>
  </div>
  )}

  {checkups.length>0 && checkups[checkups.length-1].alert && (
  <div className="fu3" style={{ background:'rgba(248,113,113,.1)', border:'2px solid rgba(239,68,68,.4)', borderRadius:'1rem', padding:'1rem', marginBottom:'1rem', display:'flex', gap:'.75rem' }}>
  <div style={{ fontSize:'1.5rem' }}>🚨</div>
  <div>
  <div style={{ color:C.red, fontWeight:800, marginBottom:'.3rem' }}>התראה — ממצא חריג</div>
  <div style={{ color:'#fca5a5', fontSize:'.82rem', lineHeight:1.5 }}>{checkups[checkups.length-1].alert}</div>
  <button style={{ marginTop:'.6rem', padding:'.4rem .875rem', background:'rgba(239,68,68,.2)', border:'1px solid rgba(239,68,68,.5)', borderRadius:'.5rem', color:C.red, fontSize:'.78rem', fontWeight:700, cursor:'pointer', fontFamily:'Heebo,sans-serif' }}
  onClick={()=>{ const t=checkups[checkups.length-1]; window.open(`https://wa.me/?text=${encodeURIComponent(`⚠️ דוח מעקב לייזר — ממצא חריג\nמטופל: ${data.name}\nתאריך: ${t.date}\nממצא: ${t.alert}`)}`); }}>
  📤 שלח לרופא עכשיו
  </button>
  </div>
  </div>
  )}

  <div className="fu4">
  <button onClick={()=>onStartCheckup(null)} style={{ width:'100%', padding:'.875rem', background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', color:C.mutedLight, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.88rem' }}>
  + בדיקה חופשית (ללא לוח זמנים)
  </button>
  </div>
  </div>
  </Shell>
  );
}

function VisusTestScreen({ onComplete }) {
  const [rowIndex, setRowIndex] = useState(0);
  const [letterIndex, setLetterIndex] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [total, setTotal] = useState(0);
  const [rowCorrect, setRowCorrect] = useState(0);
  const [finished, setFinished] = useState(false);
  const [finalAcuity, setFinalAcuity] = useState(null);
  const [sequence, setSequence] = useState(()=>SNELLEN_ROWS.map(r=>Array.from({length:r.count},()=>DIRS[Math.floor(Math.random()*4)])));
  const [feedback, setFeedback] = useState(null); // 'correct'|'wrong'

  const currentRow = SNELLEN_ROWS[rowIndex];
  const currentDir = sequence[rowIndex]?.[letterIndex];

  const answer = (dir) => {
  const isCorrect = dir === currentDir;
  setFeedback(isCorrect?'correct':'wrong');
  const newRowCorrect = rowCorrect + (isCorrect?1:0);
  const newTotal = total + 1;
  const newCorrect = correct + (isCorrect?1:0);

  setTimeout(()=>{
  setFeedback(null);
  const nextLetter = letterIndex + 1;
  if(nextLetter >= currentRow.count){
  // End of row — check if passed threshold
  const passed = newRowCorrect >= currentRow.threshold;
  if(!passed || rowIndex >= SNELLEN_ROWS.length-1){
  // Done — final acuity is current or previous row
  const acuityRow = passed ? currentRow : (rowIndex>0?SNELLEN_ROWS[rowIndex-1]:SNELLEN_ROWS[0]);
  setFinalAcuity(acuityRow);
  setFinished(true);
  return;
  }
  // Next row
  setRowIndex(r=>r+1);
  setLetterIndex(0);
  setRowCorrect(0);
  } else {
  setLetterIndex(nextLetter);
  setRowCorrect(newRowCorrect);
  }
  setTotal(newTotal);
  setCorrect(newCorrect);
  }, 400);
  };

  // Tumbling E SVG renderer
  const TumblingE = ({dir, size, dim=false}) => {
  const rotate = {up:270,down:90,left:180,right:0}[dir];
  return (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ opacity:dim?0.35:1 }}>
  <g transform={`rotate(${rotate},50,50)`} fill={C.white}>

  <rect x="20" y="15" width="15" height="70"/>
  <rect x="20" y="15" width="45" height="15"/>
  <rect x="20" y="42" width="38" height="15"/>
  <rect x="20" y="70" width="45" height="15"/>
  </g>
  </svg>
  );
  };

  if(finished && finalAcuity) return (
  <Shell title="בדיקת ויזוס">
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem', alignItems:'center', justifyContent:'center' }}>
  <div className="fu0" style={{ textAlign:'center', maxWidth:360, width:'100%' }}>
  <div style={{ fontSize:'3rem', marginBottom:'1rem' }}>👁️</div>
  <h2 style={{ color:C.white, fontSize:'1.6rem', fontWeight:900, margin:'0 0 .5rem' }}>תוצאת ויזוס</h2>
  <div style={{ display:'inline-block', padding:'.75rem 2rem', background:`${C.purple}22`, border:`2px solid ${C.purple}`, borderRadius:'1.5rem', marginBottom:'1.5rem' }}>
  <div style={{ color:C.purple, fontSize:'2.5rem', fontWeight:900, lineHeight:1 }}>{finalAcuity.acuity}</div>
  <div style={{ color:C.mutedLight, fontSize:'.78rem', marginTop:'.2rem' }}>חדות ראייה</div>
  </div>
  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.75rem', marginBottom:'1.5rem' }}>
  <div style={{ background:'rgba(255,255,255,0.09)', borderRadius:'1rem', padding:'.875rem', border:`1px solid ${C.cardBorder}` }}>
  <div style={{ color:C.muted, fontSize:'.72rem', marginBottom:'.3rem' }}>תשובות נכונות</div>
  <div style={{ color:C.green, fontSize:'1.4rem', fontWeight:800 }}>{correct}/{total}</div>
  </div>
  <div style={{ background:'rgba(255,255,255,0.09)', borderRadius:'1rem', padding:'.875rem', border:`1px solid ${C.cardBorder}` }}>
  <div style={{ color:C.muted, fontSize:'.72rem', marginBottom:'.3rem' }}>ציון</div>
  <div style={{ color:C.cyan, fontSize:'1.4rem', fontWeight:800 }}>{Math.round(correct/total*100)}%</div>
  </div>
  </div>
  <div style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'.875rem', padding:'.875rem', marginBottom:'1.5rem', textAlign:'right' }}>
  <div style={{ color:C.cyan, fontSize:'.72rem', fontWeight:700, marginBottom:'.5rem' }}>📊 מדרגת ויזוס</div>
  <div style={{ display:'flex', flexDirection:'column', gap:'.3rem' }}>
  {[{a:'6/60',l:'ראייה מאוד מוגבלת'},{a:'6/36',l:'חלשה'},{a:'6/24',l:'בינונית'},{a:'6/18',l:'סבירה'},{a:'6/12',l:'טובה'},{a:'6/9',l:'טובה מאוד'},{a:'6/6',l:'נורמלית'},{a:'6/5',l:'מעולה'}].map((r,i)=>(
  <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'.25rem .5rem', borderRadius:'.4rem', background:r.a===finalAcuity.acuity?`${C.purple}22`:'transparent', border:r.a===finalAcuity.acuity?`1px solid ${C.purple}44`:'none' }}>
  <span style={{ color:r.a===finalAcuity.acuity?C.purple:C.muted, fontWeight:r.a===finalAcuity.acuity?700:400, fontSize:'.82rem' }}>{r.a}</span>
  <span style={{ color:r.a===finalAcuity.acuity?C.text:C.muted, fontSize:'.78rem' }}>{r.l} {r.a===finalAcuity.acuity?'← אתה':''}</span>
  </div>
  ))}
  </div>
  </div>
  <button className="hover-lift" onClick={()=>onComplete({acuity:finalAcuity.acuity, snellenNum:finalAcuity.snellenNum, score:Math.round(correct/total*100), correct, total})} style={{ width:'100%', padding:'1rem', background:C.purple, color:C.white, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.95rem', boxShadow:`0 0 20px ${C.purple}44` }}>
  המשך לשאלון תסמינים ←
  </button>
  </div>
  </div>
  </Shell>
  );

  return (
  <Shell>
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem' }}>

  <div className="fu0" style={{ textAlign:'center', marginBottom:'1rem' }}>
  <div style={{ fontSize:'.65rem', letterSpacing:'.25em', color:C.purple, fontWeight:700, marginBottom:'.4rem' }}>בדיקת ויזוס</div>
  <h2 style={{ color:C.white, margin:0, fontSize:'1.3rem', fontWeight:800 }}>👁️ מבחן חדות ראייה</h2>
  <p style={{ color:C.mutedLight, margin:'.3rem 0 0', fontSize:'.82rem' }}>לאיזה כיוון האות E פונה?</p>
  </div>

  <div style={{ display:'flex', gap:'.3rem', marginBottom:'1rem', justifyContent:'center' }}>
  {SNELLEN_ROWS.map((r,i)=>(
  <div key={i} style={{ height:4, flex:1, maxWidth:32, borderRadius:2, background:i<rowIndex?C.purple:i===rowIndex?C.cyan:'rgba(255,255,255,.1)' }}/>
  ))}
  </div>
  <div style={{ textAlign:'center', marginBottom:'.5rem' }}>
  <span style={{ color:C.muted, fontSize:'.75rem' }}>שורה {rowIndex+1} מתוך {SNELLEN_ROWS.length} · אות {letterIndex+1} מתוך {currentRow.count}</span>
  <span style={{ color:C.cyan, fontSize:'.75rem', marginRight:'.5rem' }}> · יעד: {currentRow.acuity}</span>
  </div>

  <div style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:'1.5rem' }}>
  <div style={{ background:'rgba(255,255,255,0.09)', borderRadius:'1.5rem', padding:'2rem', border:`2px solid ${feedback==='correct'?C.green:feedback==='wrong'?C.red:C.cardBorder}`, transition:'border-color .2s', boxShadow:`0 0 ${feedback?40:0}px ${feedback==='correct'?C.green:feedback==='wrong'?C.red:'transparent'}40` }}>
  {currentDir && <TumblingE dir={currentDir} size={currentRow.size}/>}
  </div>
  {feedback && (
  <div style={{ fontSize:'1.5rem', animation:'fadeUp .3s ease' }}>{feedback==='correct'?'✅ נכון!':'❌ לא נכון'}</div>
  )}
  </div>

  <div style={{ padding:'1rem 0 .5rem' }}>

  <div style={{ display:'flex', justifyContent:'center', marginBottom:'.5rem' }}>
  <button className="dir-btn" onClick={()=>answer('up')} style={{ width:72, height:72, borderRadius:'1rem', background:`${C.cyan}12`, border:`2px solid ${C.cyan}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.8rem', color:C.cyan }}>
  {DIR_ARROWS.up}
  </button>
  </div>

  <div style={{ display:'flex', justifyContent:'center', gap:'1.5rem', marginBottom:'.5rem' }}>
  <button className="dir-btn" onClick={()=>answer('left')} style={{ width:72, height:72, borderRadius:'1rem', background:`${C.cyan}12`, border:`2px solid ${C.cyan}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.8rem', color:C.cyan }}>
  {DIR_ARROWS.left}
  </button>
  <div style={{ width:72, height:72, display:'flex', alignItems:'center', justifyContent:'center' }}>
  <div style={{ width:8, height:8, borderRadius:'50%', background:`${C.cyan}44` }}/>
  </div>
  <button className="dir-btn" onClick={()=>answer('right')} style={{ width:72, height:72, borderRadius:'1rem', background:`${C.cyan}12`, border:`2px solid ${C.cyan}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.8rem', color:C.cyan }}>
  {DIR_ARROWS.right}
  </button>
  </div>

  <div style={{ display:'flex', justifyContent:'center' }}>
  <button className="dir-btn" onClick={()=>answer('down')} style={{ width:72, height:72, borderRadius:'1rem', background:`${C.cyan}12`, border:`2px solid ${C.cyan}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.8rem', color:C.cyan }}>
  {DIR_ARROWS.down}
  </button>
  </div>
  <div style={{ textAlign:'center', marginTop:'.75rem', color:C.muted, fontSize:'.75rem' }}>
  לחץ על חץ בכיוון שבו האות E פונה
  </div>
  </div>
  </div>
  </Shell>
  );
}

function SymptomsScreen({ onComplete }) {
  const [values, setValues] = useState({dryness:0,clarity:5,pain:0,sensitivity:0,halos:0});
  const set = (id,v) => setValues(prev=>({...prev,[id]:v}));
  return (
  <Shell title="שאלון תסמינים">
  <div dir="rtl" style={{ minHeight:'100vh', display:'flex', flexDirection:'column', padding:'1.25rem', paddingBottom:'2rem' }}>
  <div className="fu0" style={{ textAlign:'center', marginBottom:'1.5rem' }}>
  <div style={{ fontSize:'.65rem', letterSpacing:'.25em', color:C.purple, fontWeight:700, marginBottom:'.4rem' }}>שאלון תסמינים</div>
  <h2 style={{ color:C.white, margin:0, fontSize:'1.3rem', fontWeight:800 }}>💊 איך אתה מרגיש?</h2>
  <p style={{ color:C.mutedLight, margin:'.3rem 0 0', fontSize:'.82rem' }}>דרג כל תסמין מ-0 (אין) עד 10 (חמור)</p>
  </div>
  <div className="fu1" style={{ display:'flex', flexDirection:'column', gap:'.875rem', flex:1, maxWidth:400, margin:'0 auto', width:'100%' }}>
  {SYMPTOM_QUESTIONS.map((q,i)=>{
  const v = values[q.id]||0;
  const isGood = q.id==='clarity'?v>=7:v<=3;
  const barColor = isGood?C.green:v>6?C.red:C.yellow;
  return (
  <div key={i} style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1rem' }}>
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'.6rem' }}>
  <div style={{ display:'flex', alignItems:'center', gap:'.5rem' }}>
  <span style={{ fontSize:'1.1rem' }}>{q.icon}</span>
  <span style={{ color:C.text, fontWeight:600, fontSize:'.9rem' }}>{q.label}</span>
  </div>
  <span style={{ color:barColor, fontWeight:800, fontSize:'1.1rem', minWidth:28, textAlign:'center' }}>{v}</span>
  </div>
  <input type="range" min="0" max="10" value={v} onChange={e=>set(q.id,+e.target.value)}
  style={{ width:'100%', accentColor:barColor, cursor:'pointer' }}/>
  <div style={{ display:'flex', justifyContent:'space-between', marginTop:'.25rem' }}>
  <span style={{ color:C.muted, fontSize:'.65rem' }}>0 — אין</span>
  <span style={{ color:C.muted, fontSize:'.65rem' }}>10 — חמור</span>
  </div>
  </div>
  );
  })}
  </div>
  <div className="fu3" style={{ paddingTop:'1.25rem', maxWidth:400, margin:'0 auto', width:'100%' }}>
  <button className="hover-lift" onClick={()=>onComplete(values)} style={{ width:'100%', padding:'1rem', background:C.purple, color:C.white, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', fontSize:'.95rem', boxShadow:`0 0 20px ${C.purple}44` }}>
  המשך לצילום עין ←
  </button>
  </div>
  </div>
  </Shell>
  );
}

function PostOpResultsScreen({ checkup, prevCheckup, patientName, onSave, onShare }) {
  const visus = checkup.visus;
  const visusTrend = prevCheckup?.visus ? visus.snellenNum - prevCheckup.visus.snellenNum : null;
  const visusColor = !visus ? C.muted : visus.acuity==='6/6'||visus.acuity==='6/5' ? C.green : visus.acuity==='6/9'||visus.acuity==='6/12' ? C.yellow : C.red;

  return (
  <Shell title="תוצאות מעקב">
  <div dir="rtl" style={{ padding:'1.25rem', maxWidth:440, margin:'0 auto', width:'100%', paddingBottom:'2rem' }}>
  <div className="fu0" style={{ textAlign:'center', marginBottom:'1.5rem' }}>
  <div style={{ fontSize:'.65rem', letterSpacing:'.25em', color:C.purple, fontWeight:700, marginBottom:'.4rem' }}>תוצאות מעקב</div>
  <h2 style={{ color:C.white, margin:0, fontSize:'1.4rem', fontWeight:800 }}>{checkup.timelineLabel||'בדיקת מעקב'}</h2>
  <p style={{ color:C.muted, margin:'.2rem 0 0', fontSize:'.8rem' }}>{checkup.date} · {patientName}</p>
  </div>

  {checkup.alert && (
  <div className="fu0" style={{ background:'rgba(248,113,113,.1)', border:'2px solid rgba(239,68,68,.4)', borderRadius:'1rem', padding:'1rem', marginBottom:'.875rem', display:'flex', gap:'.75rem' }}>
  <span style={{ fontSize:'1.4rem' }}>🚨</span>
  <div>
  <div style={{ color:C.red, fontWeight:800, marginBottom:'.3rem' }}>ממצא חריג!</div>
  <div style={{ color:'#fca5a5', fontSize:'.82rem', lineHeight:1.5 }}>{checkup.alert}</div>
  </div>
  </div>
  )}

  {visus && (
  <div className="fu1" style={{ background:'rgba(255,255,255,0.09)', border:`2px solid ${visusColor}44`, borderRadius:'1rem', padding:'1.1rem', marginBottom:'.75rem' }}>
  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'.75rem' }}>
  <div style={{ color:C.purple, fontSize:'.75rem', fontWeight:700, letterSpacing:'.1em' }}>👁️ ויזוס</div>
  {visusTrend!==null && (
  <span style={{ color:visusTrend>=0?C.green:C.red, fontSize:'.75rem', fontWeight:700 }}>
  {visusTrend>=0?'↑':'↓'} {visusTrend>=0?'+':''}{visusTrend} מהבדיקה הקודמת
  </span>
  )}
  </div>
  <div style={{ display:'flex', alignItems:'center', gap:'1rem' }}>
  <div style={{ textAlign:'center' }}>
  <div style={{ fontSize:'2.2rem', fontWeight:900, color:visusColor, lineHeight:1 }}>{visus.acuity}</div>
  <div style={{ color:C.muted, fontSize:'.7rem' }}>Snellen</div>
  </div>
  <div style={{ flex:1 }}>
  <div style={{ height:8, background:'rgba(255,255,255,.07)', borderRadius:4, overflow:'hidden' }}>
  <div style={{ height:'100%', width:`${visus.snellenNum}%`, background:`linear-gradient(90deg,${C.red},${C.yellow},${C.green})`, borderRadius:4 }}/>
  </div>
  <div style={{ display:'flex', justifyContent:'space-between', marginTop:'.3rem' }}>
  <span style={{ color:C.muted, fontSize:'.65rem' }}>6/60</span>
  <span style={{ color:C.muted, fontSize:'.65rem' }}>6/6</span>
  </div>
  </div>
  <div style={{ textAlign:'center' }}>
  <div style={{ color:C.cyan, fontSize:'1.2rem', fontWeight:700 }}>{visus.score}%</div>
  <div style={{ color:C.muted, fontSize:'.68rem' }}>נכון</div>
  </div>
  </div>
  </div>
  )}

  {checkup.symptoms && (
  <div className="fu2" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1rem', marginBottom:'.75rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.75rem' }}>💊 תסמינים</div>
  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.45rem' }}>
  {SYMPTOM_QUESTIONS.map((q,i)=>{
  const v=checkup.symptoms[q.id]||0;
  const isGood=q.id==='clarity'?v>=7:v<=3;
  const c=isGood?C.green:v>6?C.red:C.yellow;
  return (
  <div key={i} style={{ background:'rgba(255,255,255,.07)', borderRadius:'.6rem', padding:'.5rem .65rem' }}>
  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:'.25rem' }}>
  <div style={{ color:C.muted, fontSize:'.65rem' }}>{q.icon} {q.label}</div>
  <div style={{ color:c, fontSize:'.72rem', fontWeight:700 }}>{v}</div>
  </div>
  <div style={{ height:3, background:'rgba(255,255,255,.07)', borderRadius:2 }}>
  <div style={{ height:'100%', width:`${v*10}%`, background:c, borderRadius:2 }}/>
  </div>
  </div>
  );
  })}
  </div>
  </div>
  )}

  {checkup.aiAnalysis && (
  <div className="fu3" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1rem', marginBottom:'.75rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.5rem' }}>🤖 ניתוח AI</div>
  <p style={{ color:C.text, margin:0, fontSize:'.88rem', lineHeight:1.6 }}>{checkup.aiAnalysis}</p>
  </div>
  )}

  {checkup.eyeImage && prevCheckup?.eyeImage && (
  <div className="fu3" style={{ background:'rgba(255,255,255,0.09)', border:`1px solid ${C.cardBorder}`, borderRadius:'1rem', padding:'1rem', marginBottom:'.75rem' }}>
  <div style={{ color:C.cyan, fontSize:'.75rem', fontWeight:700, marginBottom:'.75rem' }}>📸 השוואת תמונות</div>
  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.75rem' }}>
  <div style={{ textAlign:'center' }}>
  <img src={prevCheckup.eyeImage} alt="prev" style={{ width:'100%', borderRadius:'.75rem', border:`1px solid ${C.cardBorder}`, objectFit:'cover', aspectRatio:'1' }}/>
  <div style={{ color:C.muted, fontSize:'.7rem', marginTop:'.3rem' }}>קודם</div>
  </div>
  <div style={{ textAlign:'center' }}>
  <img src={checkup.eyeImage} alt="now" style={{ width:'100%', borderRadius:'.75rem', border:`1px solid ${C.cyan}44`, objectFit:'cover', aspectRatio:'1' }}/>
  <div style={{ color:C.cyan, fontSize:'.7rem', marginTop:'.3rem' }}>עכשיו</div>
  </div>
  </div>
  </div>
  )}

  <div className="fu4" style={{ display:'flex', flexDirection:'column', gap:'.7rem' }}>
  <button className="hover-lift" onClick={onShare} style={{ width:'100%', padding:'1rem', background:C.purple, color:C.white, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', boxShadow:`0 0 20px ${C.purple}44` }}>
  📤 שלח לרופא
  </button>
  <button className="hover-lift" onClick={onSave} style={{ width:'100%', padding:'1rem', background:C.cyan, color:C.bg, border:'none', borderRadius:'.875rem', fontWeight:800, cursor:'pointer', fontFamily:'Heebo,sans-serif', boxShadow:`0 0 16px ${C.cyanGlow}` }}>
  ✓ שמור ועבור ללוח מחוונים
  </button>
  </div>
  </div>
  </Shell>
  );
}

function PostOpAnalysisScreen() {
  const steps=['בוחן ויזוס...','מנתח תסמינים...','משווה לבדיקה קודמת...','מזהה מגמות...','מחפש ממצאים חריגים...'];
  const [active,setActive]=useState(0);
  useEffect(()=>{const iv=setInterval(()=>setActive(s=>(s+1)%steps.length),800);return()=>clearInterval(iv);},[]);
  return (
  <Shell center>
  <div dir="rtl" style={{ textAlign:'center', padding:'2rem', maxWidth:320 }}>
  <div style={{ position:'relative', width:100, height:100, margin:'0 auto 1.5rem' }}>
  <div style={{ position:'absolute', inset:0, borderRadius:'50%', border:`3px solid ${C.purple}22` }}/>
  <div style={{ position:'absolute', inset:0, borderRadius:'50%', border:'3px solid transparent', borderTopColor:C.purple, animation:'spin 1.1s linear infinite' }}/>
  <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'2rem' }}>📈</div>
  </div>
  <h2 style={{ color:C.white, fontSize:'1.4rem', fontWeight:800, margin:'0 0 .75rem' }}>מנתח נתוני מעקב...</h2>
  <div style={{ display:'flex', flexDirection:'column', gap:'.5rem' }}>
  {steps.map((s,i)=>(
  <div key={i} style={{ display:'flex', alignItems:'center', gap:'.75rem', justifyContent:'center', opacity:i===active?1:0.3, transition:'opacity .3s' }}>
  <div style={{ width:6, height:6, borderRadius:'50%', background:i===active?C.purple:C.muted, boxShadow:i===active?`0 0 8px ${C.purple}`:'none' }}/>
  <span style={{ color:i===active?C.purple:C.muted, fontSize:'.82rem' }}>{s}</span>
  </div>
  ))}
  </div>
  </div>
  </Shell>
  );
}

// MAIN APP
export default function App() {
  const [mode, setMode] = useState('home');
  // Wire global home button
  useEffect(() => {
    setGoHome(() => () => {
      setMode('home');
      restartPreOpSilent();
    });
  }, []); // home | preop | postop | approval | chat | scheduler
  // PRE-OP state
  const [step, setStep] = useState('welcome');
  const [qIndex, setQIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [patientName, setPatientName] = useState('');
  const [patientId, setPatientId] = useState('');
  const [hmo, setHmo] = useState(null);
  const [schedulerData, setSchedulerData] = useState({}); // {pkg, finalPrice, hmoObj}
  const [selectedClinic, setSelectedClinic] = useState(null);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [capturedEye, setCapturedEye] = useState(null);
  const [placidoImage, setPlacidoImage] = useState(null);
  const [result, setResult] = useState(null);
  // POST-OP state
  const [postOpStep, setPostOpStep] = useState('dashboard');
  const [postOpData, setPostOpData] = useState(()=>loadPostOpData());
  const [currentCheckup, setCurrentCheckup] = useState(null);
  const [pendingCheckup, setPendingCheckup] = useState({});

  // Persist patient info
  const savePatient = (name, hmoId) => {
  savePatientStore(name, hmoId);
  setPatientName(name); setHmo(hmoId);
  };

  // ── PRE-OP LOGIC ──
  const answerQ = val => {
  const newA={...answers,[QUESTIONS[qIndex].id]:val};
  setAnswers(newA);
  if(qIndex<QUESTIONS.length-1) setQIndex(qIndex+1);
  else setStep('capture');
  };

  const runPreOpAnalysis = async(eyeImg,placidoImg)=>{
  setStep('analysis');
  try {
  const content=[];
  if(eyeImg){ content.push({type:'image',source:{type:'base64',media_type:'image/jpeg',data:eyeImg.split(',')[1]}}); content.push({type:'text',text:'[תמונה 1: צילום עין ישיר]'}); }
  if(placidoImg){ content.push({type:'image',source:{type:'base64',media_type:'image/jpeg',data:placidoImg.split(',')[1]}}); content.push({type:'text',text:'[תמונה 2: Placido — נתח עיוותים]'}); }
  const hmoObj=HMO_LIST.find(h=>h.id===hmo);
  const clinicInfo = CLINICS.find(c=>c.id===selectedClinic);
      const doctorInfo = DOCTORS.find(d=>d.id===selectedDoctor);
      content.push({type:'text',text:'שם:'+patientName+'\nקופה:'+(hmoObj?.name||'לא צוין')+'\nמרפאה:'+(clinicInfo?.name||'לא נבחרה')+'\nרופא:'+(doctorInfo?.name||'לא נבחר')+'\nשאלון:'+JSON.stringify(answers,null,2)+'\nעין:'+(eyeImg?'כן':'לא')+'\nPlacido:'+(placidoImg?'כן':'לא')});
  const res=await fetch("https://api.anthropic.com/v1/messages",{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
  model:'claude-sonnet-4-20250514',max_tokens:1500,
  system:`אתה AI רפואי לבדיקת התאמה לניתוח לייזר. נתח Placido אם סופק. החזר JSON בלבד:\n{"score":<0-100>,"verdict":"מתאים"|"ייתכן מתאים"|"לא מתאים","color":"green"|"yellow"|"red","summary":"2-3 משפטים","risks":["..."],"pros":["..."],"nextStep":"...","placido":{"risk":"low"|"medium"|"high","symmetry":"סימטרי"|"חצי-סימטרי"|"א-סימטרי","centralCurvature":"תקין"|"שטוח"|"תלול"|"לא ניתן","peripheralVariation":"נמוך"|"בינוני"|"גבוה"|"לא ניתן","kcIndex":"0.0-1.0 או לא ניתן","summary":"משפט"}}\nכללים: קרטוקונוס/גלאוקומה/הריון=לא מתאים. מספר לא יציב<שנה=לא מתאים.`,
  messages:[{role:'user',content:content.length>0?content:[{type:'text',text:`שם:${patientName}\nשאלון:${JSON.stringify(answers)}`}]}]
  })});
  const data=await res.json();
  const txt=data.content?.find?.(b=>b.type==='text')?.text||'{}';
  setResult(JSON.parse(txt.replace(/```json|```/g,'').trim()));
  } catch(e){
  console.error(e);
  setResult({score:65,verdict:'ייתכן מתאים',color:'yellow',summary:'על פי השאלון ייתכן שאתה מתאים. נדרשות בדיקות נוספות.',risks:['נדרשת טופוגרפיה קלינית'],pros:['אין מחלות רקע חמורות'],nextStep:'פנה לרופא לבדיקת LASIK מקיפה.',placido:{risk:'medium',symmetry:'לא ניתן',centralCurvature:'לא ניתן',peripheralVariation:'לא ניתן',kcIndex:'לא ניתן',summary:'שגיאה בחיבור.'}});
  }
  setStep('results');
  };

  const restartPreOp=()=>{setStep('welcome');setQIndex(0);setAnswers({});setCapturedEye(null);setPlacidoImage(null);setResult(null);setSelectedClinic(null);setSelectedDoctor(null);};
  const restartPreOpSilent=()=>{setStep('welcome');setQIndex(0);setAnswers({});setCapturedEye(null);setPlacidoImage(null);setResult(null);setSelectedClinic(null);setSelectedDoctor(null);};

  // ── POST-OP LOGIC ──
  const savePostOp = data => { setPostOpData(data); savePostOpData(data); };
  const startCheckup = tl => { setCurrentCheckup(tl); setPendingCheckup({}); setPostOpStep('visus'); };

  const runPostOpAnalysis = async (checkupData) => {
  setPostOpStep('analysis');
  const prev = (postOpData.checkups||[]).slice(-1)[0];
  try {
  const content = [];
  if(checkupData.eyeImage){ content.push({type:'image',source:{type:'base64',media_type:'image/jpeg',data:checkupData.eyeImage.split(',')[1]}}); content.push({type:'text',text:'[צילום עין נוכחי]'}); }
  content.push({type:'text',text:`מעקב אחרי ${checkupData.timelineLabel||'ניתוח לייזר'}\nויזוס: ${checkupData.visus?.acuity||'לא נבדק'}\nתסמינים: ${JSON.stringify(checkupData.symptoms)}\nקודם: ${prev?JSON.stringify({visus:prev.visus?.acuity,symptoms:prev.symptoms}):'ראשונה'}`});
  const res=await fetch("https://api.anthropic.com/v1/messages",{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
  model:'claude-sonnet-4-20250514',max_tokens:800,
  system:`אתה AI רפואי מנתח מעקב אחרי ניתוח לייזר. החזר JSON בלבד:\n{"analysis":"2-3 משפטים","alert":"התראה אם חריג או null","recommendation":"המלצה"}`,
  messages:[{role:'user',content:content.length>0?content:[{type:'text',text:`ויזוס:${checkupData.visus?.acuity}\nתסמינים:${JSON.stringify(checkupData.symptoms)}`}]}]
  })});
  const data=await res.json();
  const txt=data.content?.find?.(b=>b.type==='text')?.text||'{}';
  const parsed=JSON.parse(txt.replace(/```json|```/g,'').trim());
  setPendingCheckup({...checkupData, aiAnalysis:parsed.analysis, alert:parsed.alert||null, recommendation:parsed.recommendation, date:new Date().toLocaleDateString('he-IL')});
  setPostOpStep('results');
  } catch(e){
  setPendingCheckup({...checkupData, aiAnalysis:'ניתוח הושלם.', alert:null, date:new Date().toLocaleDateString('he-IL')});
  setPostOpStep('results');
  }
  };

  const saveCheckup = () => {
  savePostOp({...postOpData, checkups:[...(postOpData.checkups||[]), pendingCheckup]});
  setPendingCheckup({}); setCurrentCheckup(null); setPostOpStep('dashboard');
  };
  const shareCheckup = () => {
  const c=pendingCheckup;
  window.open(`https://wa.me/?text=${encodeURIComponent(`דוח מעקב לייזר — ${postOpData.name}\nתאריך: ${c.date} · ${c.timelineLabel||'בדיקה'}\nויזוס: ${c.visus?.acuity||'לא נבדק'}\nניתוח: ${c.aiAnalysis||''}\n${c.alert?`⚠️ ${c.alert}`:''}\n--- OptiScan ---`)}`);
  };

  // ── ROUTING ──
  if(mode==='home') return <HomeScreen
  patientName={patientName} hmo={hmo}
  onPreOp={()=>setMode('preop')}
  onPostOp={()=>setMode('postop')}
  onApproval={()=>setMode('approval')}
  onChat={()=>setMode('chat')}
  />;

  if(mode==='scheduler') return <SurgerySchedulerScreen
  patientName={patientName||'אורח'}
  pkg={schedulerData.pkg}
  finalPrice={schedulerData.finalPrice}
  hmoObj={schedulerData.hmoObj}
  onBack={()=>setMode('approval')}
  onConfirmed={()=>setMode('home')}
  />;

  if(mode==='approval') return <ApprovalScreen
  patientName={patientName||'אורח'}
  hmo={hmo}
  onBack={()=>setMode('home')}
  onChat={()=>setMode('chat')}
  onSchedule={(pkg,fp,hObj)=>{ setSchedulerData({pkg,finalPrice:fp,hmoObj:hObj}); setMode('scheduler'); }}
  />;

  if(mode==='chat') return <ChatCenterScreen
  patientName={patientName||'אורח'}
  hmo={hmo}
  onBack={()=>setMode('home')}
  />;

  if(mode==='preop'){
  if(step==='welcome') return <WelcomeScreen onStart={()=>setStep('name')} onBack={()=>{restartPreOp();setMode('home');}}/>;
  if(step==='name') return <NameScreen onNext={n=>{ setPatientName(n); setStep('hmo'); }}/>;
    if(step==='hmo') return <HmoScreen name={patientName} onNext={h=>{ savePatient(patientName, h); setStep('clinic'); }}/>;
    if(step==='clinic') return <ClinicScreen hmo={hmo} onNext={id=>{ setSelectedClinic(id); setStep('doctor'); }} onBack={()=>setStep('hmo')}/>;
    if(step==='doctor') return <DoctorScreen clinicId={selectedClinic} hmo={hmo} answers={answers} onNext={id=>{ setSelectedDoctor(id); setStep('questionnaire'); }} onBack={()=>setStep('clinic')}/>;
  if(step==='questionnaire') return <QuestionnaireScreen qIndex={qIndex} answers={answers} onAnswer={answerQ} onBack={()=>qIndex>0?setQIndex(qIndex-1):setStep('hmo')}/>;
  if(step==='capture') return <CaptureScreen onContinue={img=>{setCapturedEye(img);setStep('placido');}}/>;
  if(step==='placido') return <PlacidoScreen onComplete={img=>{setPlacidoImage(img);runPreOpAnalysis(capturedEye,img);}}/>;
  if(step==='analysis') return <AnalysisScreen/>;
  if(step==='results') return <ResultsScreen result={result} patientName={patientName} capturedEye={capturedEye} placidoImage={placidoImage} onShare={()=>setStep('share')} onRestart={restartPreOp} onToPricing={()=>setMode('approval')}/>;
  if(step==='share') return <ShareScreen result={result} patientName={patientName} capturedEye={capturedEye} placidoImage={placidoImage} onBack={()=>setStep('results')}/>;
  }

  if(mode==='postop'){
  if(postOpStep==='setup') return <SurgerySetupScreen onSave={d=>{savePostOp(d);setPostOpStep('dashboard');}} onBack={()=>setPostOpStep('dashboard')}/>;
  if(postOpStep==='dashboard'){
  if(!postOpData.surgeryDate) return <SurgerySetupScreen onSave={d=>{savePostOp(d);setPostOpStep('dashboard');}} onBack={()=>setMode('home')}/>;
  return <FollowUpDashboard data={postOpData} onStartCheckup={startCheckup} onBack={()=>setMode('home')}/>;
  }
  if(postOpStep==='visus') return <VisusTestScreen onComplete={v=>{setPendingCheckup(p=>({...p,visus:v,timelineId:currentCheckup?.id,timelineLabel:currentCheckup?.label||'בדיקה חופשית'}));setPostOpStep('symptoms');}}/>;
  if(postOpStep==='symptoms') return <SymptomsScreen onComplete={s=>{setPendingCheckup(p=>({...p,symptoms:s}));setPostOpStep('capture');}}/>;
  if(postOpStep==='capture') return <CaptureScreen stepLabel="צילום עין" onContinue={img=>{const cd={...pendingCheckup,eyeImage:img}; setPendingCheckup(cd); runPostOpAnalysis(cd);}}/>;
  if(postOpStep==='analysis') return <PostOpAnalysisScreen/>;
  if(postOpStep==='results'){
  const prev=(postOpData.checkups||[]).slice(-1)[0];
  return <PostOpResultsScreen checkup={pendingCheckup} prevCheckup={prev} patientName={postOpData.name} onSave={saveCheckup} onShare={shareCheckup}/>;
  }
  }

  return null;
}

